#DDR54 diagssystemAnalyst2
3)pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst % cd phyinit/ddr54
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst3/phyinit/ddr54 % rm -r diags.tar.gz 
rm: remove regular file `diags.tar.gz'? y'''
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/ddr54 % make phyinit
pranavp@us01msemt364:/remote/us01sgnfs00017/users/pranavp/clients/ddr54 % cd pmu_firmware/Diags_test/
pranavp@us01msemt364:/remote/us01sgnfs00017/users/pranavp/clients/ddr54/pmu_firmware/Diags_test % make

#Running on test chip
# ddr54 
#In CA09 - DDR54 workspace
1)pranavp@ca09lts2:~/Desktop % ssh -X ca09lab-bfmgr2-lnx #Secure shell
2)pranavp@ca09lts2:~/Desktop % cd /remote/ca09dws000/ddrphy_firmware/pranavp/
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst3/phyinit/ddr54 % rm -r diags.tar.gz 
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst3/phyinit/ddr54 % rm -rf diagfw/ 
#In US01
5)pranavp@us01msem-32cx720g-386-120:/remote/us01sgnfs00017/users/pranavp/clients/ddr54 % cd build/c 

#Zip fw, init folders from US01
#If we need diag, zip diag from US01
8)pranavp@us01msem-32cx720g-386-120:/remote/us01sgnfs00017/users/pranavp/clients/ddr54/build/c % tar zchf diags.tar.gz diags 

#Export fw, init and diag to SystemAnalyst/phyinit/ddr54 from US01
9) pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/ddr54/build/c %  scp diags.tar.gz pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/`whoami`/systemAnalyst5/phyinit/ddr54
   The authenticity of host 'ca09lab-bfmgr2-lnx (10.44.12.92)' can't be established.
   RSA key fingerprint is SHA256:I4Ljc3kHMBmmAxoRwNqscvRVNZHCn6s09G/Nwdk1S5Q.
   RSA key fingerprint is MD5:37:e5:aa:d4:f7:9f:f3:88:3c:88:9f:1e:15:33:f0:7a.
   Are you sure you want to continue connecting (yes/no)? yes
   Warning: Permanently added 'ca09lab-bfmgr2-lnx,10.44.12.92' (RSA) to the list of known hosts.
   fw.tar.gz                                                                                                                   100%   10MB   5.9MB/s   00:01    
   init.tar.gz                                                                                                                 100%   13MB  13.4MB/s   00:01    
   diags.tar.gz                                                                                                                100%  252     2.9KB/s   00:00 '   

#In CA09 - DDR54 workspaceUnzip fw, init and diags in SystemAnalyst/phyinit/ddr54
10)pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst/phyinit/ddr54 % tar zxf diags.tar.gz
  #Rename diags to diagfw
  pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst/phyinit/ddr54 % mv diags diagfw   
#Compile and Run in a required DDR5 chip
13)python src/util/compile.py -sn FT242541 -r
  python src/apps/diags_driver.py -sn FT242541 -c configs/ddr54_ddr5_rdimm.json -hdtctrl 0xA

#To read CSR definitions and it's purpose
pranavp@us01msemt361:/remote/us01sgnfs00017/users/pranavp/clients/ddr54 % st rtl/pub/st csr.txt


