pranavp@us01odcvde40200:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_Copy % p4 edit pmu_firmware/lpddr/common_api/eddrphy_PMU_MsgBlock.xls
pranavp@us01odcvde40200:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_Copy % df -h /remote/us01sgnfs00017/
Filesystem                                     Size  Used Avail Use% Mounted on
us01cm01-t2-fs:/US01SGNFS00017/us01sgnfs00017  2.0T  1.2T  868G  57% /remote/us01sgnfs00017

# Windows search bar
\\us01cm01-t2-fs\us01sgnfs00017\users\pranavp\clients\lpddr5x_Copy
\\us01cm01-t2-fs\us01sgnfs00017\users\pranavp\clients\lp5_std
\\us01cm01-t2-fs\us01sgnfs00017\users\pranavp\clients\ddr54
Click on easy access option on the top menu -> map as drive 

\\ca09cm01-t2-sg2\ca09dwp004\ddrphy_firmware\pranavp\systemAnalyst2022_12

Drive:  W
Folder: \\us01cm01-t2-fs\us01sgnfs00017\users\pranavp\clients\lpddr5x_Copy
Folder: \\us01cm01-t2-fs\us01sgnfs00017\users\pranavp\clients\lp5_std

Click Finish

Then we go the corresponding folder and edit the excel sheet and save it directly.