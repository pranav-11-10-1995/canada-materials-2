#--Move to root of workspace
cd $REPO_PATH

#--Build prerequisties for StdProd LP5
make cleanAte ateDone LP54X=1

#--Build prerequisties for StdProd D5
make ateDone DDR5=1

#--Move to 'ate_firmware/'
cd $REPO_PATH/pmu_firmware/ate_firmware/

#--Compile only for D5
make clean real fake DDR5=1

#--Compile only for LP5
make clean real fake DDR5=0

#--Compile for LP5 and D5
make clean && make real fake DDR5=1 && make real fake DDR5=0

#--Compile + quickly check for syntax errors
make real DDR5=0
make real DDR5=1