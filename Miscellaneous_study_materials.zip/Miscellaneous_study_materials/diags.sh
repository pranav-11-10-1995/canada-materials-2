Mode Register Read:

Test Menu
2	Send Burst Writes
3	Send Burst Reads
4	Simple Write Read
5	Tx Eye
6	Rx Eye
9	Mode Register Write
10	Mode Register Read
rl	Reload firmware
w	Write PHY register value
r	Read PHY register value
rw_gui	Read/Write PHY register value
c	Run command script
C	Dump all CSRs
d	Change debug level [0:255]
D	Run DQS Oscillator
E	Print evaled expression 
X	Print hex of evaled expression
p	PIE Menu
h	Print this help
x	Exit

Enter test number: 10
DiagRank (CS[3:0]): 0x
Defaulting to 0x0
MR to read: 14
Training has run successfully (firmware complete)
Total number of bytes read from mailbox: 2
MR14 dbyte00 value: 0x33
MR14 dbyte01 value: 0x0
MR14 dbyte02 value: 0x0
MR14 dbyte03 value: 0x32



Change the debug level:
Test Menu
2	Send Burst Writes
3	Send Burst Reads
4	Simple Write Read
5	Tx Eye
6	Rx Eye
9	Mode Register Write
10	Mode Register Read
rl	Reload firmware
w	Write PHY register value
r	Read PHY register value
rw_gui	Read/Write PHY register value
c	Run command script
C	Dump all CSRs
d	Change debug level [0:255]
D	Run DQS Oscillator
E	Print evaled expression 
X	Print hex of evaled expression
p	PIE Menu
h	Print this help
x	Exit

Enter test number: d
Debug level (0x4-0xff): 0x4
Diags debug level (HdtCtrl) set to 0x4


