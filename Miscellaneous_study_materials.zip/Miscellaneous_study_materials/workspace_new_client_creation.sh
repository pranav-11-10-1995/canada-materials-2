#Creating a workspace
pranavp@us01odcvde17752:~/Desktop % cd /remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy/
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % cd ..
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients % ls
lpddr54  lpddr54_2009.amd  lpddr5x_mphy 
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients % mkdir ddr54
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients % cd ddr54/ 
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/ddr54 % p4w -mkwa -code=ddr54/dev -novwa 
#DDR54 std
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/ddr54 % p4w -mkwa -code=lpddr5x_ddr5_phy/dev -novwa
p4w: Command not found.
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/ddr54 % cd ..    
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients % cd lpddr54/
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54 % source bootenv
Bootenv grid type = msem
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54 % p4w -update_env
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54 % source bootenv
Bootenv grid type = msem
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54 % cd ..
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients % cd ddr54/ 
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/ddr54 % p4w -mkwa -code=ddr54/dev -novwa
#DDR54 std
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/ddr54 % p4w -mkwa -code=lpddr5x_ddr5_phy/dev -novwa


#Integrating a folder from depot to folder in local workspace
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst % mkdir fw_validation
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst % cd fw_validation
#this copied all files from fw_validation folder present in the depot to local workspace
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst/fw_validation % p4 integ //depot/products/SystemAnalyst/fw_validation/... /remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst/fw_validation/...


#Creating a new client in System Analyst
#SystemAnalyst2 is our new client(workspace)
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp % mkdir SystemAnalyst2
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp % cd SystemAnalyst2
#copy P4CONFIG from old client 'SystemAnalyst'
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst2 % cp ../SystemAnalyst1/P4CONFIG .
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst2 % setenv P4EDITOR 'evim -f'
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst2 % evim P4CONFIG
#Change SystemAnalyst to SystemAnalyst2 for P4CLIENT
	In P4CONFIG file, add the following code
	P4CLIENT=msip_pranavp_SystemAnalyst2_ca09
	P4PORT=p4p-ca09:1999
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst2 % p4 client
#Add the following:
	go to insert mode: press i
	    View:
	        //depot/products/SystemAnalyst/dev/... //msip_pranavp_SystemAnalyst2_ca09/...
	go out of insert mode: press esc
	save the client file: wq
		Client msip_pranavp_SystemAnalyst2_ca09 saved.
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst2 % p4 sync -f
#Whenever we open a new terminal, always set the following env variables
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst2 % setenv SYSTEM_ANALYST_HOME `pwd`
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst2 % setenv PYTHONPATH `pwd`:`pwd`/src
#If I get import module saleae error
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst2 % setenv PYTHONPATH ${PYTHONPATH}:/remote/ca09dws000/ddrphy_firmware/Saleae/lib/python2.7/site-packages
#Changing to editor to gvim - easy to add description after shelve
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst2 % setenv P4EDITOR 'evim -f'
#Build a link to copyfw-nightly
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst2 % ln -s ../../delbaere/SystemAnalyst/copyfw-nightly
#Run the following command to get up to date firmware
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst2 % ./copyfw-nightly ddr54_dev

#How to get customer release version from perforce
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54 % p4v&
#We can see both workspace and depot
#We ll have customer releases in depot
path: //depot/products/lpddr54/branches_fw/rel_vA-2020.09-T-0056931_AMD/
#Use this to load the release version into workspace
p4w -mkwa -code=lpddr54/branches_fw/rel_vA-2020.09-T-0056931_AMD -novwa
Note: //depot/products/lpddr54/dev/pmu_firmware/production_code/ #dev path


#Creating customer release version as workspace
#Getrelease version and product (whether it's LPDDR54 or Combo_PHY or DDR54) details from JIRA for the customer issue
#Create a work space in US01 correspondingly
#Copy the customer release firmware to CA09 since boards are connected in CA09 -This is done using ./copyfw
#Choose the corresponding board and make changes in test code like any changes in registers if necessary 
#compile and run
#Generate graphs if necessary
#check 'RxDfe eyes clipped on Samsung LP5' in 'systemAnalyst_CA09_test_runners.sh' for continuity

#This example shows for LPDDR54
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients % mkdir lpddr54_2009.amd
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients % cd lpddr54_2009.amd
#rel_vA-2020.09-T-0056931_AMD is the customer release version
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54_2009.amd % p4w -mkwa -code=lpddr54/branches_fw/rel_vA-2020.09-T-0056931_AMD -novwa
#if we get issue like p4w is not found
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54_2009.amd % cd ../lpddr54
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54 % source bootenv
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54 % p4w -update_env
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54 % source bootenv
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54 % cd ../lpddr54_2009.amd
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54_2009.amd % cd pmu_firmware/scripts/
#Check for changes made in revision.py
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54_2009.amd % p4 changes revision.py
	Change 6703985 on 2020/11/20 by delbaere@msip_delbaere_depot_products_lpddr54_branches_fw_rel_vA_2020_09_T_0056931_AMD__rel_vA_2020_09_T_0056931_AMD_0 'Change Revision to 0x20b1 to al'
	Change 6703756 on 2020/11/20 by delbaere@msip_delbaere_depot_products_lpddr54_branches_fw_rel_vA_2020_09_T_0056931_AMD__rel_vA_2020_09_T_0056931_AMD_0 'Update revision '
	Change 6595246 on 2020/11/06 by bperkins@msip_bperkins_lpddr54_rel_vA_2020_09_T_0056931_AMD_0 'Update revision'
	Change 6559925 on 2020/10/30 by bperkins@msip_bperkins_lpddr54_branches_fw 'Create AMD branch '
#copy paste from Christian's workspace
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54_2009.amd % evim /remote/us01sgnfs00017/users/delbaere/clients/lpddr54/pmu_firmware/scripts/revision.py
#check for the revision
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54_2009.amd % st revision.py
#change the revision in revision.py to 0x20b0
#revision.py
	#!/usr/bin/env python
	import time
	# New FW Revision System
	# Must update this value when releasing - WITHIN THE FIRMWARE RELEASE BRANCH, AFTER IT IS CREATED
	# 
	# *** New numbering scheme from Yiannis: ***
	# revision number is an encoding of the year, the month, and the release within the month
	# YYVM - "YY" = 2 digit year, "V" = sequential release within the month, "M" = the hex encoding of the month number

	# ALWAYS Keep the "0xff00" value in the dev branch 

	Revision = 0x20b0

#Describe a Changelist
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54_2009.amd/pmu_firmware/scripts % p4 describe 6595246
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54_2009.amd/pmu_firmware/scripts % cd ../..
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54_2009.amd % source bootenv
#Update to particular change set like 6595246 in customer release
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54_2009.amd % p4w -update_env -changelist 6595246
#compile
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54_2009.amd % make fwtb
#The following code is copied from Christian's path
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54_2009.amd % evim /remote/us01sgnfs00017/users/delbaere/clients/lpddr54/pmu_firmware/scripts/printrev.py
#copy paste christian's code to my workspace
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54_2009.amd % evim pmu_firmware/scripts/printrev.py
#printrev.py
	#!/usr/bin/env python
	import argparse
	import revision
	import os

	#-------------------------------------------------
	# Code for auto-generating revision.c
	#-------------------------------------------------
	parser = argparse.ArgumentParser(description='Run production ddr3/ddr4 code training simulation')
	parser.add_argument('--version', '-v', action="store_true",  help='Print only version string in hex instead of C code')
	args = parser.parse_args()

	print("#ifndef PMU_CONFIG_H")
	print("#define PMU_CONFIG_H")
	print("")

	if args.version:
	    print("{:04x}".format(revision.Revision), end='')
	else:
	    print('#define PMU_REVISION 0x{:04x}'.format(revision.Revision))
	    print(os.popen('generate_internal_fw_revision.pl').read())

	print("#endif")
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54_2009.amd % ssh -X us01odcvde12441
	Authentication failed.
#Check for revision history
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54_2009.amd % p4 changes -m10 ...
	Change 6703985 on 2020/11/20 by delbaere@msip_delbaere_depot_products_lpddr54_branches_fw_rel_vA_2020_09_T_0056931_AMD__rel_vA_2020_09_T_0056931_AMD_0 'Change Revision to 0x20b1 to al'
	Change 6703756 on 2020/11/20 by delbaere@msip_delbaere_depot_products_lpddr54_branches_fw_rel_vA_2020_09_T_0056931_AMD__rel_vA_2020_09_T_0056931_AMD_0 'Update revision '
	Change 6703744 on 2020/11/20 by delbaere@msip_delbaere_depot_products_lpddr54_branches_fw_rel_vA_2020_09_T_0056931_AMD__rel_vA_2020_09_T_0056931_AMD_0 'add mb bit to control behavior '
	Change 6703737 on 2020/11/20 by delbaere@msip_delbaere_depot_products_lpddr54_branches_fw_rel_vA_2020_09_T_0056931_AMD__rel_vA_2020_09_T_0056931_AMD_0 'P80001562-88772 estimate the Rx'
	Change 6703730 on 2020/11/20 by delbaere@msip_delbaere_depot_products_lpddr54_branches_fw_rel_vA_2020_09_T_0056931_AMD__rel_vA_2020_09_T_0056931_AMD_0 'Null integrate 6633753 since it'
	Change 6703722 on 2020/11/20 by delbaere@msip_delbaere_depot_products_lpddr54_branches_fw_rel_vA_2020_09_T_0056931_AMD__rel_vA_2020_09_T_0056931_AMD_0 'P80001562-81965 - LP5 RxDfe eye'
	Change 6703716 on 2020/11/20 by delbaere@msip_delbaere_depot_products_lpddr54_branches_fw_rel_vA_2020_09_T_0056931_AMD__rel_vA_2020_09_T_0056931_AMD_0 'P80001562-88037 add switch for '
	Change 6703711 on 2020/11/20 by delbaere@msip_delbaere_depot_products_lpddr54_branches_fw_rel_vA_2020_09_T_0056931_AMD__rel_vA_2020_09_T_0056931_AMD_0 '       P80001562-87703 - Eye co'
	Change 6703700 on 2020/11/20 by delbaere@msip_delbaere_depot_products_lpddr54_branches_fw_rel_vA_2020_09_T_0056931_AMD__rel_vA_2020_09_T_0056931_AMD_0 ' remove DRAM DCA from loop2 Int'
	Change 6595246 on 2020/11/06 by bperkins@msip_bperkins_lpddr54_rel_vA_2020_09_T_0056931_AMD_0 'Update revision'
#We want to get details of specific revision
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54_2009.amd % p4 describe -s 6703744
	Change 6703744 by delbaere@msip_delbaere_depot_products_lpddr54_branches_fw_rel_vA_2020_09_T_0056931_AMD__rel_vA_2020_09_T_0056931_AMD_0 on 2020/11/20 10:56:57

		add mb bit to control behavior for rxClk estimating 
		misc[4]=0 seed from trained data. misc[4]=1 seed from estimate 
		
		integrate //depot/products/lpddr54/dev/...@=6673284 

	Affected files ...

	... //depot/products/lpddr54/branches_fw/rel_vA-2020.09-T-0056931_AMD/pmu_firmware/common_api/eddrphy_PMU_MsgBlock.xls#4 integrate
	... //depot/products/lpddr54/branches_fw/rel_vA-2020.09-T-0056931_AMD/pmu_firmware/common_api/mnPmuSramMsgBlock.h#4 integrate
	... //depot/products/lpddr54/branches_fw/rel_vA-2020.09-T-0056931_AMD/pmu_firmware/production_code/pmu_dca.c#3 integrate
	... //depot/products/lpddr54/branches_fw/rel_vA-2020.09-T-0056931_AMD/pmu_firmware/production_code/pmu_rdDQS_wrDQ.c#7 integrate
	... //depot/products/lpddr54/branches_fw/rel_vA-2020.09-T-0056931_AMD/pmu_firmware/production_code/pmu_util.c#7 integrate
	... //depot/products/lpddr54/branches_fw/rel_vA-2020.09-T-0056931_AMD/pmu_firmware/production_code/pmu_util.h#3 integrate
#To get all revision history
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54_2009.amd % p4 changes -m10 -l ...
	Change 6703985 on 2020/11/20 by delbaere@msip_delbaere_depot_products_lpddr54_branches_fw_rel_vA_2020_09_T_0056931_AMD__rel_vA_2020_09_T_0056931_AMD_0

		Change Revision to 0x20b1 to allow for more values

	Change 6703756 on 2020/11/20 by delbaere@msip_delbaere_depot_products_lpddr54_branches_fw_rel_vA_2020_09_T_0056931_AMD__rel_vA_2020_09_T_0056931_AMD_0

		Update revision

	Change 6703744 on 2020/11/20 by delbaere@msip_delbaere_depot_products_lpddr54_branches_fw_rel_vA_2020_09_T_0056931_AMD__rel_vA_2020_09_T_0056931_AMD_0

		add mb bit to control behavior for rxClk estimating 
		misc[4]=0 seed from trained data. misc[4]=1 seed from estimate 
		
		integrate //depot/products/lpddr54/dev/...@=6673284 

	Change 6703737 on 2020/11/20 by delbaere@msip_delbaere_depot_products_lpddr54_branches_fw_rel_vA_2020_09_T_0056931_AMD__rel_vA_2020_09_T_0056931_AMD_0

		P80001562-88772 estimate the RxClk start training value using the median of the trained values
		 integrate //depot/products/lpddr54/dev/...@=6672049

	Change 6703730 on 2020/11/20 by delbaere@msip_delbaere_depot_products_lpddr54_branches_fw_rel_vA_2020_09_T_0056931_AMD__rel_vA_2020_09_T_0056931_AMD_0

		Null integrate 6633753 since it was undone by the subsequent chang
		 p4 integ //depot/products/lpddr54/dev/...@=6633753
		 p4 resolve -ay

	Change 6703722 on 2020/11/20 by delbaere@msip_delbaere_depot_products_lpddr54_branches_fw_rel_vA_2020_09_T_0056931_AMD__rel_vA_2020_09_T_0056931_AMD_0

		P80001562-81965 - LP5 RxDfe eyes are clipped at 6400 MT/s
		 - improved performance fix by finding eye edges outside of the vref loop
		
		integrate //depot/products/lpddr54/dev/...@=6652745

	Change 6703716 on 2020/11/20 by delbaere@msip_delbaere_depot_products_lpddr54_branches_fw_rel_vA_2020_09_T_0056931_AMD__rel_vA_2020_09_T_0056931_AMD_0

		P80001562-88037 add switch for 4ui scan or 2 ui scan in Misc[3]
		 integrate //depot/products/lpddr54/dev/...@=6610842

	Change 6703711 on 2020/11/20 by delbaere@msip_delbaere_depot_products_lpddr54_branches_fw_rel_vA_2020_09_T_0056931_AMD__rel_vA_2020_09_T_0056931_AMD_0

		       P80001562-87703 - Eye compounding x-anchor offset is incorrect for DFE history mode
		        - correct problem where the x-anchor offset value calculation had two terms reversed,
		         thus doubling the skew between prev 0 and prev 1 trained values instead of eliminating it
		
		   Integrate //depot/products/lpddr54/dev/...@=6595669

	Change 6703700 on 2020/11/20 by delbaere@msip_delbaere_depot_products_lpddr54_branches_fw_rel_vA_2020_09_T_0056931_AMD__rel_vA_2020_09_T_0056931_AMD_0

		 remove DRAM DCA from loop2
		Integrate //depot/products/lpddr54/dev/...@=6401053 

	Change 6595246 on 2020/11/06 by bperkins@msip_bperkins_lpddr54_rel_vA_2020_09_T_0056931_AMD_0

		Update revision