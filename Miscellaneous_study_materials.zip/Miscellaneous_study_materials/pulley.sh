pranavp@us01odcvde40200:/remote/us01sgnfs00017/users/pranavp/clients/lp5_std % mkdir PuLLey
pranavp@us01odcvde40200:/remote/us01sgnfs00017/users/pranavp/clients/lp5_std % cd ..
pranavp@us01odcvde40200:/remote/us01sgnfs00017/users/pranavp/clients % mkdir PuLLey
pranavp@us01odcvde40200:/remote/us01sgnfs00017/users/pranavp/clients % cd PuLLey/
pranavp@us01odcvde40200:/remote/us01sgnfs00017/users/pranavp/clients/PuLLey % echo $P4CONFIG
# add the following lines 
P4PORT=p4p-us01:1999
P4CLIENT=msip_pranavp_pulley_us01
pranavp@us01odcvde40200:/remote/us01sgnfs00017/users/pranavp/clients/PuLLey % p4 client
# add the following
View:
	//depot/products/PuLLey/... //msip_pranavp_pulley_us01/...
	//depot/products/ddr54/project/phy_plls/.../opt_pll_settings/... //msip_pranavp_pulley_us01/phy_plls/ddr54/.../opt_pll_settings/...
	//depot/products/ddr54/project/phy_plls/opt_pll_setting_map/... //msip_pranavp_pulley_us01/phy_plls/ddr54/opt_pll_setting_map/...
	//depot/products/ddr54/dev/tools/pll_csv_gen.pl //msip_pranavp_pulley_us01/tools/pll_csv_gen.pl
	//depot/products/lpddr5x_ddr5_phy/phy_plls/opt_settings_map/... //msip_pranavp_pulley_us01/phy_plls/lpddr5x_ddr5_phy/opt_pll_setting_map/...
pranavp@us01odcvde40200:/remote/us01sgnfs00017/users/pranavp/clients/PuLLey % p4 sync

# ddr54 -> lpddr5x_ddr5_phy for LP5X
pranavp@us01odcvde40200:/remote/us01sgnfs00017/users/pranavp/clients/PuLLey % cd phy_plls/
pranavp@us01odcvde40200:/remote/us01sgnfs00017/users/pranavp/clients/PuLLey/phy_plls % ls
ddrphy_pll_gf12lpp18  ddrphy_pll_ss7hpp18  ddrphy_pll_tsmc12ffc18  ddrphy_pll_tsmc5ffp12  ddrphy_pll_tsmc7ff18       opt_pll_setting_map
ddrphy_pll_ss10lpp18  ddrphy_pll_ss7lpp18  ddrphy_pll_tsmc16ffc18  ddrphy_pll_tsmc6ff18   ddrphy_pll_tsmc7ff_plus18
pranavp@us01odcvde40200:/remote/us01sgnfs00017/users/pranavp/clients/PuLLey/phy_plls % rm -rf ddrphy_pll*

pranavp@us01odcvde40200:/remote/us01sgnfs00017/users/pranavp/clients/PuLLey % python dev/PuLLey.py 
usage: PuLLey.py [-h] -m MAPPINGS -s OPTIMAL_SETTINGS -o OUTPUT_FILE
PuLLey.py: error: the following arguments are required: -m/--mappings, -s/--optimal_settings, -o/--output_file
# MAPPINGS - mapping file (-m) which together with unmapped file (-s) when fed into pulley script generate mapped file (-o) (output file)
# unmapped file (-s) is the row file from the data book
pranavp@us01odcvde40200:/remote/us01sgnfs00017/users/pranavp/clients/PuLLey % python dev/PuLLey.py -m phy_plls/ddr54/opt_pll_setting_map/ddr54_pll_setting_map.csv -s phy_plls/ddr54/ddrphy_pll_tsmc7ff18/1.20a/views/opt_pll_settings/ddr54_pll_settings_tsmc7ff_BW_2MHz.csv -o test.csv
CSV file created: test.csv

# After getting test.csv file; add that file to system analyst 
# Path: tech/ddr5_std/pllSettings/TC_97_x2.csv

## To delete the client
pranavp@us01odcvde40200:/remote/us01sgnfs00017/users/pranavp/clients/PuLLey % p4 client -d pranavp_pulley_us01

# To get the client from Christian
pranavp@us01odcvde40200:/remote/us01sgnfs00017/users/pranavp/clients/PuLLey % p4 client -o msip_delbaere_PuLLey_us01

# A Perforce Client Specification.
#
#  Client:      The client name.
#  Update:      The date this specification was last modified.
#  Access:      The date this client was last used in any way.
#  Owner:       The Perforce user name of the user who owns the client
#               workspace. The default is the user who created the
#               client workspace.
#  Host:        If set, restricts access to the named host.
#  Description: A short description of the client (optional).
#  Root:        The base directory of the client workspace.
#  AltRoots:    Up to two alternate client workspace roots.
#  Options:     Client options:
#                      [no]allwrite [no]clobber [no]compress
#                      [un]locked [no]modtime [no]rmdir
#  SubmitOptions:
#                      submitunchanged/submitunchanged+reopen
#                      revertunchanged/revertunchanged+reopen
#                      leaveunchanged/leaveunchanged+reopen
#  LineEnd:     Text file line endings on client: local/unix/mac/win/share.
#  Type:        Type of client: writeable/readonly/graph/partitioned.
#  ServerID:    If set, restricts access to the named server.
#  View:        Lines to map depot files into the client workspace.
#  ChangeView:  Lines to restrict depot files to specific changelists.
#  Stream:      The stream to which this client's view will be dedicated.
#               (Files in stream paths can be submitted only by dedicated
#               stream clients.) When this optional field is set, the
#               View field will be automatically replaced by a stream
#               view as the client spec is saved.
#  StreamAtChange:  A changelist number that sets a back-in-time view of a
#                   stream ( Stream field is required ).
#                   Changes cannot be submitted when this field is set.
#
# Use 'p4 help client' to see more about client views and options.

Client:	msip_delbaere_PuLLey_us01

Update:	2022/01/12 13:31:01

Access:	2023/05/11 11:18:06

Owner:	delbaere

Description:
	Created by delbaere.

Root:	/remote/us01sgnfs00017/users/delbaere/clients/PuLLey

Options:	noallwrite noclobber nocompress unlocked nomodtime normdir

SubmitOptions:	submitunchanged

LineEnd:	local

View:
	//depot/products/PuLLey/... //msip_delbaere_PuLLey_us01/...
	//depot/products/ddr54/project/phy_plls/.../opt_pll_settings/... //msip_delbaere_PuLLey_us01/phy_plls/.../opt_pll_settings/...
	//depot/products/ddr54/project/phy_plls/opt_pll_setting_map/... //msip_delbaere_PuLLey_us01/phy_plls/opt_pll_setting_map/...
	//depot/products/ddr54/dev/tools/pll_csv_gen.pl //msip_delbaere_PuLLey_us01/tools/pll_csv_gen.pl


# The current version of python used
pranavp@us01odcvde40200:/remote/us01sgnfs00017/users/pranavp/clients/PuLLey % which python
/global/freeware/Linux/RHEL7/python-3.6.3/bin/python

# List the modules that are loaded
pranavp@us01odcvde40200:/remote/us01sgnfs00017/users/pranavp/clients/PuLLey % module list
Currently Loaded Modulefiles:
  1) grd/msem                        4) ct/2020.12-SP4-1                7) mwdt/2021.03                   10) python/3.6.3                   13) msip_shell_uge_utils/2023.04
  2) vcs/2021.09-SP2                 5) xa/2021.09-SP2-1                8) gcc/4.7.2-el6                  11) msip_shell_msem_utils/2021.10  14) vcstatic/2021.09-SP1
  3) verdi/2021.09-SP2               6) certitude/2021.09-SP2           9) spyglass/2021.09-SP1           12) cad_lookup/2022.03             15) gmake/4.2




