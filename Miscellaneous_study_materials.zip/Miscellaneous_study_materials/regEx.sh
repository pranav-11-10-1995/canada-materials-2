#Only line containing SMB Write or End of will remain. Rest of the lines will be deleted
select regular expression on sublime text
Find: ^(?!(SMB Write|End of)).*\n
Replace: <nothing>
click replace all

#Delete the line containing SMB Write
Find: .*SMB Write.*\r?\n
Replace: <nothing>
click replace all

#To remove the empty lines
Find: ^(?:[\t ]*(?:\r?\n|\r))+
Replace: <empty>
click replace all

#Give a new line before matching keyword
Find: PMU5
Replace: \nPMU5
click replace all