us01odcvde17752:pranavp>cd /remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_Copy/ 
us01odcvde17752:pran
#Rough check
#split the coverity defects based on - binary change, no binary change, later, not sure
#Run tools/binDiff to find whether binary changes or not
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % qsh -P iheavy -l os_distribution=centos -now n
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % Konsole
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % make phyinit
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % make clean
#if we just make changes in pmu_firmware code in comboPHY  
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % make coverityFwLpddr5x
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % make coverityCheck # not necessary. just in case
(or)
#full coverity
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % make coverity
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % make coverityCheck # not necessary. just in case
# To waive any new Coverity errors that are being intravp>cd /remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy/ 
#Update the environment to the latest changes:- Only once in a day - start of the day:
  us01odcvde17752:pranavp>source bootenv
  us01odcvde17752:pranavp>p4w -update_env
  us01odcvde17752:pranavp>source bootenv
oduced.  Please use this sparingly.  
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % make coverityUpdateWaivers
#one single shot
#COMBO_PHY
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % make phyinit && make clean && make coverity
#LP5_STD
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % make d2crtl phyinit LP54X=1 && make clean && make coverity

#View coverity report: 
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % firefox /remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy/build/coverity/html/index.html

# Shelve description: LP5 STD: Coverity MISRA 10.3 in eye_export_lib.c (27_10_2022)
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % p4 shelve
(or)
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % p4 shelve -f -c 8407746
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % p4 revert ...
#Run tools/binDiff again with coverity check changes
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % tools/binDiff -s 8407746
#If there is any diff, run Simulation -> answer 'y' to the question: "Do u want to run the regression?"
#To check what job is running
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % qstat
#Running time of the sim is around a day
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % find . -iname FAILED.txt #open in konsole terminal for better view
#In konsole -> cd /remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy/
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % source bootenv
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % tools/binDiff -s 8407746
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % p4 shelve
(or)
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % p4 shelve -f -c 8407746
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % p4 revert ...
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % find . -iname PASSED.txt
#If no new error exists, its safe to stage - we can change the date in the link
  https://lamp/~us8wtool/live/index.cgi/daily/27-10-21?product=combo_lpddr
#Staging the changes
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % evim change_description.txt
  input file name, author name, change description and date modified
  ADD review and jira link to that
  #review tage as well as shown below
  #review-8973403
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % p4 sync
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % p4 resolve 
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % p4w -stage -mf change_description.txt 


#diff the obj files
#Remove the previously existing .dis files
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % rm -r out1.dis
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % rm -r out2.dis
#Change the name of the object file to the one you are working
#Search for the function name in the assemby file to figure out what has changed
#we can two functions top() and bottom() called in beginning and end of the change we have made - 
#This is done to identify the location of the change we have made
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % elfdumpac -T -o out1.dis build_control/c/fw/lpddr5x/pmu_train.o
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % elfdumpac -T -o out2.dis build_edits/c/fw/lpddr5x/pmu_train.o
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % vimdiff out1.dis out2.dis
#For diags - different folder for diags
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % elfdumpac -T -o out1.dis build_control/c/fw/lpddr5x_diags/pmu_diag.o
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % elfdumpac -T -o out2.dis build_edits/c/fw/lpddr5x_diags/pmu_diag.o

Note:
Coverity Site for lpddr5x std product:

https://us01-coverity-sg.internal.synopsys.com:8443/reports.htm#dQUALITY/p10045



How to run a Coverity build in your LPDDR5x STD product workspace:

 # option 1: run full Coverity check
 # this automatically compares your build against the waivers
 make coverity
 # option 2: run Coverity on subtargets
 # NOTE: these don't check against waivers by default

 # all LPDDR firmware
 make coverityFw

 # one specific protocol
 make coverityFwLpddr5x
 make coverityFwLpddr5
 make coverityFwLpddr4x

 # diags only
 make coverityDiags

 # compare your build against waivers
 make coverityCheck
How to get past the release_gate check and update the waivers if you cannot solve all of the errors in your code on your own:

# first
make coverity
# then
make coverityUpdateWaivers
# finally, include the additional files that are opened for edit in your p4w stage

# TKDIFF
tkdiff <file> — to compare the local version of the given file to the most recent version in the CVS/Subversion repository

# To make p4 diff work like tkdiff
# Method 1
env P4DIFF=tkdiff p4 diff

# Method 2
p4 set P4DIFF="/global/freeware/Linux/2.X/tkdiff-4.3.5/tkdiff"

# Coverity Server
https://us01-coverity8-sg.internal.synopsys.com:8443/ -> configuration/system/LDAP configuration -> Bind password # This password has to be changed in 90 days
# login
username: admin
password: synopsys
(or)
username: pranavp
password: <my system password>
# Getting the authorisation key
pranavp@us01odcvde40200:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5_std_copy % cd ~
pranavp@us01odcvde40200:~ % cd .ssh/
pranavp@us01odcvde40200:~/.ssh % ls
authorized_keys  id_rsa  id_rsa.pub  known_hosts
pranavp@us01odcvde40200:~/.ssh % evim authorized_keys # Gave it to Christian for approval
pranavp@us01odcvde40200:~/.ssh % ssh -l svc-bfmgr us01-coverity-sg
# Press ctrl+D to log out
svc-bfmgr@us01-coverity-sg:~ $ logout




# Edit the changes to build files that run coverity in SA

# Open this file 
//depot/products/SystemAnalyst/hw_reg/product_build.sh
Inside which we can find the path to US01 and CA09
HW_REG_DIR=/remote/us01sgnfs00290/ddrphy_firmware/svc-bfmgr/hw_reg
REMOTE_HW_REG_DIR=/remote/ca09dwp004/ddrphy_firmware/svc-bfmgr/hw_reg

pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/systemAnalyst4 % cd ..
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp % mkdir hw_reg_1
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp % cd hw_reg_1/
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/hw_reg_1 % cp ../systemAnalyst4/P4CONFIG .
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/hw_reg_1 % setenv P4EDITOR 'evim -f'
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/hw_reg_1 % evim P4CONFIG
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/hw_reg_1 % p4 client

View:
  //depot/products/SystemAnalyst/hw_reg/... //msip_pranavp_hw_reg_1_ca09/...

Client msip_pranavp_hw_reg_1_ca09 saved.
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/hw_reg_1 % p4 sync -f
//depot/products/SystemAnalyst/hw_reg/build_ddr54_daily.csh#4 - deleted as /remote/ca09dwp004/ddrphy_firmware/pranavp/hw_reg_1/build_ddr54_daily.csh
//depot/products/SystemAnalyst/hw_reg/build_lpddr54_rel_vA-2020.04_daily.csh#3 - deleted as /remote/ca09dwp004/ddrphy_firmware/pranavp/hw_reg_1/build_lpddr54_rel_vA-2020.04_daily.csh
//depot/products/SystemAnalyst/hw_reg/build_lpddr5x_ddr5_phy_daily.csh#4 - deleted as /remote/ca09dwp004/ddrphy_firmware/pranavp/hw_reg_1/build_lpddr5x_ddr5_phy_daily.csh
//depot/products/SystemAnalyst/hw_reg/build.sh#26 - added as /remote/ca09dwp004/ddrphy_firmware/pranavp/hw_reg_1/build.sh
//depot/products/SystemAnalyst/hw_reg/build_ddr54_dev_daily.csh#6 - added as /remote/ca09dwp004/ddrphy_firmware/pranavp/hw_reg_1/build_ddr54_dev_daily.csh
//depot/products/SystemAnalyst/hw_reg/build_ddr54_tc803_daily.csh#2 - added as /remote/ca09dwp004/ddrphy_firmware/pranavp/hw_reg_1/build_ddr54_tc803_daily.csh
//depot/products/SystemAnalyst/hw_reg/build_ddr5_std_daily.csh#1 - added as /remote/ca09dwp004/ddrphy_firmware/pranavp/hw_reg_1/build_ddr5_std_daily.csh
//depot/products/SystemAnalyst/hw_reg/build_lpddr54_daily.csh#11 - added as /remote/ca09dwp004/ddrphy_firmware/pranavp/hw_reg_1/build_lpddr54_daily.csh
//depot/products/SystemAnalyst/hw_reg/build_lpddr5x_mphy_daily.csh#6 - added as /remote/ca09dwp004/ddrphy_firmware/pranavp/hw_reg_1/build_lpddr5x_mphy_daily.csh
//depot/products/SystemAnalyst/hw_reg/build_lpddr5x_mphy_misrac_7_daily.csh#2 - added as /remote/ca09dwp004/ddrphy_firmware/pranavp/hw_reg_1/build_lpddr5x_mphy_misrac_7_daily.csh
//depot/products/SystemAnalyst/hw_reg/build_lpddr5x_std_daily.csh#2 - added as /remote/ca09dwp004/ddrphy_firmware/pranavp/hw_reg_1/build_lpddr5x_std_daily.csh
//depot/products/SystemAnalyst/hw_reg/build_lpddr5x_std_phyinit_misra_c_daily.csh#1 - added as /remote/ca09dwp004/ddrphy_firmware/pranavp/hw_reg_1/build_lpddr5x_std_phyinit_misra_c_daily.csh
//depot/products/SystemAnalyst/hw_reg/build_phy2_daily.csh#4 - added as /remote/ca09dwp004/ddrphy_firmware/pranavp/hw_reg_1/build_phy2_daily.csh
//depot/products/SystemAnalyst/hw_reg/product_build.sh#82 - added as /remote/ca09dwp004/ddrphy_firmware/pranavp/hw_reg_1/product_build.sh
//depot/products/SystemAnalyst/hw_reg/release_expired_reservations.sh#7 - added as /remote/ca09dwp004/ddrphy_firmware/pranavp/hw_reg_1/release_expired_reservations.sh
//depot/products/SystemAnalyst/hw_reg/run_ate_tests.sh#5 - added as /remote/ca09dwp004/ddrphy_firmware/pranavp/hw_reg_1/run_ate_tests.sh
//depot/products/SystemAnalyst/hw_reg/run_fw_tests.sh#5 - added as /remote/ca09dwp004/ddrphy_firmware/pranavp/hw_reg_1/run_fw_tests.sh
//depot/products/SystemAnalyst/hw_reg/run_fw_validation.sh#3 - added as /remote/ca09dwp004/ddrphy_firmware/pranavp/hw_reg_1/run_fw_validation.sh
//depot/products/SystemAnalyst/hw_reg/run_measure_code_sizes.sh#2 - added as /remote/ca09dwp004/ddrphy_firmware/pranavp/hw_reg_1/run_measure_code_sizes.sh
//depot/products/SystemAnalyst/hw_reg/run_p4_sync.sh#4 - added as /remote/ca09dwp004/ddrphy_firmware/pranavp/hw_reg_1/run_p4_sync.sh
//depot/products/SystemAnalyst/hw_reg/run_sasp_tests.sh#2 - added as /remote/ca09dwp004/ddrphy_firmware/pranavp/hw_reg_1/run_sasp_tests.sh
//depot/products/SystemAnalyst/hw_reg/run_timing_tests.sh#3 - added as /remote/ca09dwp004/ddrphy_firmware/pranavp/hw_reg_1/run_timing_tests.sh
//depot/products/SystemAnalyst/hw_reg/setup_sa_env.sh#3 - added as /remote/ca09dwp004/ddrphy_firmware/pranavp/hw_reg_1/setup_sa_env.sh
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/hw_reg_1 % ls
build_ddr54_dev_daily.csh     build_lpddr5x_mphy_misrac_7_daily.csh        P4CONFIG                         run_fw_tests.sh            run_timing_tests.sh
build_ddr54_tc803_daily.csh   build_lpddr5x_std_daily.csh                  P4CONFIG~                        run_fw_validation.sh       setup_sa_env.sh
build_ddr5_std_daily.csh      build_lpddr5x_std_phyinit_misra_c_daily.csh  product_build.sh                 run_measure_code_sizes.sh
build_lpddr54_daily.csh       build_phy2_daily.csh                         release_expired_reservations.sh  run_p4_sync.sh
build_lpddr5x_mphy_daily.csh  build.sh                                     run_ate_tests.sh                 run_sasp_tests.sh

#If u want to edit any files 
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/hw_reg_1 % p4 edit build_lpddr5x_std_*
//depot/products/SystemAnalyst/hw_reg/build_lpddr5x_std_daily.csh#2 - opened for edit
//depot/products/SystemAnalyst/hw_reg/build_lpddr5x_std_phyinit_misra_c_daily.csh#1 - opened for edit

# Log in to svc-bfmgr (nightly build user) and then p4 sync to sync the changes made to pranavp to svc-bfmgr (to get reflected in nightly build)
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/hw_reg_1 % ssh -l svc-bfmgr ca09lab-bfmgr1-lnx
Last login: Tue Aug 29 11:10:52 2023 from ca09lab-bfmgr1-lnx.internal.synopsys.com
  Linux vmlinuz-2.6.32-696.30.1.el6.x86_64
  OS:        CentOS6.9
        Hostname:  ca09lab-bfmgr1-lnx (delbaere)
        Location:  CA09
        CPU:  8 x 3601.000 MHz, Intel(R)Xeon(R) (1 socket, 4 core, HT) 
        Memory:  31 GB RAM, 62 GB Swap
        QSC:    NOT-QSC
  Warning:  This machine binding LDAP instead of NIS
[svc-bfmgr@ca09lab-bfmgr1-lnx ~]$ cd /remote/ca09dwp004/ddrphy_firmware/svc-bfmgr/hw_reg
[svc-bfmgr@ca09lab-bfmgr1-lnx hw_reg]$ p4 sync
//depot/products/SystemAnalyst/hw_reg/build_lpddr5x_std_daily.csh#3 - updating /remote/ca09dwp004/ddrphy_firmware/svc-bfmgr/hw_reg/build_lpddr5x_std_daily.csh
//depot/products/SystemAnalyst/hw_reg/build_lpddr5x_std_phyinit_misra_c_daily.csh#2 - updating /remote/ca09dwp004/ddrphy_firmware/svc-bfmgr/hw_reg/build_lpddr5x_std_phyinit_misra_c_daily.csh
[svc-bfmgr@ca09lab-bfmgr1-lnx hw_reg]$ ls
build_ddr54_dev_daily.csh              build_lpddr5x_std_phyinit_misra_c_daily.csh  lpddr5x_mphy_daily               run_fw_tests.sh
build_ddr54_tc803_daily.csh            build_phy2_daily.csh                         lpddr5x_std_daily                run_fw_validation.sh
build_ddr5_std_daily.csh               build.sh                                     P4CONFIG                         run_measure_code_sizes.sh
build_lpddr54_daily.csh                ddr54_dev_daily                              phy2_daily                       run_p4_sync.sh
build_lpddr5x_mphy_daily.csh           ddr5_std_daily                               product_build.sh                 run_sasp_tests.sh
build_lpddr5x_mphy_misrac_7_daily.csh  logs                                         release_expired_reservations.sh  run_timing_tests.sh
build_lpddr5x_std_daily.csh            lpddr54_daily                                run_ate_tests.sh                 setup_sa_env.sh
# Press ctrl+D to log out
[svc-bfmgr@ca09lab-bfmgr1-lnx hw_reg]$ logout
Connection to ca09lab-bfmgr1-lnx closed.


# p4 sync the same changes from SA to US01 to reflect on nightly build
pranavp@us01odcvde40200:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5_std_copy1 % ssh -l svc-bfmgr us01-coverity-sg
Last login: Tue Aug 29 08:13:46 2023 from us01odcvde40200.internal.synopsys.com
      Linux 3.10.0-957.5.1.el7.x86_64 x86_64
      OS:        CentOS Linux release 7.6
      Hostname:  us01-coverity-sg (jserras)
      Location:  HQDC-DC EPG-IP-SG-INFRA
      CPU:       8  x 2900 MHz, Intel Core (8 socket, 1 core, No HT)
      Memory:    31 GB RAM, 8 GB Swap
      QSC:       NOT-QSC
      Comments:
                
      Note: Please do NOT edit this file directly. Use ansible utility to add or delete comment(s). To use ansible utility refer to KBA00008924.

svc-bfmgr@us01-coverity-sg:~ $ cd /remote/us01sgnfs00290/ddrphy_firmware/svc-bfmgr/hw_reg
svc-bfmgr@us01-coverity-sg:/remote/us01sgnfs00290/ddrphy_firmware/svc-bfmgr/hw_reg $ p4 sync
//depot/products/SystemAnalyst/hw_reg/build_lpddr5x_std_daily.csh#3 - updating /remote/us01sgnfs00290/ddrphy_firmware/svc-bfmgr/hw_reg/build_lpddr5x_std_daily.csh
//depot/products/SystemAnalyst/hw_reg/build_lpddr5x_std_phyinit_misra_c_daily.csh#2 - updating /remote/us01sgnfs00290/ddrphy_firmware/svc-bfmgr/hw_reg/build_lpddr5x_std_phyinit_misra_c_daily.csh
svc-bfmgr@us01-coverity-sg:/remote/us01sgnfs00290/ddrphy_firmware/svc-bfmgr/hw_reg $ ls
build_ddr54_dev_daily.csh                    build_phy2_daily.csh  lpddr5x_std_phyinit_misra_c_daily  run_measure_code_sizes.sh
build_ddr54_tc803_daily.csh                  build.sh              P4CONFIG                           run_p4_sync.sh
build_ddr5_std_daily.csh                     ddr54_dev_daily       phy2_daily                         run_sasp_tests.sh
build_lpddr54_daily.csh                      ddr5_std_daily        product_build.sh                   run_timing_tests.sh
build_lpddr5x_mphy_daily.csh                 logs                  release_expired_reservations.sh    setup_sa_env.sh
build_lpddr5x_mphy_misrac_7_daily.csh        lpddr54_daily         run_ate_tests.sh
build_lpddr5x_std_daily.csh                  lpddr5x_mphy_daily    run_fw_tests.sh
build_lpddr5x_std_phyinit_misra_c_daily.csh  lpddr5x_std_daily     run_fw_validation.sh
# Press ctrl+D to log out
svc-bfmgr@us01-coverity-sg:/remote/us01sgnfs00290/ddrphy_firmware/svc-bfmgr/hw_reg $ logout
