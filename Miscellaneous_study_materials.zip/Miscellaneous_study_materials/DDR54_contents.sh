#code changes
#To add structure variables to PMU_SMB_DDR5_t{} which is in pmu_firmware/common_api/mnPmuSramMsgBlock.h
#Please p4 edit the following files
   pmu_firmware/common_api/eddrphy_PMU_MsgBlock.xls  # edit
	pmu_firmware/common_api/mnMsgBlockDumper.c	# edit
	pmu_firmware/common_api/mnMsgBlockDumper.h	# edit
	pmu_firmware/common_api/mnPmuSramMsgBlock.h	# edit
#Add the structure variable in pmu_firmware/common_api/eddrphy_PMU_MsgBlock.xls
#Run pmu_firmware/common_api/makeMessgBlockHeader.py	
#We can see that variable is added the structure in pmu_firmware/common_api/mnPmuSramMsgBlock.h
#Each row corresponds to uint8_t
#If the variable is of size uint16_t, then merge two rows

#DDR54 std
#Before running sim, make sure that workspace is upto date
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/ddr54_std % source bootenv
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/ddr54_std % p4w -update_env
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/ddr54_std % source bootenv
#Compile
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/ddr54_std % make d2crtl phyinit DDR5=1
#Sims
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/ddr54_std % make d2crtl phyinit fwtb_fake DDR5=1
#Staging
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/ddr54_std % p4w -stage -novwa -mf=checkin.log

#Before running sim, make sure that workspace is upto date
1)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/ddr54 % source bootenv
  pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/ddr54 % p4w -update_env
  pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/ddr54 % source bootenv
#compile
2)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/ddr54 % make phyinit && make d2crtl
#Running Sim
#We cannot work on US01ODC for running simulations since it is slow -> we go for test pc -us01msem-32cx720g-386-120
#we can also use iwork instead of iheavy. It is recommended to use iheavy
1)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/ddr54 % qsh -P iheavy -l os_distribution=centos -now n
2)pranavp@us01msem-32cx720g-386-120:~ % qstat.real
job-ID     prior   name       user         state submit/start at     queue                          jclass                         slots ja-task-ID 
------------------------------------------------------------------------------------------------------------------------------------------------
   5940425 0.00105 INTERACTIV pranavp      r     08/16/2021 18:42:12 h@us01msem-32cx720g-1246-011.s 
3)pranavp@us01msem-32cx720g-386-120:~ % konsole #open in konsole terminal for better view
4)In konsole -> cd /remote/us01sgnfs00017/users/pranavp/clients/ddr54_works/
5)pranavp@us01msem-32cx720g-386-120:/remote/us01sgnfs00017/users/pranavp/clients/ddr54 % source bootenv
#hdt_ctrl - verbosity
#nochkresult - not to clog up the terminal
#fwtb_debug - to get more debug info; 0 to turn off
#-diag - to run diag after the training
#num_pstates - running with one pstate
#testname - giving some random test name
#seed - 1234 - input to pseudo random generator - any 32 bit postive value
#-maxerr 10000 - keep the max error high - so that sim won't stop until we exceed 1000 errors - we do this because other errors may not disturb our sim
6)pranavp@us01msem-32cx720g-386-120:/remote/us01sgnfs00017/users/pranavp/clients/ddr54 % cd fw_tb/run
#Sim for internal revision
7)pranavp@us01msem-32cx720g-386-120:/remote/us01sgnfs00017/users/pranavp/clients/ddr54/fw_tb/run %./runfw -nochkresult -dram DDR5 -fwtb_debug 1 -hdt_ctrl 0x4 -dimm udimm -d5misc6_ckdly 1 -swizzle 0 -swap_dbytes 0 -CsPresent 0x1 -num_pstates 1 -sctrl 0x821f -mmisc 6 -mr50 0 -mr0_bl 0 -ovloff -maxerr 10000 -testname pranav_test -seed 1234
8)pranavp@us01msem-32cx720g-386-120:/remote/us01sgnfs00017/users/pranavp/clients/ddr54 % st fw_tb/reg/sim_ddr5_train_ac10d4ch1_tc1_033358_pranav_test_x16_s1234/simv.log
#Sim for Vref CS training for RDIMM and LRDIMM
#pmu_firmware/common_api/mnPmuSramMsgBlock.h -> get the parameters from here to add as arguments to the sim command
#check for CATrainOpt in DDR5 is in mnPmuSramMsgBlock.h
#cross check CATrainOpt in fw_tb/run/runfw 
#[list catrainopt.arg  0xc                                      {CATrainOpt arg}]\
#We can use catrainopt as argument in sim command
#[0] Enable RDIMM/LRDIMM 2D CA training (UDIMM: RFU, must be zero): 1 // 0 for udimm
#[3:2] step size for CS and CA training: [1:0] -> 4 (step size [1:1] -> 8 step size for sim to make time shorter)
#[4] Skip_CA13_during_CAtraining : 1 
#[5] Enable RCD VrefCS training : 1//remove for udimm
#catrainopt = 0x3d //udimm = 0x1C
#Sequence control : sctrl 0xc21f //0x821f for udimm
#we need to set devinit since we have cs/ca training in that
#SequenceCtrl[0] = 1 Run DevInit - Device/PHY initialization. Should always be set
#SequenceCtrl[1] = 1 Run WrLvl - Write leveling
#SequenceCtrl[2] = 1 Run RxEn - Read gate training
#SequenceCtrl[3] = 1 Run RdDQS1D - 1d read dqs training
#SequenceCtrl[4] = 1 Run WrDQ1D - 1d write dq training
#SequenceCtrl[9] = 1 Run MxRdLat - Max read latency training
#SequenceCtrl[15-14] = [1-0] RFU, must be zero
#sim for cs/ca training

#To check for arguments, evim runfw file and search for the arguments
9)pranavp@us01msem-32cx720g-386-120:/remote/us01sgnfs00017/users/pranavp/clients/ddr54/fw_tb/run %./runfw -nochkresult -dram DDR5 -fwtb_debug 1 -hdt_ctrl 0x4 -dimm rdimm -d5misc6_ckdly 1 -swizzle 0 -swap_dbytes 0 -CsPresent 0x1 -num_pstates 1 -sctrl 0xc21f -catrainopt 0x3d -mmisc 6 -mr50 0 -mr0_bl 0 -ovloff -maxerr 10000 -testname pranav_vref_cs_train_rdimm -seed 1234
  pranavp@us01msem-32cx720g-386-120:/remote/us01sgnfs00017/users/pranavp/clients/ddr54/fw_tb/run %./runfw -nochkresult -dram DDR5 -fwtb_debug 1 -hdt_ctrl 0x4 -dimm lrdimm -d5misc6_ckdly 1 -swizzle 0 -swap_dbytes 0 -CsPresent 0x1 -num_pstates 1 -sctrl 0xfe67 -catrainopt 0x3d -mmisc 6 -mr50 0 -mr0_bl 0 -ovloff -maxerr 10000 -testname pranav_vref_cs_train_lrdimm_1 -seed 1234
  pranavp@us01msem-32cx720g-386-120:/remote/us01sgnfs00017/users/pranavp/clients/ddr54/fw_tb/run %./runfw -nochkresult -dram DDR5 -fwtb_debug 1 -hdt_ctrl 0x4 -dimm udimm -d5misc6_ckdly 1 -swizzle 0 -swap_dbytes 0 -CsPresent 0x1 -num_pstates 1 -sctrl 0x821f -catrainopt 0x1c -mmisc 6 -mr50 0 -mr0_bl 0 -ovloff -maxerr 10000 -testname pranav_vref_cs_train_udimm -seed 1234

#Config for UDIMM and RDIMM
UDIMM:
ac6d2ch1   
ac6d4ch1   
ac6d5ch1   
ac10d2ch1  
ac10d4ch1  
ac10d5ch1  
ac14d5ch1  
ac12d4ch2  
ac12d8ch2  
ac12d9ch2  
ac12d10ch2 
ac14d4ch2  
ac14d8ch2  
ac14d9ch2  
ac14d10ch2 

RDIMM:
ac12d4ch2  
ac12d8ch2  
ac12d9ch2  
ac12d10ch2 
ac14d4ch2  
ac14d8ch2  
ac14d9ch2  
ac14d10ch2 

#new
#multi cycle
./runfw -nochkresult -dram DDR5 -fwtb_debug 1 -hdt_ctrl 0x4 -dimm udimm -d5misc6_ckdly 1 -swizzle 0 -swap_dbytes 0 -CsPresent 0x1 -num_pstates 1 -sctrl 0x8001 -catrainopt 0x1c -mmisc 6 -mr50 0 -mr2 0x84 -mr0_bl 0 -ovloff -maxerr 10000 -ddrxwidth x8 -testname pranav_diag_cs_udimm_mr2_84_multi_cycle -seed 1234 -diag -diag_static_msgblk_file ../testbench/inc/diag_tests/diag_new
#single cycle
./runfw -nochkresult -dram DDR5 -fwtb_debug 1 -hdt_ctrl 0x5 -dimm udimm -d5misc6_ckdly 1 -swizzle 0 -swap_dbytes 0 -CsPresent 0x1 -num_pstates 1 -sctrl 0x8001 -catrainopt 0x1c -mmisc 6 -mr50 0 -mr2 0x94 -mr0_bl 0 -ovloff -maxerr 10000 -ddrxwidth x8 -testname pranav_diag_cs_udimm_mr2_94_single_cycle_hdtctrl_5_vincent_corrected_x8 -seed 1234 -diag -diag_static_msgblk_file ../testbench/inc/diag_tests/diag_new

#sim for 2 channels
-cfg ac12d4ch2 # ac12 is anib value for 2 channels d4 is dbyte 4 (check in phy databook and ch2 -> 2 channels
./runfw -nochkresult -dram DDR5 -fwtb_debug 1 -hdt_ctrl 0x5 -cfg ac12d4ch2 -dimm udimm -d5misc6_ckdly 1 -swizzle 0 -swap_dbytes 0 -CsPresent 0x1 -num_pstates 1 -sctrl 0x8001 -catrainopt 0x1c -mmisc 6 -mr50 0 -mr2 0x94 -mr0_bl 0 -ovloff -maxerr 10000 -ddrxwidth x8 -testname pranav_diag_cs_eye_udimm_channel_2_no_eye_issue -seed 1234 -diag -diag_static_msgblk_file ../testbench/inc/diag_tests/diag_new


./runfw -dram DDR5 -fwtb_debug 1 -hdt_ctrl 0x5 -dimm rdimm -d5misc6_ckdly 1 -swizzle 0 -swap_dbytes 0 -CsPresent 0x1 -num_pstates 1 -sctrl 0x8001 -catrainopt 0x38 -mmisc 6 -mr50 0 -mr0_bl 0  -maxerr 10000 -testname pranav_diag_ca_train -seed 1234 -diag -diag_static_msgblk_file ../testbench/inc/diag_tests/diag_new

#CA UDIMM (20/10/2022)
./runfw -dram DDR5 -fwtb_debug 1 -hdt_ctrl 0x5 -dimm udimm -d5misc6_ckdly 1 -swizzle 0 -swap_dbytes 0 -CsPresent 0x1 -num_pstates 1 -sctrl 0x8001 -catrainopt 0x3d -mmisc 6 -mr50 0 -mr2 0x94 -mr0_bl 0  -maxerr 10000 -ddrxwidth x8 -testname pranav_diag_ca_udimm_24_10_22_x8 -seed 1234 -diag -diag_static_msgblk_file ../testbench/inc/diag_tests/diag_new


# Diag FWTB:
# Use diag_apb_config to add new testNumbers into FWTB
pranavp@us01msem-32cx720g-386-120:/remote/us01sgnfs00017/users/pranavp/clients/ddr54 % p4 edit fw_tb/testbench/inc/diag_apb_config
# this is the file that contains the sample commands run by the diag regressions
pranavp@us01msem-32cx720g-386-120:/remote/us01sgnfs00017/users/pranavp/clients/ddr54 % p4 edit fw_tb/etc/diag.txt
# -delay zero (To make it run faster)
# mr50 0 (we don't support CRC in diag)
# -mr0_bl 0 (only burst length of 16 is supported in diag)
# -nofsbd (rmove this for diag)
# -repeat 5 (To repeat the test 5 times)
# -regr (To randomize more fields; can be removed to make the regression run faster)
# ac6d4ch1 is for UDIMM only; use it if u want to run sim faster since it have only 1 channel
# fwtb_debug 1 to see fw_tb debug messages; 0 will turn off the debug messages
# -compress is to save some space
#Do make clean 
#make phyinit
#make d2crtl
#cd pmu_firmware/Diag 
#make
# check in apb_config.sv to find the default value for vrefCA and vrefCS
# [phyinit_print_dat] mb_DDR5U_1D[0].MR11_A0 = 0x0 -> VrefCA
#  [phyinit_print_dat] mb_DDR5U_1D[0].MR12_A0 = 0x80 -> VrefCS
${REPO_PATH}/fw_tb/run/runfw -dram DDR5 -cfg ac6d4ch1 -fwtb_debug 1 -diag -delay zero -dimm udimm -d5misc6_ckdly 1 -swizzle 0 -swap_dbytes 0 -CsPresent 0x1 -num_pstates 1 -sctrl 0x821f -mmisc 6 -mr50 0 -mr0_bl 0 -min_diag_rand -testname fwtb_diag_23_11_22
#To skip the training (only run devinit) - reduces the time drastically. can be used to check the code for errors
${REPO_PATH}/fw_tb/run/runfw -dram DDR5 -cfg ac6d4ch1 -delay zero -fwtb_debug 1 -diag -dimm udimm -d5misc6_ckdly 1 -swizzle 0 -swap_dbytes 0 -CsPresent 0x1 -num_pstates 1 -mmisc 6 -mr50 0 -mr0_bl 0 -min_diag_rand -testname fwtb_diag_03_01_23_1 -phyinit_mode devinit
# -d5cscaskew 1 - different delay for CA lines for different ranks (To simulate error case)
# -d5cscaskew 0 - unique delay for all CA lines
# -delay rand to give random delay and check
${REPO_PATH}/fw_tb/run/runfw -dram DDR5 -cfg ac12d4ch2 -delay rand -d5cscaskew 1 -catrainopt 0x3d -fwtb_debug 1 -diag -dimm udimm -d5misc6_ckdly 1 -swizzle 0 -swap_dbytes 0 -CsPresent 0x1 -num_pstates 1 -sctrl 0x821f -mmisc 6 -mr50 0 -mr0_bl 0 -min_diag_rand -testname fwtb_diag_13_12_22_1

# 1N and 2N mode
# setDefault.c
    uint8_t mode1N               = 1; # 1N mode or DDR
    uint8_t mode1N               = 0; # 2N mode or SDR

#Check whether sim is still running 
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/ddr54 % qstat
tee: /u/pranavp/tmp/qstat.txt: No such file or directory
job-ID     prior   name       user         state submit/start at     queue                          jclass                         slots ja-task-ID 
------------------------------------------------------------------------------------------------------------------------------------------------
   6745801 0.00000 fw_tb_sim  pranavp      r     10/18/2021 10:53:38 b_msem@odcgen-msem-120g-1176-0   
#To stop the sim in half way
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/ddr54 % qdel 6745801 #qdel <jobid>
#To check whether anything failed. If anything failed, we can stop the simulation and check what's wrong
10)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/ddr54 % find . -iname FAILED.txt
#Similarly we can also check passed.txt
11)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/ddr54 % find . -iname PASSED.txt

#for internal revision change In simv.log file
#Search for debugf(10, "PMU10: **** Start DDR5 Training. PMU Firmware Revision 0x%04x (%d) ****\n", PMU_REVISION, (dccm_preload_pmu_internal_rev1 << 16) + dccm_preload_pmu_internal_rev0);
#Get the value of dccm_preload_pmu_internal_rev1 and dccm_preload_pmu_internal_rev0
#Check for variable names PmuInternalRev0 and PmuInternalRev1. We can find in message dump which is found both in Pre train and Post train
#Compare both the values. They should match
#Once sim is over, we will get either PASSED.txt or FAILED.txt
#Once sim is over, we can check for the user command we entered for running sim in the following path
# fw_tb/reg/sim_ddr5_train_ac10d4ch1_tc1_033358_pranav_test_x16_s1234/user_command

#for CS/CA vref training in  simv.log
"PMU5: CSn          0 Channel          0 VrefCS train passing region (         0,        105)\n"
"PMU5: CSn          0 Channel          0 final VrefCS 0x0035\n"

#Running on test chip
# ddr54 
#In CA09 - DDR54 workspace
1)pranavp@ca09lts2:~/Desktop % ssh -X ca09lab-bfmgr2-lnx #Secure shell
2)pranavp@ca09lts2:~/Desktop % cd /remote/ca09dws000/ddrphy_firmware/pranavp/systemAnalyst2
3)pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst % cd phyinit/ddr54
4)pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst3/phyinit/ddr54 % rm -r fw.tar.gz 
rm: remove regular file `fw.tar.gz'? y'
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst3/phyinit/ddr54 % rm -r init.tar.gz 
rm: remove regular file `init.tar.gz'? y'
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst3/phyinit/ddr54 % rm -r diags.tar.gz 
rm: remove regular file `diags.tar.gz'? y'''
#Remove old fw/, init/
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst3/phyinit/ddr54 % rm -rf fw/
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst3/phyinit/ddr54 % rm -rf init/   
#Remove old diagfw/
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst3/phyinit/ddr54 % rm -rf diagfw/ 
#In US01
5)pranavp@us01msem-32cx720g-386-120:/remote/us01sgnfs00017/users/pranavp/clients/ddr54 % cd build/c 

#Zip fw, init folders from US01
#If we need diag, zip diag from US01
6)pranavp@us01msem-32cx720g-386-120:/remote/us01sgnfs00017/users/pranavp/clients/ddr54/build/c % tar zchf fw.tar.gz fw 

7)pranavp@us01msem-32cx720g-386-120:/remote/us01sgnfs00017/users/pranavp/clients/ddr54/build/c % tar zchf init.tar.gz init 

8)pranavp@us01msem-32cx720g-386-120:/remote/us01sgnfs00017/users/pranavp/clients/ddr54/build/c % tar zchf diags.tar.gz diags 

#Export fw, init and diag to SystemAnalyst/phyinit/ddr54 from US01
9) pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/ddr54/build/c %  scp fw.tar.gz init.tar.gz diags.tar.gz pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/`whoami`/systemAnalyst5/phyinit/ddr54
   The authenticity of host 'ca09lab-bfmgr2-lnx (10.44.12.92)' can't be established.
   RSA key fingerprint is SHA256:I4Ljc3kHMBmmAxoRwNqscvRVNZHCn6s09G/Nwdk1S5Q.
   RSA key fingerprint is MD5:37:e5:aa:d4:f7:9f:f3:88:3c:88:9f:1e:15:33:f0:7a.
   Are you sure you want to continue connecting (yes/no)? yes
   Warning: Permanently added 'ca09lab-bfmgr2-lnx,10.44.12.92' (RSA) to the list of known hosts.
   fw.tar.gz                                                                                                                    100%   10MB   5.9MB/s   00:01    
   init.tar.gz                                                                                                                 100%   13MB  13.4MB/s   00:01    
   diags.tar.gz                                                                                                                100%  252     2.9KB/s   00:00 '   

#In CA09 - DDR54 workspaceUnzip fw, init and diags in SystemAnalyst/phyinit/ddr54
10)pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst/phyinit/ddr54 % tar zxf init.tar.gz
  pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst/phyinit/ddr54 % tar zxf fw.tar.gz
  #Don't need diag
  pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst/phyinit/ddr54 % tar zxf diags.tar.gz
  #Rename diags to diagfw
  pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst/phyinit/ddr54 % mv diags diagfw   
#You'll have to manually fix the 'fw' directory to move the contents from "rel" up one level
11)pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst/phyinit/ddr54 % cd fw
12)pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst/phyinit/ddr54/fw % rm -rf ddr*
   pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst/phyinit/ddr54/fw % mv rel/* .
   pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst/phyinit/ddr54/fw % rmdir rel 
#Compile and Run in a required DDR5 chip
13)python src/util/compile.py -sn FT240584 -r -pmbx 
   python src/apps/phyinit_driver.py -sn FT240584 -c configs/ddr54_ddr5_udimm.json -hdtctrl 0x4 


#Vref CS training in test chip
#First choose the appropriate board
#FT242541 since its an RDIMM board and it has logic analyser connected to it
#Alter the parameters similar to that of sim in phyinit/ddr54/userCustom/ddr5_rdimm/FT242541/dwc_ddrphy_phyinit_setDefault.c
#uint8_t CATrainOpt           = 0x39;
#SequenceCtrl[0] = 0x8267;//0xC267 if QCS training is also enabled
#SequenceCtrl[1] = 0x021f;
#SequenceCtrl[2] = 0x021f;
#SequenceCtrl[3] = 0xc21f;
#[0], [1], [2], [3] represants pstates. 
#Compile and run the training with the set parameters
python src/util/compile.py -sn FT242541 -r -pmbx -mbh
python src/apps/phyinit_driver.py -sn FT242541 -c configs/ddr54_ddr5_rdimm.json -hdtctrl 0x4 
#In the log file generated
#check for the following lines
PMU5: CSn 0 Channel 0: 00000000000000000000000000ffffff #0-pass f-fail
PMU5: CSn 0 Channel 0 VrefCS train passing region (0, 103) #not the passing region width
PMU4: CSn 0 Channel 0 isCA 0 isVref 1 margin 51
PMU5: CSn 0 Channel 0 final VrefCS 0x0036 #vrefcs is 0x36 = 54(dec), which is % of max Vref
#compile and run before making code changes. save the log
#after extracting fw and init from US01 with our code changes -> compile and run -> save the log
#VrefCs passing region and vrefcs should be more or less same.(need not be exact. But has to be close to)



#To get back nightly builds
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst/phyinit/ddr54 % rm -rf fw/
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst/phyinit/ddr54 % rm -rf init/
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst/phyinit/ddr54 % cd ../..
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst % ./copyfw-nightly ddr54_dev
	Copying training and diag fw for ddr54_dev...
	Copying ate fw for ddr54_dev...


#To get DDR54 firmware application note
#Open perforce helix
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/ddr54 % p4v &
#In that Connections -> Open connection
#Enter p4p-us01:1700 in server
#Then enter the path
# Training app note
//techpubssgip/phy/ddr/ddr54_phy/app_notes/ddr54_training_firmware_application_note/_released/dwc_ddr54_phy_training_firmware_application_note.pdf
# Diag app note
//techpubssgip/phy/ddr/ddr54_phy/app_notes/firmware_diagnostic_application_note/source/dwc_ddr54_phy_firmware_diagnostic_application_note.docx
Path to submit:
//depot/products/ddr54/dev/pmu_firmware/doc/
#Sync till the changeset
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/ddr54_works % p4 sync @8912199
#confirm that we have loaded till changeset 8912199
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/ddr54_works % p4 cstat
... change 8911092
... status have

... change 8912199
... status have

... change 8913873
... status need
#Build it till the changeset
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/ddr54_works % make phyinit
#Import it to CA09 and test


#CATrainOpt - 0101 1011 - 0x5B
uint8_t  CATrainOpt;       // Byte offset 0x1b, CSR Addr 0x5800d, Direction=In
                           // CA training option bit field:
                           // [0] Enable RDIMM/LRDIMM 2D CA training (UDIMM: RFU, must be zero) -1
                           // [1] Enable RDIMM/LRDIMM CA DFE training (UDIMM: RFU, must be zero) - 1
                           // [3:2] step size for CS and CA training: 0 -> 1, 1 -> 2, 2 -> 4, 3 -> - 10
                           // [4] Skip_CA13_during_CAtraining
                           //     0x0 = Train CA13 during CA training
                           //     0x1 = Skip CA13 during CA training - 1
                           // [5] Enable RCD VrefCS training - 1
                           // [6] Enable RCD VrefCA training - 0
                           // [7] Use multiple patterns during CA training - 0
#new CATrainOpt - 0011 1101
uint8_t  CATrainOpt;       // Byte offset 0x1b, CSR Addr 0x5800d, Direction=In
                           // CA training option bit field:
                           // [0] Enable 2D CA training - 1
                           // [1] Enable RDIMM/LRDIMM CA DFE training (UDIMM: RFU, must be zero) - 0
                           // [3:2] step size for CS and CA training: 0 -> 1, 1 -> 2, 2 -> 4, 3 -> 8 11
                           // [4] Skip_CA13_during_CAtraining
                           //     0x0 = Train CA13 during CA training
                           //     0x1 = Skip CA13 during CA training - 1
                           // [5] Enable 2D CS training - 1
                           // [6] RFU, must be zero - 0
                           // [7] Use multiple patterns during CA training - 0

#SequenceCtrl - 0x8267 - 8001
// Training step to bit mapping:
//    SequenceCtrl[0] = Run DevInit - Device/phy initialization. Should always be set - 1
//    SequenceCtrl[1] = Run WrLvl - Write leveling - 1
//    SequenceCtrl[2] = Run RxEn - Read gate training - 1
//    SequenceCtrl[3] = Run RdDQS1D - 1d read dqs training
//    SequenceCtrl[4] = Run WrDQ1D - 1d write dq training
//    SequenceCtrl[5] = Run rd2D - 2d read dqs training - 1
//    SequenceCtrl[6] = Run wr2D - 2d write dq training - 1
//    SequenceCtrl[7] = RFU, must be zero
//    SequenceCtrl[8] = RFU, must be zero
//    SequenceCtrl[9] = Run MxRdLat - Max read latency training - 1
//    SequenceCtrl[13-10] = RFU, must be zero
//    SequenceCtrl[14] = Run RCD_CSCA - CS/CA training between RCD and DRAM
//    SequenceCtrl[15] = Run CSCA - CS/CA Training - 1

#SequenceCtrl - 0000000001100111 - 0x67
// Training step to bit mapping: 
// SequenceCtrl[0] = Run DevInit - Device/PHY initialization. Should always be set - 1
// SequenceCtrl[1] = Run WrLvl - Write leveling - 1
// SequenceCtrl[2] = Run RxEn - Read gate training - 1
// SequenceCtrl[3] = Run RdDQS1D - 1d read dqs training - 0 
// SequenceCtrl[4] = Run WrDQ1D - 1d write dq training - 0
// SequenceCtrl[5] = Run rd2D - 2d read dqs training - 1
// SequenceCtrl[6] = Run wr2D - 2d write dq training - 1
// SequenceCtrl[7] =  RFU, must be zero - 0
// SequenceCtrl[8] = Run RdDeskew - Per lane read dq deskew training - 0
// SequenceCtrl[9] = Run MxRdLat - Max read latency training - 0
// SequenceCtrl[10] = Run DWL - LDRIMM DRAM Write Leveling - 0
// SequenceCtrl[11] = Run MREP - LRDIMM DRAM Interface MDQ Receive Enable Phase training - 0
// SequenceCtrl[12] = Run MRD - DRAM-to-DB Read Delay training - 0
// SequenceCtrl[13] = Run MWD - DB-to-DRAM Write Delay training - 0
// SequenceCtrl[15-14] = RFU, must be zero - 00



# sim - wave form
# Go into sim folder
pranavp@us01msemt1062:/remote/us01sgnfs00017/users/pranavp/clients/ddr54/fw_tb/reg/sim_ddr5_train_ac10d4ch1_tc1_204810_pranav_diag_cs_udimm_corrected_x16_s1234 % ./verdi.run
signal -> get signal -> test -> top -> ddr5_dimm0_dut -> dimm_if -> channel[0] -> data lane[0] -> dram[0] -> CK, CS_n, CA[0:13], cmd_debug[255:0], alert for RDIMM
file -> save signal -> <name>.rc
click on cmd_debug[255:0] -> set_radix -> ASCII 
# CS line toggle -> CS training
# CA line toggle -> CA training
# Ck line and CS line low -> after that diag firmware runs

test.sv -> d5_mode2n = 0 -> 1N mode 
           d5_mode2n = 1 -> 2N mode 

# RCD signal 
# DCS_n[0] for rank 0 and DCS_n[1] for rank 1
# When we see CS toggle, we get alert pin 0. When there is no toggle in CS line, alert pin is 1.
/test/top/ddr5_dimm0_dut/dimm_if/ddr5_ca_buffer_if/ca_buffer_channel[0] -> CK, DCS_n[1:0], DCA_n[6:0], alert_n (output signal), cmd_debug[255:0]
click on cmd_debug[255:0] -> set_radix -> ASCII 

rtl/pub/csr.txt -> With the help of address (For eg, 0x1080 -> we ll get the description of that CSR)
# DDR54
/test/top/dut/u_DWC_ddrphy_pub/dfi2acx/ANIB1_dig -> To get all the CSRs values like Dly CSR  (ANIB1 for CA training, ANIB0 for CS training)
(Inside the CSR address, what is the value?)

# DDR5_STD
# To search in all sub scope of the selected option
signal -> get signal -> options -> check search signals in all subscope 
/test/top/dut/ -> click on dut -> type the intended CSR in the signal value box - *ATxDlySelect*
# channel 0
 = > choose /test/top/dut/pub_top/pub/ac_0/_ac_dig/csrATxDlySelect_p0[1:0] # p for pstate
#channel 1
 = > choose /test/top/dut/pub_top/pub/ac_1/_ac_dig/csrATxDlySelect_p0[1:0] # p for pstate

# check for pin mapping in pmu_util.c
/ CS0: ACXTxDly[R9]  (Lane 9)
// CS1: ACXTxDly[R8]  (Lane 8)
// CS2: ACXTxDlyD5Ln1 (Lane 11)
// CS3: ACXTxDlyD5Ln0 (Lane 10)

# Find which rank it is ACXTxDly_r9 in the waveform viewer

# If there is an error, say for example
UVM_ERROR: Description: VrefCA Command to next valid commnad Minimum time tVREFCA_DELAY not satisfied, Reference: TG423B5^20211104^1848.99J^Samsung^DDR5_Draft_Spec_Rev171_Emailvote : 4.24.2 VrefCA Command Timing, Table 116 -  tVrefCA_Delay not met. Last VREFCA command was observed @ 66794048224.099998 ps. Current command VREFCA is issued before tVrefCA=14000.000000 ps completed Expected tVREFCA_DELAY time is 14000.000000ps(25 nCK), actual tVREFCA_DELAY is (1 nCK), tCK_ps = 556.000000ps, tERR_n_per -124ps, clock_jitter_enabled=1, enable_rounding=1 enable_max_para_rounding=0
UVM_ERROR @ 66794048780100: uvmvlog_top.ddr5_dimm_dut.channel_0_data_lane_0.rank[0].monitor [register_fail:DDR5:vrefca_group:tvrefca_delay_timing_check] Description: VrefCA Command to next valid commnad Minimum time tVREFCA_DELAY not satisfied, Reference: TG423B5^20211104^1848.99J^Samsung^DDR5_Draft_Spec_Rev171_Emailvote : 4.24.2 VrefCA Command Timing, Table 116 -  tVrefCA_Delay not met. Last VREFCA command was observed @ 66794048224.099998 ps. Current command VREFCA is issued before tVrefCA=14000.000000 ps completed Expected tVREFCA_DELAY time is 14000.000000ps(25 nCK), actual tVREFCA_DELAY is (1 nCK), tCK_ps = 556.000000ps, tERR_n_per -124ps, clock_jitter_enabled=1, enable_rounding=1 enable_max_para_rounding=0

Go to that time 66794048224 (ps)

In the waveform, it will be fs (femto sec) - type 66794048224000 in the time box and check the waveform (append 3 zeros at the end)

Here it says to check the table from JEDEC spec. So go check in the spec, the value of the timing

# simv.log
# sim..../apb_config.sv 
# CsPresentChA = 0x1 -> 00 01 -> rank 0 DIMM0
# CsPresentChA = 0x2 -> 00 10 -> rank 1 DIMM0
# CsPresentChA = 0x4 -> 01 00 -> rank 2 DIMM1
# CsPresentChA = 0x8 -> 10 00 -> rank 3 DIMM1

