Steps to run simulation:
1)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54 % p4 opened
//depot/products/lpddr54/dev/pmu_firmware/production_code/pmu_rdDQS_wrDQ.c#177 - edit change 8250899 (text)
//depot/products/lpddr54/dev/pmu_firmware/production_code/pmu_util.c#252 - edit change 8250899 (text)
//depot/products/lpddr54/dev/pmu_firmware/production_code/pmu_wrlvl.c#99 - edit change 8250899 (text)
2)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54 % tools/binDiff -s 8250899
This script can only be run with no open files.
3)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54 % p4 revert ...
//depot/products/lpddr54/dev/pmu_firmware/production_code/pmu_rdDQS_wrDQ.c#177 - was edit, reverted
//depot/products/lpddr54/dev/pmu_firmware/production_code/pmu_util.c#252 - was edit, reverted
//depot/products/lpddr54/dev/pmu_firmware/production_code/pmu_wrlvl.c#99 - was edit, reverted
4)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % p4 edit tools/binDiff
5) Change the following code in Christian's' script:
    # Check to make sure there are no opened files
    P4OPENED=`p4 -s opened | head -n 1`
    if [ "$P4OPENED" != "error: File(s) not opened on this client." ]
    then
            echo "This script can only be run with no open files."
            #exit 1
    fi

    # Do unedited build
    cd $REPO_PATH
    make clean fwtbfw build=build_control

    # Do build with edits
    p4 unshelve -s $changelist
    make clean fwtbfw build=build_edits
5)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54 % tools/binDiff -s 9762209   
#We cannot work on US01ODC for running simulations since it is slow -> we go for test pc -us01msem-32cx720g-386-120
6)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54 % qsh -P iheavy -l os_distribution=centos -now n
7)pranavp@us01msem-32cx720g-386-120:~ % qstat.real
job-ID     prior   name       user         state submit/start at     queue                          jclass                         slots ja-task-ID 
------------------------------------------------------------------------------------------------------------------------------------------------
   5940425 0.00105 INTERACTIV pranavp      r     08/16/2021 18:42:12 h@us01msem-32cx720g-1246-011.s 
8)pranavp@us01msem-32cx720g-386-120:~ % konsole #open in konsole terminal for better view
9)In konsole -> cd /remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy/
10)pranavp@us01msem-32cx720g-386-120:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54 % source bootenv
11)pranavp@us01msem-32cx720g-386-120:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54 % p4 opened 
12)pranavp@us01msem-32cx720g-386-120:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54 % ll -ltr
13)pranavp@us01msemt1045:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy  % make fwtb && fw_tb/lpddr/run/runfw -host_as_fake_uc -repeat 200 -seed 1 -simdir $REPO_PATH/sims/clean -fwlocat $REPO_PATH/build_control/c/fw/rel && fw_tb/lpddr/run/runfw -host_as_fake_uc -repeat 200 -seed 1 -simdir $REPO_PATH/sims/edits -fwlocat $REPO_PATH/build_edits/c/fw/rel
14)pranavp@us01msemt1045:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy  %ls -d clean/* | wc -l  #total clean - 202
15)pranavp@us01msemt1045:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy  %ls -d edits/* | wc -l  #total edits - 200
#get all failed.txt files
16)pranavp@us01msemt1045:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy  %find . -iname FAILED.txt
#get all passed.txt files
17)pranavp@us01msemt1045:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy  %find . -iname PASSED.txt
#To check what job is running
18)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/ddr54 % qstat
tee: /u/pranavp/tmp/qstat.txt: No such file or directory
job-ID     prior   name       user         state submit/start at     queue                          jclass                         slots ja-task-ID 
------------------------------------------------------------------------------------------------------------------------------------------------
   6745801 0.00000 fw_tb_sim  pranavp      r     10/18/2021 10:53:38 b_msem@odcgen-msem-120g-1176-0   
#To stop the sim in half way
19)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/ddr54 % qdel 6745801 #qdel <jobid>
#Go into sims/clean and search for both passed and failed cases
20)pranavp@us01msemt1045:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy/sims/clean % ls */*ED.txt
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823191008_171301_56/PASSED.txt
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823200928_213539_102/PASSED.txt
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823210228_203730_122/PASSED.txt
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823210907_133224_146/PASSED.txt
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823190908_154924_52/PASSED.txt
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823200624_165950_89/PASSED.txt
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823200830_172659_98/PASSED.txt
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823210608_160923_135/PASSED.txt
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823211214_064057_159/PASSED.txt
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823220717_092841_187/PASSED.txt
21)pranavp@us01msemt1045:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy/sims/clean % ls */*ED.txt | sed 's/PASSED.txt/simv.log.gz/g'
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823191008_171301_56/simv.log.gz
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823200928_213539_102/simv.log.gz
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823210228_203730_122/simv.log.gz
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823210907_133224_146/simv.log.gz
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823190908_154924_52/simv.log.gz
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823200624_165950_89/simv.log.gz
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823200830_172659_98/simv.log.gz
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823210608_160923_135/simv.log.gz
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823211214_064057_159/simv.log.gz
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823220717_092841_187/simv.log.gz
#getting the time taken for each test
22)pranavp@us01msemt1045:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy/sims/clean % ls */*ED.txt | sed 's/PASSED.txt/simv.log.gz/g' | xargs zgrep 'CPU Time'
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823191008_171301_56/simv.log.gz:CPU Time:    632.030 seconds;       Data structure size:  96.1Mb
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823200928_213539_102/simv.log.gz:CPU Time:    670.510 seconds;       Data structure size:  96.1Mb
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823210228_203730_122/simv.log.gz:CPU Time:    860.060 seconds;       Data structure size: 100.5Mb
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823210907_133224_146/simv.log.gz:CPU Time:    597.500 seconds;       Data structure size: 100.1Mb
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823190908_154924_52/simv.log.gz:CPU Time:    751.770 seconds;       Data structure size: 100.8Mb
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823200624_165950_89/simv.log.gz:CPU Time:    975.040 seconds;       Data structure size:  96.3Mb
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823200830_172659_98/simv.log.gz:CPU Time:    900.300 seconds;       Data structure size: 100.3Mb
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823210608_160923_135/simv.log.gz:CPU Time:    772.570 seconds;       Data structure size: 100.3Mb
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823211214_064057_159/simv.log.gz:CPU Time:    976.110 seconds;       Data structure size:  96.4Mb
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823220717_092841_187/simv.log.gz:CPU Time:   1009.310 seconds;       Data structure size: 100.5Mb
#Go into sims/edit and search for both passed and failed cases
23)pranavp@us01msemt1045:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy/sims/edit % ls */*ED.txt
#Go to reg_edits
pranavp@us01msemt808:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_Copy % cd mytests
pranavp@us01msemt808:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_Copy/mytests % ls
reg_control  reg_edits
pranavp@us01msemt808:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_Copy/mytests % cd reg_edits/
pranavp@us01msemt808:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_Copy/mytests/reg_edits % ls
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270425_204040_165
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270505_210454_166
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270517_175738_167
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270527_235712_168
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270606_221642_169
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270616_175624_170
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270626_091227_171
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270706_051541_172
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270715_203911_173
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270726_055533_174
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270804_100611_175
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270814_084214_176
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270823_195125_177
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270902_093728_178
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270912_013800_179
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270921_182917_180
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933271001_060032_181
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933271011_220941_182
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933271022_055331_183
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933271031_094342_184
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933271109_225450_185
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933271120_101126_186
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933271203_104514_187
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933271214_092452_188
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933271231_194249_189
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933280118_144848_190
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933280203_044738_191
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933280222_012625_192
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933280309_081355_193
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933280326_054445_194
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933280409_164823_195
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933280424_131051_196
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933280506_022347_197
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933280517_193156_198
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933280529_154438_199
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933280610_111158_200
#simv.log.gz is where we check results of the sim - pass or fail
pranavp@us01msemt808:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_Copy/mytests/reg_edits % ls */simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270425_204040_165/simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270505_210454_166/simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270517_175738_167/simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270527_235712_168/simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270606_221642_169/simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270616_175624_170/simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270626_091227_171/simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270706_051541_172/simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270715_203911_173/simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270726_055533_174/simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270804_100611_175/simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270814_084214_176/simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270823_195125_177/simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270902_093728_178/simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270912_013800_179/simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270921_182917_180/simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933271001_060032_181/simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933271011_220941_182/simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933271022_055331_183/simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933271031_094342_184/simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933271109_225450_185/simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933271120_101126_186/simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933271203_104514_187/simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933271214_092452_188/simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933271231_194249_189/simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933280118_144848_190/simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933280203_044738_191/simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933280222_012625_192/simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933280309_081355_193/simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933280326_054445_194/simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933280409_164823_195/simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933280424_131051_196/simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933280506_022347_197/simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933280517_193156_198/simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933280529_154438_199/simv.log.gz
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933280610_111158_200/simv.log.gz
#Add one more arg (xargs) and grep(find) the cpu time
pranavp@us01msemt808:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_Copy/mytests/reg_edits % ls */simv.log.gz | xargs zgrep 'CPU Time'
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270425_204040_165/simv.log.gz:CPU Time:  10173.480 seconds;       Data structure size: 106.6Mb
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270505_210454_166/simv.log.gz:CPU Time:   8660.720 seconds;       Data structure size: 112.0Mb
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270517_175738_167/simv.log.gz:CPU Time:  15190.060 seconds;       Data structure size: 107.7Mb
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270527_235712_168/simv.log.gz:CPU Time:   7252.070 seconds;       Data structure size: 109.8Mb
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270606_221642_169/simv.log.gz:CPU Time:   3278.790 seconds;       Data structure size: 105.5Mb
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270616_175624_170/simv.log.gz:CPU Time:   8829.760 seconds;       Data structure size: 110.8Mb
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270626_091227_171/simv.log.gz:CPU Time:   6786.490 seconds;       Data structure size: 106.1Mb
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270706_051541_172/simv.log.gz:CPU Time:  10509.220 seconds;       Data structure size: 106.5Mb
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270715_203911_173/simv.log.gz:CPU Time:  21334.120 seconds;       Data structure size: 111.9Mb
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270726_055533_174/simv.log.gz:CPU Time:   6895.030 seconds;       Data structure size: 110.5Mb
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270804_100611_175/simv.log.gz:CPU Time:   3127.060 seconds;       Data structure size: 105.0Mb
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270814_084214_176/simv.log.gz:CPU Time:   7011.410 seconds;       Data structure size: 109.9Mb
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270823_195125_177/simv.log.gz:CPU Time:   9871.440 seconds;       Data structure size: 106.4Mb
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270902_093728_178/simv.log.gz:CPU Time:   6733.640 seconds;       Data structure size: 110.2Mb
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270912_013800_179/simv.log.gz:CPU Time:  11450.330 seconds;       Data structure size: 107.0Mb
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270921_182917_180/simv.log.gz:CPU Time:   8524.780 seconds;       Data structure size: 111.4Mb
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933271001_060032_181/simv.log.gz:CPU Time:  18801.990 seconds;       Data structure size: 112.0Mb
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933271011_220941_182/simv.log.gz:CPU Time:  14977.400 seconds;       Data structure size: 107.6Mb
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933271022_055331_183/simv.log.gz:CPU Time:   5043.660 seconds;       Data structure size: 109.7Mb
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933271031_094342_184/simv.log.gz:CPU Time:   7351.100 seconds;       Data structure size: 105.5Mb
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933271109_225450_185/simv.log.gz:CPU Time:   8281.500 seconds;       Data structure size: 106.3Mb
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933271120_101126_186/simv.log.gz:CPU Time:   6467.810 seconds;       Data structure size: 105.9Mb
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933271203_104514_187/simv.log.gz:CPU Time:   5860.930 seconds;       Data structure size: 111.4Mb
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933271214_092452_188/simv.log.gz:CPU Time:   9515.910 seconds;       Data structure size: 107.0Mb
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933271231_194249_189/simv.log.gz:CPU Time:  17359.400 seconds;       Data structure size: 112.1Mb
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933280118_144848_190/simv.log.gz:CPU Time:  11770.690 seconds;       Data structure size: 107.7Mb
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933280203_044738_191/simv.log.gz:CPU Time:   2127.680 seconds;       Data structure size: 109.2Mb
sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933280222_012625_192/simv.log.gz:CPU Time:   5311.200 seconds;       Data structure size: 106.4Mb
#Add one more arg (xargs) and grep(find) the cpu time - sort the 3rd column (-nk3,3)
# -n numeric sort
# -r sort in decending order (sort the 3rd column (-nkr3,3))
# -k is the sorting key - by default w sort the first column, -k3,3 -> sort the third column
pranavp@us01msemt808:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_Copy/mytests/reg_edits % ls */simv.log.gz | xargs zgrep 'CPU Time' | sort -nk3,3 | less
#run python and calculate the time in worst case and best case
pranavp@us01msemt808:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_Copy/mytests/reg_edits % python
Python 3.6.3 (default, Jan  2 2018, 21:51:32) 
[GCC 4.8.3 20140911 (Red Hat 4.8.3-9)] on linux
Type "help", "copyright", "credits" or "license" for more information.
>>> 2100/60
35.0
>>> 21000/60/60
5.833333333333333
>>> 
#Diff the config and check the sim configuration for worst case and best case
pranavp@us01msemt808:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_Copy/mytests/reg_edits % tkdiff sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933280203_044738_191/.phyinit/lpddr5/output/dwc_ddrphy_phyinit_out_lpddr5_train.txt  sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_51933270715_203911_173/.phyinit/lpddr5/output/dwc_ddrphy_phyinit_out_lpddr5_train.txt 
#History used to display all the command we entered till now
pranavp@us01msemt1045:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy/sims/clean % history
     1  14:18   cd /u/pranavp
     2  14:18   vi .cshrc.pranavp
     3  14:19   cd /remote/us01sgnfs00017/users/pranavp/clients/lpddr54/
     4  14:20   st pmu_firmware/production_code
     5  19:14   cd fix_misra_error/c/fw
     6  19:14   rm -r fix.txt
     7  19:15   md5sum */*.bin | sort -k2 > fix.txt
     8  19:15   cd ../../../build/c/fw
     9  19:15   rm -r old.txt
    10  19:15   md5sum */*.bin | sort -k2 > old.txt
    11  19:15   diff old.txt ../../../fix_misra_error/c/fw/fix.txt
    12  5:54    cd ../../..
    13  5:54    make coverity
    14  11:18   p4w -update_env
    15  11:18   source bootenv
    17  11:24   p4 shelve -fc 8250899
    20  11:31   tools/binDiff -s 8250899
    21  12:16   setenv P4EDITOR 'evim -f'
    22  12:16   p4 shelve
    23  12:19   ~delbaere/bin/post-review 1243174 8263782
    24  16:45   p4 diff -du
    25  16:46   make phyinit build=fix_misra_error
    27  18:52   build/c/fw/lpddr5
    28  18:53   cd build/c/fw/lpddr5
    29  18:53   ls -l *.strings
    30  18:53   st pmu_train.strings
    32  19:13   st lpddr5
    33  9:48    cd /remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy/
    34  9:49    s bootenv
    36  9:49    ll -ltr
    37  10:03   cd tools
    38  10:03   cd make
    39  10:03   st fwtb.mk
    40  10:10   cd ../../
    42  10:11   cd build_control
    44  10:11   cd ..
    45  10:23   make fwtbPerl && fw_tb/run/runfw -host_as_fake_uc -repeat 200 -seed 1 -simdir $REPO_PATH/sims/clean -fwlocat $REPO_PATH/build_control/c/fw/rel && fw_tb/run/runfw -host_as_fake_uc -repeat 200 -seed 1 -simdir $REPO_PATH/sims/edits -fwlocat $REPO_PATH/build_edits/c/fw/rel
    46  10:25   make fwtbPerl && fw_tb/lpddr/run/runfw -host_as_fake_uc -repeat 200 -seed 1 -simdir $REPO_PATH/sims/clean -fwlocat $REPO_PATH/build_control/c/fw/rel && fw_tb/lpddr/run/runfw -host_as_fake_uc -repeat 200 -seed 1 -simdir $REPO_PATH/sims/edits -fwlocat $REPO_PATH/build_edits/c/fw/rel
    51  10:35   echo $!
    53  10:39   p4 opened
    54  10:40   p4 revert ...
    55  10:40   tools/binDiff -s 8396861
    57  11:22   st tools/binDiff
    58  11:23   p4 edit tools/binDiff
    59  12:19   make fwtb && fw_tb/lpddr/run/runfw -host_as_fake_uc -repeat 200 -seed 1 -simdir $REPO_PATH/sims/clean -fwlocat $REPO_PATH/build_control/c/fw/rel && fw_tb/lpddr/run/runfw -host_as_fake_uc -repeat 200 -seed 1 -simdir $REPO_PATH/sims/edits -fwlocat $REPO_PATH/build_edits/c/fw/rel
    62  12:41   cd sims
    65  12:42   ls */*
    67  12:42   qstat
    68  12:43   qstat | wc -l
    70  12:44   ls -d clean/* | wc -l               // total clean - 202
    71  12:44   ls -d edits/* | wc -l               // total edits - 200
    76  12:44   ls */*ED,txt
    78  12:44   cd ../
    79  12:45   find . -iname FAILED.txt
    80  12:45   find . -iname PASSED.txt
    83  12:46   ls -d */*/*ED.txt | wc -l
    84  12:47   cd clean/
    86  12:47   cat */sim_command
    87  12:47   ls
    88  12:47   ls *
    91  12:48   ls */*ED.txt | sed 's/PASSED.txt/simv.log.gz/g' | xargs zgrep 'CPU Time'
    92  12:48   python
    96  12:53   ls */simv.log.gz
    97  12:53   ls */simv.log.gz | xargs zgrep 'CPU Time'
    98  12:54   ls */*ED.txt | sed 's/PASSED.txt/simv.log.gz/g'
    99  12:54   ls */*ED.txt
   100  12:55   ls */*ED.txt | sed 's/PASSED.txt/simv.log.gz/g' | xargs -n 2 echo
   102  12:56   ls */*ED.txt | sed 's/PASSED.txt/simv.log.gz/g' | xargs diff
   103  12:56   ls */*ED.txt | sed 's/PASSED.txt/simv.log.gz/g' | xargs -n 2 diff
   104  12:56   ls */*ED.txt | sed 's/PASSED.txt/simv.log.gz/g' | xargs -n 2 echo | wc -l
   105  12:56   ls */*ED.txt | sed 's/PASSED.txt/simv.log.gz/g' | xargs -n 1 echo | wc -l
   106  12:57   ls -d */* | wc -l
   107  14:42   history

#We can run individual command in the history as follows !89 -> will run 89th command, we need not type again and again
pranavp@us01msemt1045:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy/sims/clean % !89 
ls */*ED.txt
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823190412_202016_32/PASSED.txt
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823190604_080717_39/PASSED.txt
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823191008_171301_56/PASSED.txt
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823191116_123104_61/PASSED.txt
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823200519_050306_85/PASSED.txt
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823200928_213539_102/PASSED.txt
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823210228_203730_122/PASSED.txt
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823210907_133224_146/PASSED.txt
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823190908_154924_52/PASSED.txt
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823200624_165950_89/PASSED.txt
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823200830_172659_98/PASSED.txt
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823210608_160923_135/PASSED.txt
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823211214_064057_159/PASSED.txt
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823220717_092841_187/PASSED.txt
pranavp@us01msemt1045:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy/sims/clean % !90 
ls */*ED.txt | sed 's/PASSED.txt/simv.log.gz/g'
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823190412_202016_32/simv.log.gz
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823190604_080717_39/simv.log.gz
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823191008_171301_56/simv.log.gz
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823191116_123104_61/simv.log.gz
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823200519_050306_85/simv.log.gz
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823200928_213539_102/simv.log.gz
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823210228_203730_122/simv.log.gz
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823210907_133224_146/simv.log.gz
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823190908_154924_52/simv.log.gz
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823200624_165950_89/simv.log.gz
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823200830_172659_98/simv.log.gz
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823210608_160923_135/simv.log.gz
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823211214_064057_159/simv.log.gz
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823220717_092841_187/simv.log.gz
#Instead of grep, we can also use sed to find 's/PASSED.txt/simv.log.gz/g'
pranavp@us01msemt1045:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy/sims/clean % ls */*ED.txt | sed 's/PASSED.txt/simv.log.gz/g'
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823191008_171301_56/simv.log.gz
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823200928_213539_102/simv.log.gz
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823210228_203730_122/simv.log.gz
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823210907_133224_146/simv.log.gz
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823190908_154924_52/simv.log.gz
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823200624_165950_89/simv.log.gz
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823200830_172659_98/simv.log.gz
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823210608_160923_135/simv.log.gz
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823211214_064057_159/simv.log.gz
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823220717_092841_187/simv.log.gz
pranavp@us01msemt1045:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy/sims/clean % ls */*ED.txt | sed 's/PASSED.txt/simv.log.gz/g' | xargs zgrep 'CPU Time'
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823191008_171301_56/simv.log.gz:CPU Time:    632.030 seconds;       Data structure size:  96.1Mb
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823200928_213539_102/simv.log.gz:CPU Time:    670.510 seconds;       Data structure size:  96.1Mb
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823210228_203730_122/simv.log.gz:CPU Time:    860.060 seconds;       Data structure size: 100.5Mb
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823210907_133224_146/simv.log.gz:CPU Time:    597.500 seconds;       Data structure size: 100.1Mb
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823190908_154924_52/simv.log.gz:CPU Time:    751.770 seconds;       Data structure size: 100.8Mb
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823200624_165950_89/simv.log.gz:CPU Time:    975.040 seconds;       Data structure size:  96.3Mb
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823200830_172659_98/simv.log.gz:CPU Time:    900.300 seconds;       Data structure size: 100.3Mb
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823210608_160923_135/simv.log.gz:CPU Time:    772.570 seconds;       Data structure size: 100.3Mb
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823211214_064057_159/simv.log.gz:CPU Time:    976.110 seconds;       Data structure size:  96.4Mb
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823220717_092841_187/simv.log.gz:CPU Time:   1009.310 seconds;       Data structure size: 100.5Mb
#sort the second column based on the number and output (-n 2 echo)
pranavp@us01msemt1045:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy/sims/clean % ls */*ED.txt | sed 's/PASSED.txt/simv.log.gz/g' | xargs -n 2 echo
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823190412_202016_32/simv.log.gz sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823190604_080717_39/simv.log.gz
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823191008_171301_56/simv.log.gz sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823191116_123104_61/simv.log.gz
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823200519_050306_85/simv.log.gz sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823200928_213539_102/simv.log.gz
sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823210228_203730_122/simv.log.gz sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823210907_133224_146/simv.log.gz
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823190908_154924_52/simv.log.gz sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823200624_165950_89/simv.log.gz
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823200830_172659_98/simv.log.gz sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823210608_160923_135/simv.log.gz
sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823211214_064057_159/simv.log.gz sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823220717_092841_187/simv.log.gz
#check whether file differs or not (xargs -n 2 diff)
pranavp@us01msemt1045:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy/sims/clean % ls */*ED.txt | sed 's/PASSED.txt/simv.log.gz/g' | xargs -n 2 diff
Binary files sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823190412_202016_32/simv.log.gz and sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823190604_080717_39/simv.log.gz differ
Binary files sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823191008_171301_56/simv.log.gz and sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823191116_123104_61/simv.log.gz differ
Binary files sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823200519_050306_85/simv.log.gz and sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823200928_213539_102/simv.log.gz differ
Binary files sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823210228_203730_122/simv.log.gz and sim_lpddr5_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823210907_133224_146/simv.log.gz differ
Binary files sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823190908_154924_52/simv.log.gz and sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823200624_165950_89/simv.log.gz differ
Binary files sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823200830_172659_98/simv.log.gz and sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823210608_160923_135/simv.log.gz differ
Binary files sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823211214_064057_159/simv.log.gz and sim_lpddr5x_devinit_skiptrain_lp5d5cs4dq40ch2combo_tc200_45823220717_092841_187/simv.log.gz differ
#wc - word count - to see total number of test cases - passed-failed-total
#To get total number of test cases
pranavp@us01msemt808:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_Copy/mytests/reg_edits % ls */*ED.txt | sed 's/PASSED.txt/simv.log.gz/g' | xargs -n 2 echo | wc -l
32
#To get total number of test cases passed
pranavp@us01msemt808:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_Copy/mytests/reg_edits % ls */PASSED.txt | sed 's/PASSED.txt/simv.log.gz/g' | xargs -n 2 echo | wc -l
31
#To get total number of test cases failed
pranavp@us01msemt808:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_Copy/mytests/reg_edits % ls */FAILED.txt | sed 's/PASSED.txt/simv.log.gz/g' | xargs -n 2 echo | wc -l
1
#Total sims yet to run -> 0 -> all sims successfully completed
pranavp@us01msemt1045:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_Copy/mytests/reg_edits  % qstat | wc -l
pranavp@us01msemt1045:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_Copy/mytests/reg_edits  % ls -d */* | wc -l

