pranavp@ca09lts2:~/Desktop %  ssh -X ca09lab-bfmgr3-lnx
[pranavp@ca09lab-bfmgr3-lnx] % cd /remote/ca09dwp004/ddrphy_firmware/svc-bfmgr/pyside3
pranavp@ca09lab-bfmgr3-lnx:/remote/ca09dwp004/ddrphy_firmware/svc-bfmgr/pyside3 % source setenv.csh
pranavp@ca09lab-bfmgr3-lnx:/remote/ca09dwp004/ddrphy_firmware/svc-bfmgr/pyside3 % cd /remote/ca09dwp004/ddrphy_firmware/pranavp/systemAnalyst4
pranavp@ca09lab-bfmgr3-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/systemAnalyst4 % setenv SYSTEM_ANALYST_HOME `pwd`

# To view the Gui window:
pranavp@ca09lab-bfmgr3-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/systemAnalyst4 % python src/apps/ate_gui.py

# To view the files in sublime:
pranavp@ca09lab-bfmgr3-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/systemAnalyst4 % ssh -X ca09lab-bfmgr2-lnx
[pranavp@ca09lab-bfmgr2-lnx] % cd /remote/ca09dwp004/ddrphy_firmware/pranavp/systemAnalyst4

# src/apps/ate_gui.py -> class ateGui(QMainWindow) contains the start of the GUI window
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/systemAnalyst4 % st src/apps/ate_gui.py

# src/gui/ contains all the files necessary for the GUI menus
# For eg., For 1D data loopback, we have the file called data_loopback_frame.py
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/systemAnalyst4 % st src/gui/data_loopback_frame.py

# To get the inputs to the GUI from the message block
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/systemAnalyst4 % st src/widgets/input_widget.py

# How the input and outputs look like in command interface
# ate/lpddr5x_std/ate_defaults.txt contains are the defaults inputs to 1D data loopback
# We run ate_driver with default inputs
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/systemAnalyst4 % python src/apps/ate_driver.py

# In the menu, select 0x20
Test Menu
0x0001	Revision Check Test
0x0002	Impedance Cal Test
0x0004	PLL Lock Test
0x0008	LCDL Linearity Test
0x0010	AC Loopback Test
0x0020	DAT 1D Loopback Test
0x0040	DAT 2D Loopback Test
0x0080	Burn In Test
2deyes	Print 2D Eyes for AC Loopback
r	Read Address
w	Write Address
rl	Reload firmware
rd	Reload ate_defaults.txt and ate_values.txt
d	Dump Test Values
v	Loopback Result Vebosity 0 or 1
c	Run Command Script
dump	Dump all CSRs
h	Print help
x	Exit

Enter test number: 0x20

# We display the outputs from the memory locations - we have variables and arrays.
# We have to display this in graphical manner in the gui.
# We have to store the ouptut to the message block self._messageBlock.getTest() and display those values in the window GUI.


