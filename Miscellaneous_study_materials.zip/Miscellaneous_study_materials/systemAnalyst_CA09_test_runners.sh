#SystemAnalyst Test Run in CA09


#############################################################################################
Always run testRunner if u make any changes to SystemAnalyst (best to run LP54, ddr54 (ddr54_tc803 as well) and phy2)
Always run validate_fw.py, when u update something in setDefault.c
when you run ssh -X it forwards your display to your Citrix session. if you omit the -X -- which the nightly builds do, because there is no display for them, then you can't create graphical windows and objects in the Python code, otherwise you'll get an error
#############################################################################################

DDR54:
# CADC Shared Linux or CADC ODC VDE 79 2x16 
1)pranavp@ca09lts2:~/Desktop % ssh -X ca09lab-bfmgr5-lnx #Secure shell
1)pranavp@ca09lts2:~/Desktop % ssh ca09lab-bfmgr2-lnx #Secure shell nightly (no graphics)
2)pranavp@ca09lts2:~/Desktop % cd /remote/ca09dwp004/ddrphy_firmware/pranavp/systemAnalyst
3)[pranavp@ca09lab-bfmgr2-lnx SystemAnalyst]$ ln -s ../../delbaere/SystemAnalyst/copyfw-nightly #done only once
  pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst2 %  source bootenv 
(or)
  pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst2 % setenv SYSTEM_ANALYST_HOME `pwd`
  pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst2 % setenv PYTHONPATH `pwd`:`pwd`/src
  #If I get import module saleae error
  pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst2 % setenv PYTHONPATH ${PYTHONPATH}:/remote/ca09dwp004/ddrphy_firmware/Saleae/lib/python2.7/site-packages
#Changing to editor to gvim - easy to add description after shelve
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst2 % setenv P4EDITOR 'evim -f'
#Run the following command to get up to date firmware 
4)[pranavp@ca09lab-bfmgr2-lnx SystemAnalyst]$ ./copyfw-nightly ddr54
  Copying training and diag fw for ddr54_dev...
  Copying ate fw for ddr54_dev...
  [pranavp@ca09lab-bfmgr2-lnx SystemAnalyst]$ ./copyfw-nightly ddr5_std
  Copying phyinit, training and diag fw for ddr5_std...
  Copying ate fw for ddr5_std...
#Running test after code change and before sending for review - running tests on new boards - totally 12 
5)[pranavp@ca09lab-bfmgr2-lnx SystemAnalyst]$ python src/test/testRunner.py -P ddr54 # --branch ddr54_dev #+ test FT242500
#full test
5)[pranavp@ca09lab-bfmgr2-lnx SystemAnalyst]$ python src/test/testRunner.py -P ddr54 --suite full
5)[pranavp@ca09lab-bfmgr2-lnx SystemAnalyst]$ python src/test/testRunner.py -P ddr5_std --suite full
#To run the all tests in individual boards - eg) FT242541
5)[pranavp@ca09lab-bfmgr2-lnx SystemAnalyst]$ python src/test/test.py -sn FT242541
#Running tests on older boards for FT242500
6)pranavp@ca09lab-bfmgr2-lnx:% ./copyfw-nightly ddr54_tc803
7)pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst % python src/test/testRunner.py -P ddr54 --branch ddr54_tc803
#compile
8)[pranavp@ca09lab-bfmgr2-lnx SystemAnalyst]% python src/util/compile.py -sn FT24258A -r -pmbx
#run
9)[pranavp@ca09lab-bfmgr2-lnx SystemAnalyst]$ python src/apps/phyinit_driver.py -sn FT24258A -c configs/ddr54_ddr5_rdimm.json -hdtctrl 0xa

1)pranavp@ca09lts1:~/Desktop % ssh -X ca09lab-bfmgr4-lnx #Secure shell
pranavp@ca09lts1:~/Desktop % ssh ca09lab-bfmgr4-lnx #Secure shell
2)pranavp@ca09lts1:~/Desktop % cd /remote/ca09dwp004/ddrphy_firmware/pranavp/systemAnalyst
#Running test after code change and before sending for review
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst2 % setenv SYSTEM_ANALYST_HOME `pwd`
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst2 % setenv PYTHONPATH `pwd`:`pwd`/src
#If I get import module saleae error
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst2 % setenv PYTHONPATH ${PYTHONPATH}:/remote/ca09dwp004/ddrphy_firmware/Saleae/lib/python2.7/site-packages
#Changing to editor to gvim - easy to add description after shelve
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst2 % setenv P4EDITOR 'evim -f'
#Run the following command to get up to date firmware
3)[pranavp@ca09lab-bfmgr1-lnx SystemAnalyst]$ ./copyfw-nightly lpddr54
4)[pranavp@ca09lab-bfmgr1-lnx SystemAnalyst]$ python src/test/testRunner.py -P lpddr54
4)[pranavp@ca09lab-bfmgr1-lnx SystemAnalyst]$ python src/test/testRunner.py -P lpddr5x_std -hdtctrl 0xa --suite full
5)[pranavp@ca09lab-bfmgr1-lnx SystemAnalyst]$ python src/test/testRunner.py -P lpddr54 -hdtctrl 0xa --suite full --branch lpddr54 #(full lpddr54 test)
6)[pranavp@ca09lab-bfmgr1-lnx SystemAnalyst]$ python src/tools/query_boards.py
Serial Number   Product   Protocol       DIMM       Manu     Freq  Rank  Width         Test Chip  Unique ID     Reserved By         Reserve Time
------------------------------------------------------------------------------------------------------------------------------------------------
FT354532        lpddr54     lpddr5   dramdown     Micron  6400MHz     2     16   d856 (83) 1.02a          2         pranavp  2021-09-20 14:08:45
FT354531        lpddr54     lpddr5   dramdown   Sk Hynix  6400MHz     2     16   d856 (83) 1.02a          1                                     
FT354530        lpddr54     lpddr5   dramdown    Samsung  6400MHz     2     16   d856 (83) 1.02a          0                                     
FT354533        lpddr54     lpddr5   dramdown     Micron  6400MHz     2      8   d856 (83) 1.02a          3                                     
FT3244F0        lpddr54     lpddr4   dramdown    Samsung  4267MHz     1     32   d859 (79) 0.60a          0                                     
FT3644F1        lpddr54    lpddr4x   dramdown     Micron  4267MHz     1     32   d859 (79) 0.60a          1                                     
FT364590        lpddr54    lpddr4x   dramdown     Micron  4266MHz     2     32   d850 (89) 2.00a          0                                     
FT354591        lpddr54     lpddr5   dramdown    Samsung  6400MHz     2     16   d850 (89) 2.00a          1                                     
FT356590        lpddr54     lpddr5      nomem 

# phyinit make
https://jiradocs.internal.synopsys.com/pages/viewpage.action?pageId=147718785

# to check what shell someone is using
echo $SHELL # For eg., bash or csh

#All board testing LPDDR54
1)python src/util/compile.py -sn FT354532 -r -pmbx -mbh
  python src/apps/phyinit_driver.py -sn FT354532 -c configs/lpddr54_lpddr5.json -hdtctrl 0x4
  python src/apps/diags_driver.py -sn FT354532 -c configs/lpddr54_lpddr5.json -hdtctrl 0xA
2)python src/util/compile.py -sn FT354531 -r -pmbx -mbh
  python src/apps/phyinit_driver.py -sn FT354531 -c configs/lpddr54_lpddr5.json -hdtctrl 0x4
  python src/apps/diags_driver.py -sn FT354531 -c configs/lpddr54_lpddr5.json -hdtctrl 0xA
3)python src/util/compile.py -sn FT354530 -r -pmbx -mbh #samsung issue board
  python src/apps/phyinit_driver.py -sn FT354530 -c configs/lpddr54_lpddr5.json -hdtctrl 0x4
  python src/apps/diags_driver.py -sn FT354530 -c configs/lpddr54_lpddr5.json -hdtctrl 0xA
4)python src/util/compile.py -sn FT354533 -r -pmbx -mbh
  python src/apps/phyinit_driver.py -sn FT354533 -c configs/lpddr54_lpddr5.json -hdtctrl 0x4
  python src/apps/phyinit_driver.py -sn FT354533 -c configs/lpddr54_lpddr5.json -hdtctrl 0x4 -dump-quickboot
  python src/apps/phyinit_driver.py -sn FT354533 -c configs/lpddr54_lpddr5.json -hdtctrl 0x4 -dump-quickboot -quickboot
  python src/apps/diags_driver.py -sn FT354533 -c configs/lpddr54_lpddr5.json -hdtctrl 0xA
5)python src/util/compile.py -sn FT3245C0 -r -pmbx -mbh
  python src/apps/phyinit_driver.py -sn FT3245C0 -c configs/lpddr54_lpddr4.json -hdtctrl 0x4
  python src/apps/diags_driver.py -sn FT3245C0 -c configs/lpddr54_lpddr4.json -hdtctrl 0xA
6)python src/util/compile.py -sn FT3645C1 -r -pmbx -mbh
  python src/apps/phyinit_driver.py -sn FT3645C1 -c configs/lpddr54_lpddr4x.json -hdtctrl 0x4
  python src/apps/diags_driver.py -sn FT3645C1 -c configs/lpddr54_lpddr4x.json -hdtctrl 0xA
7)python src/util/compile.py -sn FT364590 -r -pmbx -mbh
  python src/apps/phyinit_driver.py -sn FT364590 -c configs/lpddr54_lpddr4x.json -hdtctrl 0x4
  python src/apps/diags_driver.py -sn FT364590 -c configs/lpddr54_lpddr4x.json -hdtctrl 0xA
8)python src/util/compile.py -sn FT354591 -r -pmbx -mbh
  python src/apps/phyinit_driver.py -sn FT354591 -c configs/lpddr54_lpddr5.json -hdtctrl 0x4
  python src/apps/diags_driver.py -sn FT354591 -c configs/lpddr54_lpddr5.json -hdtctrl 0xA
9)python src/util/compile.py -sn FT356590 -r -pmbx -mbh #directory doesn't exist
  python src/apps/phyinit_driver.py -sn FT356590 -c configs/lpddr54_lpddr5.json -hdtctrl 0x4
  python src/apps/diags_driver.py -sn FT356590 -c configs/lpddr54_lpddr5.json -hdtctrl 0xA

#LP5X_STD
1)python src/util/compile.py -sn FT574600 -r 
  python src/apps/phyinit_driver.py -sn FT574600 -c configs/lpddr5x_std_lpddr5x.json -hdtctrl 0xA
  python src/apps/diags_driver.py -sn FT574600 -c configs/lpddr5x_std_lpddr5x.json -hdtctrl 0xA

2)python src/util/compile.py -sn FT554600 -r 
  python src/apps/phyinit_driver.py -sn FT554600 -c configs/lpddr5x_std_lpddr5.json -hdtctrl 0xA
  python src/apps/diags_driver.py -sn FT554600 -c configs/lpddr5x_std_lpddr5.json -hdtctrl 0xA

3)python src/util/compile.py -sn FT564600 -r 
  python src/apps/phyinit_driver.py -sn FT564600 -c configs/lpddr5x_std_lpddr4x.json -hdtctrl 0xA
  python src/apps/diags_driver.py -sn FT564600 -c configs/lpddr5x_std_lpddr4x.json -hdtctrl 0xA


#LP54_LP5x
3)python src/util/compile.py -sn FT374595 -r 
  python src/apps/phyinit_driver.py -sn FT374595 -c configs/lpddr54_lpddr5x.json -hdtctrl 0xA
  python src/apps/diags_driver.py -sn FT374595 -c configs/lpddr54_lpddr5x.json -hdtctrl 0xA

#DDR5_STD
3)python src/util/compile.py -sn FT642610 -r 
  python src/apps/phyinit_driver.py -sn FT642610 -c configs/ddr5_std_ddr5_rdimm.json -hdtctrl 0xA
  python src/apps/diags_driver.py -sn FT642610 -c configs/ddr5_std_ddr5_rdimm.json -hdtctrl 0xA
  #To run the diags driver even if the training fails
  python src/apps/diags_driver.py -sn FT642610 -c configs/ddr5_std_ddr5_rdimm.json -hdtctrl 0xA -continue
  python src/test/test.py -P ddr54 -p ddr5_std -sn FT642610 -hdtctrl 0x0A


# python 2 to python 3 and vice versa
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/systemAnalyst4 % module swap python python/3.6.3
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/systemAnalyst4 % which python
/global/freeware/Linux/2.6/python-3.6.3/bin/python
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/systemAnalyst4 % module swap python python/2.7.15
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/systemAnalyst4 % which python
/global/freeware/Linux/2.6/python-2.7.15/bin/python


# To change the already submitted changeList's description
pranavp@us01odcvde40200:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5_std_copy1 % p4 change -u 13266239


#Nightly DDR4 udimm and DDR5 udimm test manual run:
# Before running, make sure that python path is set. setenv PYTHONPATH ${PYTHONPATH}:/remote/ca09dws000/ddrphy_firmware/Saleae/lib/python2.7/site-packages
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst3 % python src/test/test.py -t -P ddr54  

Mailbox:
1)pranavp@ca09lts2:~/Desktop % ssh -X ca09lab-bfmgr1-lnx #Secure shell
2)[pranavp@ca09lab-bfmgr2-lnx Desktop] % cd /remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst
#compile
3)[pranavp@ca09lab-bfmgr2-lnx SystemAnalyst]% python src/util/compile.py -sn FT354532 -r -pmbx
#run
4)[pranavp@ca09lab-bfmgr2-lnx SystemAnalyst]% python src/apps/phyinit_driver.py -sn FT354532 -c configs/lpddr54_lpddr5.json -hdtctrl 0xa
#hdtctrl is the debug depth - [4,FF]
#compile without -pmbx
#LPDDR54
5)[pranavp@ca09lab-bfmgr2-lnx SystemAnalyst]% python src/util/compile.py -sn FT354532 -r
6)[pranavp@ca09lab-bfmgr2-lnx SystemAnalyst]% python src/apps/phyinit_driver.py -sn FT354532 -c configs/lpddr54_lpddr5.json -hdtctrl 0xa
#hdtctrl is the debug depth - [4,FF]
#DDR54
5)[pranavp@ca09lab-bfmgr2-lnx SystemAnalyst]% python src/util/compile.py -sn FT240541 -r -pmbx
6)[pranavp@ca09lab-bfmgr2-lnx SystemAnalyst]% python src/apps/phyinit_driver.py -sn FT240541 -c configs/ddr54_ddr5_udimm.json -hdtctrl 0x4 
#Standalone version of mailbox:
#LPDDR54
python src/util/mailbox_messages.py "phyinit/lpddr54/hex_log_file.txt" "phyinit/lpddr54/major_mailbox_message.strings" "phyinit/lpddr54/fw/lpddr5/pmu_train.strings"
#DDR54
python src/util/mailbox_messages.py "phyinit/ddr54/hex_log_file.txt" "phyinit/ddr54/major_mailbox_message.strings" "phyinit/ddr54/fw/ddr5/pmu_train.strings"
#PHY2
8)python src/util/mailbox_messages.py "phyinit/phy2/hex_log_file.txt" "phyinit/phy2/major_mailbox_message.strings" "phyinit/phy2/fw/ddr4/pmu_train.strings"
#DDR54
8) compile: python src/util/compile.py -sn FT24258A -r -pmbx
#with mailbox handler
8) compile: python src/util/compile.py -sn FT24258A -r -pmbx -mbh
9) run: python src/apps/phyinit_driver.py -sn FT24258A -c configs/ddr54_ddr5_rdimm.json -hdtctrl 0x4 #0xA for short run

#Running tests in all boards
#check all available boards
1)pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst % python src/tools/query_boards.py
#Make sure that there is not Unrecognized messages
#For ddr4 udimm - 1d and 2d training will run eg) FT200540 board - waitFwDone() will be called twice
2)pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst % 
3) compile: python src/util/compile.py -sn FT200540 -r -pmbx -mbh #issue Unrecognized string index
4) run: python src/apps/phyinit_driver.py -sn FT200540 -c configs/ddr54_ddr4.json -hdtctrl 0x4
#DDR5 UDIMM
5) compile: python src/util/compile.py -sn FT240541 -r -pmbx -mbh
6) run: python src/apps/phyinit_driver.py -sn FT240541 -c configs/ddr54_ddr5_udimm.json -hdtctrl 0x4

#All board testing
1)python src/util/compile.py -sn FT242581 -r -pmbx -mbh
  python src/apps/phyinit_driver.py -sn FT242581 -c configs/ddr54_ddr5_rdimm.json -hdtctrl 0x4  #-check
  python src/apps/diags_driver.py -sn FT242581 -c configs/ddr54_ddr5_rdimm.json -hdtctrl 0xA
2)python src/util/compile.py -sn FT240541 -r -pmbx -mbh
  python src/apps/phyinit_driver.py -sn FT240541 -c configs/ddr54_ddr5_udimm.json -hdtctrl 0x4  #-check
  python src/apps/diags_driver.py -sn FT240541 -c configs/ddr54_ddr5_udimm.json -hdtctrl 0xA
3)python src/util/compile.py -sn FT240584 -r -pmbx -mbh
  python src/apps/phyinit_driver.py -sn FT240584 -c configs/ddr54_ddr5_udimm.json -hdtctrl 0x4 
  python src/apps/diags_driver.py -sn FT240584 -c configs/ddr54_ddr5_udimm.json -hdtctrl 0x0A
4)python src/util/compile.py -sn FT240542 -r -pmbx -mbh
  python src/apps/phyinit_driver.py -sn FT240542 -c configs/ddr54_ddr5_udimm.json -hdtctrl 0x4 
  python src/apps/diags_driver.py -sn FT240542 -c configs/ddr54_ddr5_udimm.json -hdtctrl 0xA
5)python src/util/compile.py -sn FT242583 -r -pmbx -mbh
  python src/apps/phyinit_driver.py -sn FT242583 -c configs/ddr54_ddr5_rdimm.json -hdtctrl 0x4 
  python src/apps/diags_driver.py -sn FT242583 -c configs/ddr54_ddr5_rdimm.json -hdtctrl 0xA
6)python src/util/compile.py -sn FT240583 -r -pmbx -mbh
  python src/apps/phyinit_driver.py -sn FT240583 -c configs/ddr54_ddr5_udimm.json -hdtctrl 0x4 
  python src/apps/diags_driver.py -sn FT240583 -c configs/ddr54_ddr5_udimm.json -hdtctrl 0xA
7)python src/util/compile.py -sn FT240540 -r -pmbx -mbh
  python src/apps/phyinit_driver.py -sn FT240540 -c configs/ddr54_ddr5_udimm.json -hdtctrl 0x4 
  python src/apps/diags_driver.py -sn FT240540 -c configs/ddr54_ddr5_udimm.json -hdtctrl 0xA
8)python src/util/compile.py -sn FT242580 -r -pmbx -mbh
  python src/apps/phyinit_driver.py -sn FT242580 -c configs/ddr54_ddr5_rdimm.json -hdtctrl 0x4 
  python src/apps/diags_driver.py -sn FT242580 -c configs/ddr54_ddr5_rdimm.json -hdtctrl 0xA
9)python src/util/compile.py -sn FT200540 -r -pmbx -mbh #previous issue:Unrecognized string index
  python src/apps/phyinit_driver.py -sn FT200540 -c configs/ddr54_ddr4.json -hdtctrl 0x4        #-check
  python src/apps/diags_driver.py -sn FT200540 -c configs/ddr54_ddr4.json -hdtctrl 0xA
10)python src/util/compile.py -sn FT242541 -r -pmbx -mbh
  python src/apps/phyinit_driver.py -sn FT242541 -c configs/ddr54_ddr5_rdimm.json -hdtctrl 0x4 
  python src/apps/diags_driver.py -sn FT242541 -c configs/ddr54_ddr5_rdimm.json -hdtctrl 0xA
11)python src/util/compile.py -sn FT243540 -r -pmbx -mbh
  python src/apps/phyinit_driver.py -sn FT243540 -c configs/ddr54_ddr5_lrdimm.json -hdtctrl 0x4 #-check
  python src/apps/diags_driver.py -sn FT243540 -c configs/ddr54_ddr5_lrdimm.json -hdtctrl 0xA
12)python src/util/compile.py -sn FT244500 -r -pmbx -mbh 
  python src/apps/phyinit_driver.py -sn FT244500 -c configs/ddr54_ddr5.json -hdtctrl 0x4
  python src/apps/diags_driver.py -sn FT244500 -c configs/ddr54_ddr5.json -hdtctrl 0xA
13)python src/util/compile.py -sn FT24258A -r -pmbx -mbh
  python src/apps/phyinit_driver.py -sn FT24258A -c configs/ddr54_ddr5_rdimm.json -hdtctrl 0x4 
  python src/apps/diags_driver.py -sn FT24258A -c configs/ddr54_ddr5_rdimm.json -hdtctrl 0xA
#For the below given board FT242500, since it runs on older chip, setdefault.c should not be modified
#for phyinit changes in dev branch
14)python src/util/compile.py -sn FT242500 -r -pmbx -mbh 
  python src/apps/phyinit_driver.py -sn FT242500 -c configs/ddr54_ddr5_rdimm.json -hdtctrl 0x4 
  python src/apps/diags_driver.py -sn FT242500 -c configs/ddr54_ddr5_rdimm.json -hdtctrl 0xA
15)python src/util/compile.py -sn FT243540 -r -pmbx -mbh 
  python src/apps/phyinit_driver.py -sn FT243540 -c configs/ddr54_ddr4_lrdimm.json -hdtctrl 0x4  #-check
  python src/apps/diags_driver.py -sn FT243540 -c configs/ddr54_ddr5_lrdimm.json -hdtctrl 0xA
16)python src/util/compile.py -sn FT2405E0 -r -pmbx -mbh
  python src/apps/phyinit_driver.py -sn FT2405E0 -c configs/ddr54_ddr5_udimm.json -hdtctrl 0x4  #-check
  python src/apps/diags_driver.py -sn FT2405E0 -c configs/ddr54_ddr5_udimm.json -hdtctrl 0xA
17)python src/util/compile.py -sn FT2405B0 -r -pmbx -mbh
  python src/apps/phyinit_driver.py -sn FT2405B0 -c configs/ddr54_ddr5_udimm.json -hdtctrl 0x4  #-check
  python src/apps/diags_driver.py -sn FT2405B0 -c configs/ddr54_ddr5_udimm.json -hdtctrl 0xA
18)python src/util/compile.py -sn FT2425E0 -r -pmbx -mbh 
  python src/apps/phyinit_driver.py -sn FT2425E0 -c configs/ddr54_ddr5_rdimm.json -hdtctrl 0x4 
  python src/apps/diags_driver.py -sn FT2425E0 -c configs/ddr54_ddr5_rdimm.json -hdtctrl 0xA
19)python src/util/compile.py -sn FT244580 -r -pmbx -mbh 
  python src/apps/phyinit_driver.py -sn FT244580 -c configs/ddr54_ddr5_dramdown.json -hdtctrl 0x4
  python src/apps/diags_driver.py -sn FT244580 -c configs/ddr54_ddr5_dramdown.json -hdtctrl 0xA
20)python src/util/compile.py -sn FT242540 -r -pmbx -mbh 
  python src/apps/phyinit_driver.py -sn FT242540 -c configs/ddr54_ddr5_rdimm.json -hdtctrl 0x4
  python src/apps/diags_driver.py -sn FT242540 -c configs/ddr54_ddr5_rdimm.json -hdtctrl 0xA

#PPT guide for System Analyst
https://synopsys.sharepoint.com/:b:/s/SystemAnalyst/ERZtbkC-vF1LpcNtYCvEpnwBrR00c480VVpEPXcrQ4Dyzg

#MeasureTiming
python src/util/compile.py -sn FT242541 -r
python src/apps/phyinit_driver.py -sn FT242541 -c configs/ddr54_ddr5_rdimm.json -t -hdtctrl 255 --overrideUserInput src/test/timing/ddr54/full.py

python src/util/compile.py -sn FT240541 -r
python src/apps/phyinit_driver.py -sn FT240541 -c configs/ddr54_ddr5_udimm.json -t -hdtctrl 255 --overrideUserInput src/test/timing/ddr54/full.py

python src/util/compile.py -sn FT354532 -r 
python src/apps/phyinit_driver.py -sn FT354532 -c configs/lpddr54_lpddr5.json -t -hdtctrl 255 --overrideUserInput src/test/timing/ddr54/full.py

#Undo the changeList
p4 undo ...@11312395 

#Populate a new branch (folder)
pranavp@us01msemt224:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5_std_copy % p4 populate -n //depot/products/lpddr5x_mphy/dev/... //depot/products/lpddr5x_mphy/branches_ate/acsm_experiment/...
10545 files branched.
pranavp@us01msemt224:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5_std_copy % p4 populate //depot/products/lpddr5x_mphy/dev/... //depot/products/lpddr5x_mphy/branches_ate/acsm_experiment/...
10545 files branched (change 12151581).

#eye Display
python src/tools/eye_display.py -f Logs/phyinit_driver_Wed_Jan_11_13-55-14_2023 -d TX -r 0 -b 0 -l 0
python src/tools/eye_display.py -f Logs/phyinit_driver_Wed_Jan_11_13-55-14_2023 -d RX -r 0 -b 0 -l 0
#All lanes
python src/tools/eye_display.py -f Logs/phyinit_driver_Wed_Jan_11_13-55-14_2023 -d RX -r 0 -b 0 

#DDR54 and LPDDR54 diag test
1)python src/util/compile.py -sn FT240541 -r -pmbx
  python src/apps/phyinit_driver.py -sn FT240541 -c configs/ddr54_ddr5_udimm.json -hdtctrl 0xA
  python src/apps/diags_driver.py -sn FT240541 -c configs/ddr54_ddr5_udimm.json -hdtctrl 0xA
2)python src/util/compile.py -sn FT200540 -r -pmbx
  python src/apps/diags_driver.py -sn FT200540 -c configs/ddr54_ddr4.json -hdtctrl 0xA
3)python src/util/compile.py -sn FT203540 -r -pmbx
  python src/apps/diags_driver.py -sn FT203540 -c configs/ddr54_ddr4_lrdimm.json -hdtctrl 0xA
3)python src/util/compile.py -sn FT203540 -r -pmbx
  python src/apps/diags_driver.py -sn FT203540 -c configs/ddr54_ddr4_lrdimm.json -hdtctrl 0xA
#To test testRunner for particular board
4)python src/test/test.py -P ddr54 -p ddr4 -sn FT200540 -hdtctrl 0x0A
5)python src/test/test.py -P ddr54 -p ddr4 -sn FT203540 -hdtctrl 0x0A
6)python src/test/test.py -P lpddr54 -p lpddr5 -sn FT354533 -hdtctrl 0x0A
  python src/test/test.py -P ddr54 -p ddr5 -sn FT242581 -hdtctrl 0x0A
  python src/test/test.py -P phy2 -p lpddr4x -sn FT0644A0 -hdtctrl 0x0A
  python src/test/test.py -P lpddr54 -p lpddr5x -sn FT374595 -hdtctrl 0x0A
  python src/util/compile.py -sn FT354532 -r -pmbx
  python src/apps/phyinit_driver.py -sn FT354532 -c configs/lpddr54_lpddr5.json -hdtctrl 0x4
  python src/apps/diags_driver.py -sn FT354532 -c configs/lpddr54_lpddr5.json -s src/test/functional/lpddr54/tx_eye.py -hdtctrl 0x0A
#Running with min verbosity
7)python src/test/test.py -P ddr54 -p ddr4 -sn FT203540 -hdtctrl 0x04
#Running tests individually:- in overrideUserInput add the corresponding .py file
#If there are multiple .py files add them into list to overrideUserInput
8)python src/apps/phyinit_driver.py -sn FT200540 --overrideUserInput src/test/functional/ddr54/dbi.py -hdtctrl 0x0A
9)python src/apps/phyinit_driver.py -sn FT203540 --overrideUserInput src/test/functional/ddr54/dbi.py -hdtctrl 0x0A

Brian's Script:
python src/util/compile.py -sn FT3545C0 -r
python src/apps/diags_driver.py -sn FT3545C0 -c configs/lpddr54_lpddr5.json -hdtctrl 0xA -s dumpalldfimrl.py


#loop_train_driver.py test:
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dws000/ddrphy_firmware/pranavp/SystemAnalyst1 % python src/apps/loop_train_driver.py -p src/test/functional/ddr54/sweep_params/ddr4.json -sn FT200540 -hdtctrl 0x0A


# RW GUI (Read Write GUI):
# simple test
python src/gui/ddr5_std_trained_values_frame.py -sn FT642610
# Test on the board
python src/util/compile.py -sn FT642610 -r 
python src/apps/diags_driver.py -sn FT642610 -c configs/ddr5_std_ddr5_rdimm.json -hdtctrl 0xA -continue -> choose rw_gui

python src/gui/lpddr5x_std_trained_values_frame.py -sn FT574600

Unreserving the board:
#when you're using the boards, please check periodically to make sure that they get unreserved 
#if phyinit crashes or something else bad happens, then you'll have to manually unreserve it:
#Manually unreserves the board
1)python src/tools/reserve_board.py -sn FT3545C0 -r
#will show whether you have reserved the board or not
2)python src/tools/query_boards.py
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst % python src/tools/query_boards.py
python src/tools/query_boards.py -d udimm
python src/tools/query_boards.py -d rdimm
python src/tools/query_boards.py -d lrdimm

Serial Number   Product   Protocol       DIMM       Manu     Freq  Rank  Width         Test Chip  Unique ID     Reserved By         Reserve Time
------------------------------------------------------------------------------------------------------------------------------------------------
FT246581          ddr54       ddr5      nomem                                    d810 (88) 3.00a          1                                     
FT242581          ddr54       ddr5      rdimm   Sk Hynix  4800MHz     1      4   d810 (88) 3.00a          1                                     
FT240541          ddr54       ddr5      udimm   Sk Hynix  4800MHz     1     16   d806 (84) 3.00a          1                                     
FT240584          ddr54       ddr5      udimm     Micron  4800MHz     1      8   d810 (88) 3.00a          4                                     
FT240542          ddr54       ddr5      udimm     Micron  4800MHz     1     16   d806 (84) 3.00a          2                                     
FT242583          ddr54       ddr5      rdimm     Micron  4800MHz     1      4   d810 (88) 3.00a          3                                     
FT240583          ddr54       ddr5      udimm    Samsung  4800MHz     1      8   d810 (88) 3.00a          3                                     
FT240540          ddr54       ddr5      udimm    Samsung  4800MHz     1      8   d806 (84) 3.00a          0                                     
FT242580          ddr54       ddr5      rdimm   SK Hynix  4800MHz     1      4   d810 (88) 3.00a          0                                     
FT200540          ddr54       ddr4      udimm    G.Skill  3200MHz     2      8   d806 (84) 3.00a          0                                     
FT242541          ddr54       ddr5      rdimm     Micron  4800MHz     1      8   d806 (84) 3.00a          1                                     
FT243540          ddr54       ddr5     lrdimm   SK Hynix  4800MHz     2      4   d806 (84) 3.00a          0                                     
FT244500          ddr54       ddr5   dramdown     Micron  4800MHz     1      8   d802 (80) 0.95a          0                                     
FT24258A          ddr54       ddr5      rdimm   Sk Hynix  4800MHz     2      8   d810 (88) 3.00a         10                                     
                                                Sk Hynix  4800MHz     2      8                                                                  
FT246580          ddr54       ddr5      nomem                                    d810 (88) 3.00a          0                                     
FT242500          ddr54       ddr5      rdimm   Sk Hynix  4800MHz     2      8   d802 (80) 0.95a          0                                     
FT203540          ddr54       ddr4     lrdimm    Samsung  2666MHz     4      4   d806 (84) 3.00a          0     


#PHY2 boards
1)pranavp@ca09lts2:~/Desktop % ssh -X ca09lab-bfmgr3-lnx
pranavp@ca09lts2:~/Desktop % ssh ca09lab-bfmgr3-lnx
2)pranavp@ca09lts2:~/Desktop % cd /remote/ca09dws000/ddrphy_firmware/pranavp/systemAnalyst
3)pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst2 % setenv SYSTEM_ANALYST_HOME `pwd`
4)pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst2 % setenv PYTHONPATH `pwd`:`pwd`/src
#If I get import module saleae error
5)pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst2 % setenv PYTHONPATH ${PYTHONPATH}:/remote/ca09dwp004/ddrphy_firmware/Saleae/lib/python2.7/site-packages
#Changing to editor to gvim - easy to add description after shelve
6)pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst2 % setenv P4EDITOR 'evim -f'
7)pranavp@delbaere-z400-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst3 % ./copyfw-nightly phy2
8)pranavp@delbaere-z400-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst3 % python src/tools/query_boards.py
Serial Number   Product   Protocol       DIMM       Manu     Freq  Rank  Width         Test Chip  Unique ID     Reserved By         Reserve Time
------------------------------------------------------------------------------------------------------------------------------------------------
FT024460           phy2     lpddr4   dramdown   SK Hynix  3733Mhz     2     32   d561 (70) 1.21b          0                                     
FT0645A0           phy2    lpddr4x   dramdown     Micron  4267MHz     1     32   d586 (90) 2.44a          0                                     
FT064570           phy2    lpddr4x   dramdown     Micron  4267MHz     1     32   d568 (87) 2.42a          0                                     
FT034460           phy2     lpddr3   dramdown     Micron  2133Mhz     1     32   d561 (70) 1.21b          0                                     
FT0243F0           phy2     lpddr4   dramdown   SK Hynix  3733Mhz     2     32   d524 (63) 1.20a          0                                     
FT000460           phy2       ddr4      udimm    Corsair  3200MHz     1     72   d561 (70) 1.21b          0                                     
FT0344E0           phy2     lpddr3   dramdown     Micron  2133Mhz     1     32   d517 (78) 2.40a          0                                     
FT010560           phy2       ddr3      udimm    G.Skill  2133MHz     2     64   d585 (86) 2.41a          0                                     
                                                 G.Skill  2133MHz     2     64                                                                  
FT000560           phy2       ddr4      udimm    Corsair  3200MHz     2          d585 (86) 2.41a          0                                     
FT006470           phy2       ddr4      nomem                                    d549 (71) 2.00b          0                                     
FT0644A1           phy2    lpddr4x   dramdown     Micron  4267MHZ     2     16   d565 (74) 2.20a          1                                     
FT0004A0           phy2       ddr4      udimm    Corsair  3200MHz     1          d565 (74) 2.20a          0                                     
FT0644A0           phy2    lpddr4x   dramdown   SK Hynix  4267MHz     2     32   d565 (74) 2.20a          0                  
#PHY2 - DDR3 (only UDIMM) #Tx and Rx eye not support (no support for 2D training)
1) python src/util/compile.py -sn FT010560 -r -pmbx #UDIMM
   python src/apps/phyinit_driver.py -sn FT010560 -c configs/phy2_ddr3.json -hdtctrl 0x4
   python src/apps/diags_driver.py -sn FT010560 -c configs/phy2_ddr3.json -hdtctrl 0xA
2) python src/util/compile.py -sn FT014460 -r -pmbx #no device
   python src/apps/phyinit_driver.py -sn FT014460 -c configs/phy2_ddr3.json -hdtctrl 0x4
   python src/apps/diags_driver.py -sn FT014460 -c configs/phy2_ddr3.json -hdtctrl 0xA
#PHY2 - DDR4 (only UDIMM)
3) python src/util/compile.py -sn FT0005D0 -r -pmbx
   python src/apps/phyinit_driver.py -sn FT0005D0 -c configs/phy2_ddr4.json -hdtctrl 0x4
   python src/apps/diags_driver.py -sn FT0005D0 -c configs/phy2_ddr4.json -hdtctrl 0xA
4) python src/util/compile.py -sn FT0004A0 -r -pmbx
   python src/apps/phyinit_driver.py -sn FT0004A0 -c configs/phy2_ddr4.json -hdtctrl 0x4
   python src/apps/diags_driver.py -sn FT0004A0 -c configs/phy2_ddr4.json -hdtctrl 0xA
5) python src/util/compile.py -sn FT000560 -r -pmbx
   python src/apps/phyinit_driver.py -sn FT000560 -c configs/phy2_ddr4.json -hdtctrl 0x4
   python src/apps/diags_driver.py -sn FT000560 -c configs/phy2_ddr4.json -hdtctrl 0xA # use rank 2 in Tx and Rx eye test
#PHY2 - DDR4 LRDIMM - None
#PHY2 - DDR4 RDIMM - None
#PHY2 - LPDDR3 #Tx and Rx eye not support (no support for 2D training)
6) python src/util/compile.py -sn FT034460 -r -pmbx 
   python src/apps/phyinit_driver.py -sn FT034460 -c configs/phy2_lpddr3.json -hdtctrl 0x4
   python src/apps/diags_driver.py -sn FT034460 -c configs/phy2_lpddr3.json -hdtctrl 0xA
7) python src/util/compile.py -sn FT0344E0 -r -pmbx 
   python src/apps/phyinit_driver.py -sn FT0344E0 -c configs/phy2_lpddr3.json -hdtctrl 0x4
   python src/apps/diags_driver.py -sn FT0344E0 -c configs/phy2_lpddr3.json -hdtctrl 0xA
#PHY2 - LPDDR4
8) python src/util/compile.py -sn FT024570 -r -pmbx 
   python src/apps/phyinit_driver.py -sn FT024570 -c configs/phy2_lpddr4.json -hdtctrl 0x4
   python src/apps/diags_driver.py -sn FT024570 -c configs/phy2_lpddr4.json -hdtctrl 0xA
9) python src/util/compile.py -sn FT024440 -r -pmbx #no device
   python src/apps/phyinit_driver.py -sn FT024440 -c configs/phy2_lpddr4.json -hdtctrl 0x4
   python src/apps/diags_driver.py -sn FT024440 -c configs/phy2_lpddr4.json -hdtctrl 0xA
10) python src/util/compile.py -sn FT0245D0 -r -pmbx #training failed once
   python src/apps/phyinit_driver.py -sn FT0245D0 -c configs/phy2_lpddr4.json -hdtctrl 0x4
   python src/apps/diags_driver.py -sn FT0245D0 -c configs/phy2_lpddr4.json -hdtctrl 0xA
#PHY2 - LPDDR4X
11) python src/util/compile.py -sn FT0644A0 -r -pmbx 
   python src/apps/phyinit_driver.py -sn FT0644A0 -c configs/phy2_lpddr4x.json -hdtctrl 0x4
   python src/apps/diags_driver.py -sn FT0644A0 -c configs/phy2_lpddr4x.json -hdtctrl 0xA
12) python src/util/compile.py -sn FT0644A1 -r -pmbx 
   python src/apps/phyinit_driver.py -sn FT0644A1 -c configs/phy2_lpddr4x.json -hdtctrl 0x4
   python src/apps/diags_driver.py -sn FT0644A1 -c configs/phy2_lpddr4x.json -hdtctrl 0xA
13) python src/util/compile.py -sn FT064570 -r -pmbx 
   python src/apps/phyinit_driver.py -sn FT064570 -c configs/phy2_lpddr4x.json -hdtctrl 0x4
   python src/apps/diags_driver.py -sn FT064570 -c configs/phy2_lpddr4x.json -hdtctrl 0xA
14) python src/util/compile.py -sn FT0645A0 -r -pmbx 
   python src/apps/phyinit_driver.py -sn FT0645A0 -c configs/phy2_lpddr4x.json -hdtctrl 0x4
   python src/apps/diags_driver.py -sn FT0645A0 -c configs/phy2_lpddr4x.json -hdtctrl 0xA
#PHY2 - testRunner
15) python src/test/testRunner.py -P phy2

#Editing an already shelved changeList and shelving them to review
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst % p4 shelve -f -c <changelist#>

#Submitting the changesets in CA09:
#########################################################
# Once submitted, check P4 ADDED files are submitted
#########################################################
# Method 1: (If we have no files to resolve after p4 resolve)
# #review not required
1)pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst % setenv P4EDITOR 'evim -f'
2)pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst % p4 sync
3)pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst % p4 resolve
#When we revert and submit, if there are 2 or more changesets in review, then submit old one first and then new one
4)[pranavp@ca09lab-bfmgr2-lnx common]$ p4 revert -c 8263006 ...
//depot/products/SystemAnalyst/dev/phyinit/lpddr54/userCustom/common/dwc_ddrphy_phyinit_userCustom_majorMailboxMessage.c#none - was add, abandoned
//depot/products/SystemAnalyst/dev/phyinit/lpddr54/userCustom/common/dwc_ddrphy_phyinit_userCustom_streamingMailboxMessage.c#none - was add, abandoned
//depot/products/SystemAnalyst/dev/phyinit/lpddr54/userCustom/common/dwc_ddrphy_phyinit_userCustom_G_waitFwDone.c#5 - was edit, reverted
5)[pranavp@ca09lab-bfmgr2-lnx common]$ p4 submit -e 8263006
Submitting change 8263006.
Locking 4 files ...
edit //depot/products/SystemAnalyst/dev/phyinit/lpddr54/userCustom/common/dwc_ddrphy_phyinit_userCustom_G_waitFwDone.c#6
add //depot/products/SystemAnalyst/dev/phyinit/lpddr54/userCustom/common/dwc_ddrphy_phyinit_userCustom_majorMailboxMessage.c#1
add //depot/products/SystemAnalyst/dev/phyinit/lpddr54/userCustom/common/dwc_ddrphy_phyinit_userCustom_streamingMailboxMessage.c#1
edit //depot/products/SystemAnalyst/dev/src/comm/mailbox.py#32
Change 8263006 renamed change 8272714 and submitted.

# Method 2: (If we have files to resolve after p4 resolve)
# #review required
# For eg., #review-11747616 Corrected bugs in CS/CA eye tests in diags_driver.py and plot_2Dbmps_dbi.py
1)pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst2 % p4 unshelve -s 8782725
2)pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst % setenv P4EDITOR 'evim -f'
3)pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst % p4 sync
4)pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst % p4 resolve
#Resolve all the conflicts if any
#In the description part of submit, use the following template
#Description:
#Jira:
#Please use #review here
#Before submitting, check with all #edit, #add and #delete files are present
#Sometimes #add files may be there if we revert and unshelve. 
#we have to p4 add them and then shelve
5)pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst % p4 submit
#Once submitted, please confirm the only your change is included by using p4v&
6)pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst % p4v&


To shelve a newly created file:
1)[pranavp@ca09lab-bfmgr1-lnx SystemAnalyst]$ p4 add src/comm/hex_log_file.txt 
2)[pranavp@ca09lab-bfmgr1-lnx SystemAnalyst]$ p4 opened
//depot/products/SystemAnalyst/dev/src/comm/hex_log_file.txt#1 - add default change (text)



Start up configuration: #do only once
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst % rm .cshrc  
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst % mv csh.cshrc .cshrc 

#p4 integrate
pranavp committed change 11292347 under review 11292346 into lpddr-fw-combophy:cphy-lpddr 
lpddr5_std % p4 integrate //depot/products/lpddr5x_mphy/dev/...@=11292347 ...    (p4 integrate /fromBranch /toWorkspace)
#fromBranch: //depot/products/lpddr5x_mphy/dev/...@=11292347
#toWorkspace: ...
lpddr5_std % p4 resolve

# permission denied issue : rm -r
rm: cannot remove ‘stage_dir_1678213814/build_release_gate/c/fw/ddr5_lrdimm/ddr5_lrdimm_pmu_train.dis’: Permission denied
pranavp@us01odcvde40200:/remote/us01sgnfs00017/users/pranavp/clients/lp5_std % ls -l
total 32
drwxrwxr-x 3 pranavp synopsys 8192 Nov  3 16:33 build_release_gate.242538
drwxr--r-- 3 pranavp synopsys 8192 Nov 16 11:36 stage_dir_1668203243
drwxr--r-- 3 pranavp synopsys 8192 Mar  7 18:34 stage_dir_1674095177
drwxr--r-- 3 pranavp synopsys 8192 Mar  7 18:41 stage_dir_1678213814
pranavp@us01odcvde40200:/remote/us01sgnfs00017/users/pranavp/clients/lp5_std % p4w -rm -f stage* #deleting the workspace by p4w
INFO: Deleting Directory /remote/us01sgnfs00017/users/pranavp/clients/lp5_std/stage_dir_1668203243 
INFO: Deleting Directory /remote/us01sgnfs00017/users/pranavp/clients/lp5_std/stage_dir_1674095177 


#FW validation - nightly test
#Integrating a folder from depot to folder in local workspace
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst % mkdir fw_validation
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst % cd fw_validation
#this copies all files from fw_validation folder present in the depot to local workspace
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst/fw_validation % p4 integ //depot/products/SystemAnalyst/fw_validation/... /remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst/fw_validation/...
#this excel file contains info regarding which test passed or failed
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst/fw_validation % st results/Thu_Aug_26_16-15-47_2021/results.csv
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst/fw_validation % st results/Thu_Aug_26_16-15-47_2021/results.csv
#fix issues in this file
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst/fw_validation % st validate_fw.py
#-v is to give verbocity - to launch FW validation in DDR5
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst/fw_validation % python validate_fw.py -c $SYSTEM_ANALYST_HOME/configs/ddr54_ddr5_rdimm.json -p phyinit/ddr54/userCustom/ddr5_rdimm/phyinit.json phyinit/ddr54/userCustom/ddr5_rdimm/mb.json phyinit/ddr54/userCustom/ddr5_rdimm/FT242541/custom.json -sn FT242541 -v
#without verbocity - to launch FW validation in DDR5 -  
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst/fw_validation % python validate_fw.py -c $SYSTEM_ANALYST_HOME/configs/ddr54_ddr5_rdimm.json -p phyinit/ddr54/userCustom/ddr5_rdimm/phyinit.json phyinit/ddr54/userCustom/ddr5_rdimm/mb.json phyinit/ddr54/userCustom/ddr5_rdimm/FT242541/custom.json -sn FT242541 
#-v is to give verbocity - to launch FW validation in DDR4
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst/fw_validation % python validate_fw.py -c $SYSTEM_ANALYST_HOME/configs/ddr54_ddr4.json -p phyinit/ddr54/userCustom/ddr4/phyinit.json phyinit/ddr54/userCustom/ddr4/mb.json -sn FT200540 -v
#Produce error in any of .c file which compiles during FW validation
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst/fw_validation % st phyinit/ddr54/userCustom/ddr5-rdimm/FT242541/dwc_ddrphy_phyinit_setDefault.custom
#After prducing error, run FW validation -> it will throw error we injected
#Then do echo $?
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst/fw_validation % echo $? 
#Error should give non-zero output because of error
# '0'-> okay 
# non-zero output -> not okay
#modify the json file to run only specific test cases -we can modify any json file
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst/fw_validation % st phyinit/ddr54/userCustom/ddr5_rdimm/phyinit.json
#exact nightly build
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst/fw_validation % python validate_fw.py -c $SYSTEM_ANALYST_HOME/src/test/FT242541.json -p phyinit/ddr54/userCustom/ddr5_rdimm/phyinit.json phyinit/ddr54/userCustom/ddr5_rdimm/mb.json phyinit/ddr54/userCustom/ddr5_rdimm/FT242541/custom.json --results fw_val_log_dir -t >> fw_val_log_dir/script.log
#DDR4 nightly
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst3/fw_validation % python validate_fw.py -c $SYSTEM_ANALYST_HOME/configs/ddr54_ddr4.json -p phyinit/ddr54/userCustom/ddr4/phyinit.json phyinit/ddr54/userCustom/ddr4/mb.json -sn FT200540 -v


#Adding another client on to our workspace
#dev is a client
#Here we ll be adding fw_validation 
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst % p4 client
  View:
    //depot/products/SystemAnalyst/dev/... //msip_pranavp_SystemAnalyst_ca09/...
    //depot/products/SystemAnalyst/fw_validation/... //msip_pranavp_SystemAnalyst_ca09/fw_validation/...
#To see the fw_validation folder appearing 
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst % p4 sync -f

#dev is a client
#Here we ll be adding hw_reg to check the nightly that runs testRunner 
View:
  //depot/products/SystemAnalyst/dev/... //msip_pranavp_systemAnalyst3_ca09/...
  //depot/products/SystemAnalyst/fw_validation/... //msip_pranavp_systemAnalyst3_ca09/fw_validation/...
  //depot/products/SystemAnalyst/hw_reg/... //msip_pranavp_systemAnalyst3_ca09/hw_reg/...

#To see the fw_validation folder appearing 
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst % p4 sync -f


#Different processes running
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst % top
top - 14:52:06 up 51 days, 23:14, 27 users,  load average: 0.14, 0.05, 0.08
Tasks: 461 total,   1 running, 426 sleeping,  29 stopped,   5 zombie
Cpu(s):  7.1%us,  3.3%sy,  0.0%ni, 89.6%id,  0.0%wa,  0.0%hi,  0.0%si,  0.0%st
Mem:  32680704k total,  8878324k used, 23802380k free,   161120k buffers
Swap: 65362940k total,    30220k used, 65332720k free,  6546320k cached

   PID USER      PR  NI  VIRT  RES  SHR S %CPU %MEM    TIME+  COMMAND                             
 45446 pranavp   20   0  879m  83m 9228 S 90.3  0.3   0:48.09 python                              
 45520 pranavp   20   0 27752 1824 1168 R  0.7  0.0   0:00.11 top                                 
 15829 pranavp   20   0  119m 1944  948 S  0.0  0.0   0:00.36 sshd                                
 15831 pranavp   20   0  118m 2124 1368 S  0.0  0.0   0:00.08 tcsh                                
 45273 pranavp   20   0  240m  10m 3548 S  0.0  0.0   0:00.14 python                              
 48233 pranavp   20   0  122m 4820 1064 S  0.0  0.0  10:51.13 sshd                                
 48234 pranavp   20   0  118m 2200 1420 S  0.0  0.0   0:00.36 tcsh                                
 48590 pranavp   20   0  993m 157m  12m S  0.0  0.5   7:58.63 sublime_text                        
 48594 pranavp   20   0 30564  936  636 S  0.0  0.0   0:00.00 dbus-launch                         
 48595 pranavp   20   0 41892  828  584 S  0.0  0.0   0:00.00 dbus-daemon                         
 48605 pranavp   20   0  216m  19m 3476 S  0.0  0.1   0:09.41 plugin_host                         

#parent and child process running
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst % ps ufx
USER        PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
pranavp   48233  0.1  0.0 125600  4820 ?        S    Sep09  10:51 sshd: pranavp@pts/8
pranavp   48234  0.0  0.0 121016  2200 pts/8    Ss   Sep09   0:00  \_ -tcsh
pranavp   45273  0.2  0.0 246576 10284 pts/8    Sl+  14:51   0:00      \_ python validate_fw.py -c
pranavp   45446  110  0.2 880692 96232 pts/8    Sl+  14:51   1:13          \_ python /remote/ca09d
pranavp   15829  0.0  0.0 122784  1944 ?        S    13:56   0:00 sshd: pranavp@pts/7
pranavp   15831  0.0  0.0 120904  2124 pts/7    Ss   13:56   0:00  \_ -tcsh
pranavp   46678  0.0  0.0 122668  1256 pts/7    R+   14:52   0:00      \_ ps ufx
pranavp   48595  0.0  0.0  41892   828 ?        Ss   Sep09   0:00 /bin/dbus-daemon --fork --print-
pranavp   48594  0.0  0.0  30564   936 ?        S    Sep09   0:00 dbus-launch --autolaunch=e546f77
pranavp   48590  0.0  0.4 1017428 161640 ?      Ssl  Sep09   7:58 /depot/sublime_text_3/sublime_te
pranavp   48605  0.0  0.0 221396 19488 ?        Sl   Sep09   0:09  \_ /depotbld/RHEL6.0/sublime_te


#RxDfe eyes clipped on Samsung LP5
#LPDDR54 Dev
[pranavp@ca09lab-bfmgr2-lnx SystemAnalyst]$ ./copyfw-nightly lpddr54
#Set the DFEMode
path: phyinit/lpddr54/userCustom/lpddr5/FT354530/dwc_ddrphy_phyinit_setDefault.c
Change pUserInputAdvanced->RxDfeMode[pstate]             = 0x0000 to 0x0004;
#compile
[pranavp@ca09lab-bfmgr1-lnx SystemAnalyst]$ python src/util/compile.py -sn FT354530 -r 
#run - generate a log file
[pranavp@ca09lab-bfmgr1-lnx SystemAnalyst]$ python src/apps/phyinit_driver.py -sn FT354530 -c configs/lpddr54_lpddr5.json -hdtctrl 0x4
#generate graph with the log file (-d:Direction: TX or RX (default TX), -r:rank, -b:dbyte, -l:lane)
[pranavp@ca09lab-bfmgr1-lnx SystemAnalyst]$ python src/tools/eye_display.py -f Logs/phyinit_driver_Thu_Sep_30_10-49-03_2021 -d RX -r 0 -b 0 -l 0
[pranavp@ca09lab-bfmgr1-lnx SystemAnalyst]$ python src/tools/eye_display.py -f Logs/phyinit_driver_Thu_Sep_30_10-49-03_2021 -d RX -r 0 -b 0 &
[pranavp@ca09lab-bfmgr1-lnx SystemAnalyst]$ python src/tools/eye_display.py -f Logs/phyinit_driver_Thu_Sep_30_10-49-03_2021 -d RX -r 0 -b 1 &
[pranavp@ca09lab-bfmgr1-lnx SystemAnalyst]$ python src/tools/eye_display.py -f Logs/phyinit_driver_Thu_Sep_30_10-49-03_2021 -d RX -r 0 -b 2 &
[pranavp@ca09lab-bfmgr1-lnx SystemAnalyst]$ python src/tools/eye_display.py -f Logs/phyinit_driver_Thu_Sep_30_13-35-08_2021 -d RX -r 0 -b 3 &

#LPDDR54 - ISSUE board
[pranavp@ca09lab-bfmgr2-lnx SystemAnalyst]$ ./copyfw
    Copying from pranavp@us01odcvde12441:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54_2009.amd
    Connection closed by 10.192.101.206
    rsync: connection unexpectedly closed (0 bytes received so far) [Receiver]
    rsync error: unexplained error (code 255) at io.c(601) [Receiver=3.0.8]
#Set the DFEMode
path: phyinit/lpddr54/userCustom/lpddr5/FT354530/dwc_ddrphy_phyinit_setDefault.c
Change pUserInputAdvanced->RxDfeMode[pstate]             = 0x0000 to 0x0004;
#compile
[pranavp@ca09lab-bfmgr1-lnx SystemAnalyst]$ python src/util/compile.py -sn FT354530 -r 
#run - generate a log file
[pranavp@ca09lab-bfmgr1-lnx SystemAnalyst]$ python src/apps/phyinit_driver.py -sn FT354530 -c configs/lpddr54_lpddr5.json -hdtctrl 0x4
#generate graph with the log file
[pranavp@ca09lab-bfmgr1-lnx SystemAnalyst]$ python src/tools/eye_display.py -f Logs/phyinit_driver_Thu_Sep_30_14-40-11_2021 -d RX -r 0 -b 0 &
[pranavp@ca09lab-bfmgr1-lnx SystemAnalyst]$ python src/tools/eye_display.py -f Logs/phyinit_driver_Thu_Sep_30_14-40-11_2021 -d RX -r 0 -b 1 &
[pranavp@ca09lab-bfmgr1-lnx SystemAnalyst]$ python src/tools/eye_display.py -f Logs/phyinit_driver_Thu_Sep_30_14-40-11_2021 -d RX -r 0 -b 2 &
[pranavp@ca09lab-bfmgr1-lnx SystemAnalyst]$ python src/tools/eye_display.py -f Logs/phyinit_driver_Thu_Sep_30_14-40-11_2021 -d RX -r 0 -b 3 &


#./copyfw
#Create copyfw file in SystemAnalyst
    Right click on SystemAnalyst -> new file
#Copy the code from Christian's path
[pranavp@ca09lab-bfmgr1-lnx SystemAnalyst]$ evim /remote/ca09dwp004/ddrphy_firmware/delbaere/SystemAnalyst/copyfw
#To run newly created batch file with permission
#copyfw is a batch file
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst % chmod u+x copyfw
#To have edit permission for already existing batch file
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst % chmod -R u+w <file_name>
#Modify the path to point to customer issue workspace that is created in US01
#copyfw:
    #!/bin/sh

    path=pranavp@us01odcvde12441:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54_2009.amd #modify the path to point to customer issue workspace that is created in US01
    #path=delbaere@us01odcvde12441:/remote/us01sgnfs00017/users/delbaere/clients/rel_vA-2021.06

    #path=delbaere@us01odcvde12441:/slowfs/us01dwt2p870/work/delbaere/clients/lpddr54
    #path=delbaere@us01odcvde12441:/remote/us01sgnfs00017/users/delbaere/clients/lpddr54_no_changes
    #path=delbaere@us01odcvde12441:/slowfs/us01dwt2p870/work/yiannisk/release_area
    #path=delbaere@us01odcvde12441:/slowfs/us01dwt2p633/atayl/lp54_20
    #path=delbaere@us01odcvde12441:/remote/us01sgnfs00017/users/delbaere/clients/rel_vA-2020.06-T-47854-reset-workaround
    #path=delbaere@us01odcvde12441:/slowfs/us01dwt2p870/work/bperkins/lp54/rel_vA-2020.06-T-47854-zqlatch
    #path=delbaere@us01odcvde12441:/slowfs/us01dwt2p870/work/bperkins/lp54/rel_vA-2020.09-T-0056931_AMD
    #path=delbaere@us01odcvde12441:/remote/us01sgnfs00017/users/delbaere/clients/rel_vA-2020.09-T-0056931_AMD
    #path=delbaere@us01odcvde12441:/remote/us01sgnfs00017/users/delbaere/clients/rel_vA-2020.09
    #path=delbaere@us01odcvde12441:/remote/us01sgnfs00017/users/delbaere/clients/rel_vA-2020.06-T-47854-habana-mission-mode
    #path=delbaere@us01odcvde12441:/remote/us01sgnfs00017/users/delbaere/clients/rel_vA-2020.06-SP1

    #path=delbaere@us01odcvde12441:/remote/us01sgnfs00017/users/delbaere/clients/rel_vA-2020.06-T-47854-zqlatch
    #path=delbaere@us01odcvde12441:/remote/us01sgnfs00017/users/delbaere/clients/rel_vA-2020.11

    echo "Copying from $path"

    /depot/rsync-3.0.8/bin/rsync --rsync-path=/depot/rsync-3.0.8/bin/rsync -e ssh  --exclude '*/obj/*'  -vpLrc $path/build/c/init/  phyinit/lpddr54/init
    /depot/rsync-3.0.8/bin/rsync --rsync-path=/depot/rsync-3.0.8/bin/rsync -e ssh --exclude '*/obj/*'  -vpLrc $path/build/c/fw/rel/  phyinit/lpddr54/fw
    /depot/rsync-3.0.8/bin/rsync --rsync-path=/depot/rsync-3.0.8/bin/rsync -e ssh --exclude '*/obj/*'  -vpLrc $path/pmu_firmware/ate_firmware/fw_src/mnPmuSramMsgBlock_ate.h  ate/lpddr54/atefw
    /depot/rsync-3.0.8/bin/rsync --rsync-path=/depot/rsync-3.0.8/bin/rsync -e ssh --exclude '*/obj/*'  -vpLrc $path/build/c/ate/rl/ccac_objs/dwc_ddrphy_ate_main_\*mem.*  ate/lpddr54/atefw
    #rsync -e ssh --exclude '*/obj/*'  -vpLrc $path/pmu_firmware/ate_firmware/fw_src/mnPmuSramMsgBlock_ate.h  ate/lpddr54/atefw
    #rsync -e ssh --exclude '*/obj/*'  -vpLrc $path/pmu_firmware/ate_firmware/ccac_objs/dwc_ddrphy_ate_main_\*mem.incv  ate/lpddr54/atefw



#copy specific folders from Christian's folders:
#Since  ./copyfw didn't work for me. I physically copied the customer release version from Christian's path
#I copied phyinit/lpddr54/fw and phyinit/lpddr54/init from corresponding folders of Christian
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst % cd phyinit/lpddr54/
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst/phyinit/lpddr54/ % rm -rf fw/
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst/phyinit/lpddr54/ % rm -rf init/
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst/phyinit/lpddr54/ % cp /remote/ca09dwp004/ddrphy_firmware/delbaere/SystemAnalyst/phyinit/lpddr54/fw . -r
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst/phyinit/lpddr54/ % cp /remote/ca09dwp004/ddrphy_firmware/delbaere/SystemAnalyst/phyinit/lpddr54/init . -r


# diags_driver.py name change DM -> DMI and RDQS_T
#LP4
1)python src/util/compile.py -sn FT3244F0 -r -pmbx
  python src/apps/diags_driver.py -sn FT3244F0 -c configs/lpddr54_lpddr4.json 
2)python src/util/compile.py -sn FT3244F0 -r -pmbx
  python src/apps/diags_driver.py -sn FT3244F0 -c configs/lpddr54_lpddr4.json --overrideUserInput src/test/functional/lpddr54/dm.py
#LP4X
3)python src/util/compile.py -sn FT364531 -r -pmbx
  python src/apps/diags_driver.py -sn FT364531 -c configs/lpddr54_lpddr4x.json 
4)python src/util/compile.py -sn FT364531 -r -pmbx
  python src/apps/diags_driver.py -sn FT364531 -c configs/lpddr54_lpddr4x.json --overrideUserInput src/test/functional/lpddr54/dm.py
#LP5
5)python src/util/compile.py -sn FT354533 -r -pmbx
  python src/apps/diags_driver.py -sn FT354533 -c configs/lpddr54_lpddr5.json 
6)python src/util/compile.py -sn FT354533 -r -pmbx
  python src/apps/diags_driver.py -sn FT354533 -c configs/lpddr54_lpddr5.json --overrideUserInput src/test/functional/lpddr54/dm.py
#DDR4
7)python src/util/compile.py -sn FT200540 -r -pmbx
  python src/apps/diags_driver.py -sn FT200540 -c configs/ddr54_ddr4.json
8)python src/util/compile.py -sn FT200540 -r -pmbx
  python src/apps/diags_driver.py -sn FT200540 -c configs/ddr54_ddr4.json --overrideUserInput src/test/functional/ddr54/dm.py
#DDR5
7)python src/util/compile.py -sn FT242541 -r -pmbx 
  python src/apps/diags_driver.py -sn FT242541 -c configs/ddr54_ddr5_rdimm.json
8)python src/util/compile.py -sn FT242541 -r -pmbx
  python src/apps/diags_driver.py -sn FT242541 -c configs/ddr54_ddr5_rdimm.json --overrideUserInput src/test/functional/ddr54/dm.py

# DM + WECC + RECC enabled
# In dm.py
# Enable ECC (lp5 only)
if self._cfg.PROTOCOL == protocolEnum.lpddr5:
    # WECC
    self.setMbValue(["MR22_A0", "MR22_A1", "MR22_B0", "MR22_B1"], 1, 4, 0x30)
    # RECC
    self.setMbValue(["MR22_A0", "MR22_A1", "MR22_B0", "MR22_B1"], 1, 6, 0xC0)

# Enable Data Mask
self.setMbValue(["MR13_A0", "MR13_A1", "MR13_B0", "MR13_B1"], 0, 5, 0x20)

Enter test number: 5
DiagRank (CS[3:0]): 0x
Defaulting to 0x0
DiagRepeatCount: 
Defaulting to 8
DiagLoopCount: 
Defaulting to 127
DiagXCnt: 
Defaulting to 1
DiagPrbs: 1 (prbs23) or 2 (fixed pattern): 
Defaulting to 1
DiagSubTest: 0x
Defaulting to 0x0
#15 in DiagByte means to select all dbytes - we have 4 dbytes
#15 in DiagLane means to select all lanes - we have 10 lanes (8 for DQ, DMI and RDQS_T)
DiagByte (enter 15 for all): 15 # Valid inputs 0,1,2,3,15
DiagLane (enter 15 for all): 15 # Valid inputs 0,1,2,3,....8,9,15
DiagMisc0: 0 (No filter), 1 (Ignore odd), 2 (Ignore even): 0x
Defaulting to 0x0
DiagMisc1: 0 (FIFO), 2 (Normal W/R): 0x
Defaulting to 0x0



Moving files from one disk(ca09dwp004) to another disk(ca09dws000):
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst2 % cd ..
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp % mv SystemAnalyst2 /remote/ca09dws000/ddrphy_firmware/pranavp/
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp % cd /remote/ca09dws000/ddrphy_firmware/pranavp/SystemAnalyst2
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dws000/ddrphy_firmware/pranavp/SystemAnalyst2 % p4 client
Change the root from /remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst2 to /remote/ca09dws000/ddrphy_firmware/pranavp/SystemAnalyst2 


# Plotting the graphs directly with .bin files
python src/tools/plot_2Dbmps_dbi.py -c configs/lpddr5x_std_lpddr5x.json lp5x_std_7728_TX.bin
python src/tools/plot_2Dbmps_dbi.py -c configs/lpddr5x_std_lpddr5x.json lp5x_std_7728_RX.bin



# will give changelist list which u have and the ones u do not have
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst2 % p4 cstat

... change 12523178

... status have

... change 12523294

... status have

... change 12523883

... status need

... change 12523909

... status need

... change 12524099

... status need

... change 12524159

... status need


We have changelist till 12523294

from 12523883... we need those changelists







