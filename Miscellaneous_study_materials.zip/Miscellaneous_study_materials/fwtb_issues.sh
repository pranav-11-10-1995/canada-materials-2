# Go to the sim path
# For example
/remote/us01sgnfs00021/users/andylok/d5std_0411/diag/fw_tb/ddr/reg/sim_ddr5r_train_ac13ck2dq72ch2_tc1_080237_REAL_s-1632912392/cl_build.csh

# cl_build.csh
/slowfs/us01dwt2p311/alpha/dwc_ddr43_phy/verif/global_tools/perforce/frontend/p4w -mkwa -novwa -ch=12306854 -code=lpddr5x_ddr5_phy/dev; source bootenv;
qsub -N fwtb_bldrldiag -P bnormal -A quick -cwd -j y -V -m e -M $user -b y /bin/tcsh -c "make d2crtl phyinit DDR5=1 build=build_real; cd pmu_firmware/ddr/Diags_test; make build=$REPO_PATH/build_real;"
qsub -N fwtb_bldfkdiag -P bnormal -A quick -cwd -j y -V -m e -M $user -b y /bin/tcsh -c "make d2crtl phyinit DDR5=1 fwtb_fake build=build_fake; cd pmu_firmware/ddr/Diags_test; make build=$REPO_PATH/build_fake;"

# Create a new directory 
mkdir ddr5_std_temp

# This will load the issue changelist
/slowfs/us01dwt2p311/alpha/dwc_ddr43_phy/verif/global_tools/perforce/frontend/p4w -mkwa -novwa -ch=12306854 -code=lpddr5x_ddr5_phy/dev;

# Run phyinit
make d2crtl phyinit DDR5=1 build=build_real

# Run diag
cd pmu_firmware/ddr/Diags_test
make build=$REPO_PATH/build_real

# Make changes to cseye.c or diag_apb_config or whatever
# Do not touch randomization as it may change the configuration
cd pmu_firmware/ddr/Diags_test
make build=$REPO_PATH/build_real

# Run sim
# Copy the exact command from issue sim path under user_command_real
.runfwrunfw -regr -diag -delay rand -d5cscaskew 1 -d5misc6_ckdly 1 -swizzle 0 -swap_dbytes 0 -num_pstates 1 -mr38 0x2c -mr39 0x2c -mr50 0 -mr0_bl 0 -coven 0 -fwlocat $REPO_PATH/build_real/c/fw/rel -phyinitlocat $REPO_PATH/build_real/c/init -buildlocat $REPO_PATH/build_real -diagfwlocat $REPO_PATH/build_real/c/diags -seed -1632912392 -testname REAL -seed -1632912392 -testname REALREAL

# Must change two things here
.runfwrunfw -> ${REPO_PATH}/fw_tb/ddr/run/runfw

Add -hdt_ctrl 4 at the end


# Note
-seed -1632912392 -> This seed will exactly reproduce the configurations (including all the randomizations) of training firmware and diag firmware

# We can compare apb_config.sv from issue sim and the one that we have created locally and check for exact match (hdtctrl should be the only change)

# apb_config.sv -> check various configuration like seqctrl, catrainopt, whether we run 1D or 2D training







