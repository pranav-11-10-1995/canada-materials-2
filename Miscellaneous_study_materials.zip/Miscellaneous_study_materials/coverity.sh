Coverity:
Coverity link: https://ddrphy-coverity:8443/reports.htm#v10737/p10042
Project: LPDDR54
Sandwich icon -> Myoutstanding
Assigning tasks: right hand side -> triage -> owner ->pranavp
Filtering tasks: Gear icon -> filter -> using username or checker
Getting fields(columns): Gear icon -> column -> check the checker option
Down arrow near the file name -> show full path to get the path in which the file is located


Coverity MISRA documentation:
https://gitsnps.internal.synopsys.com/ddrphy-firmware/coverity/-/tree/master/Misra%20C%202012%20Guide

Steps for commiting the changes and submitting for review:
# Note: combo PHY/ lpddr5x_mphy (multi-phy : supports multiple protocols) 
1)us01odcvde17752:pranavp>cd /remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy/ 
2)Update the environment to the latest changes:- Only once in a day - start of the day:
	us01odcvde17752:pranavp>source bootenv
	us01odcvde17752:pranavp>p4w -update_env
	us01odcvde17752:pranavp>source bootenv
2)us01odcvde17752:pranavp>source bootenv /*Source the boot environment*/
	Bootenv grid type = msem
3)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54 % rm -rf build fix_misra_error
4)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54 % make phyinit && make phyinit build=fix_misra_error
                           (or)
   To build the phyinit: us01odcvde17752:pranavp>make phyinit
4)View coverity report: us01odcvde17752:pranavp>firefox /remote/us01sgnfs00017/users/pranavp/clients/lpddr54/build/coverity/html/index.html -> Firmware LPDDR4
5)Find the path from LPDDR5 full build that matches file name from coverity:
	us01odcvde17752:pranavp>cd pmu_firmware/production_code
6)To check for read/write/execute permission:
	us01odcvde17752:pranavp>ls -l /* list file with access details */
7)To get write access:
	us01odcvde17752:pranavp>p4 edit pmu_ca.c
8)To check for read/write/execute permission in the file that we got for write access:
	us01odcvde17752:pranavp>ls -l
9)Edit and save the changes: us01odcvde17752:pranavp>vi pmu_eye_optimization.c
10)To check our changes: us01odcvde17752:pranavp>p4 diff
11)To check our changes with + and -: us01odcvde17752:pranavp>p4 diff -du
12)us01odcvde17752:pranavp>make phyinit build=fix_misra_error /* Go to LPDDR5 directory to give make */
13)us01odcvde17752:pranavp>cd fix_misra_error/c/fw
14)us01odcvde17752:pranavp>ls -l */*.bin
14)us01odcvde17752:pranavp>rm -r fix.txt
15)us01odcvde17752:pranavp>md5sum */*.bin | sort -k2 > fix.txt /*Print or check MD5 (128-bit) checksums*/
16)us01odcvde17752:pranavp>cd ../../../build/c/fw
16)us01odcvde17752:pranavp>rm -r old.txt
17)us01odcvde17752:pranavp>md5sum */*.bin | sort -k2 > old.txt
18)comparing two files: us01odcvde17752:pranavp>diff old.txt ../../../fix_misra_error/c/fw/fix.txt
# for the first time, give make clean and make coverity
19)us01odcvde17752:pranavp>make clean
   us01odcvde17752:pranavp>make coverity
   us01odcvde17752:pranavp>make coverityCheck # not necessary. just in case
                          (or)
   Ensure that coverity error is gone: us01odcvde17752:pranavp>make coverity
   us01odcvde17752:pranavp>make coverityCheck # not necessary. just in case
                          (or)
   #if the errors are in diags (dependency modules), then coverityFwLpddr5x will not show errors
   #Hence use make coverity
   us01odcvde17752:pranavp>make clean
   us01odcvde17752:pranavp>make coverityFwLpddr5x     #if we just make changes in pmu_firmware code in comboPHY  
   us01odcvde17752:pranavp>make coverityCheck

20)View coverity report: us01odcvde17752:pranavp>firefox /remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy/build/coverity/html/index.html
21)Changing to editor to gvim: us01odcvde17752:pranavp>setenv P4EDITOR 'evim -f' /*another editor gvim*/
22)Shelving the changes and adding change description: us01odcvde17752:pranavp>p4 shelve
   In the description add #review and then add the description - this will automatically create review from shelve
   with the description from shelve in review description
	Change 8180006 created with 1 open file(s).
	Shelving files for change 8180006.
	edit //depot/products/lpddr54/dev/pmu_firmware/production_code/pmu_eye_optimization.c#77
	Change 8180006 files shelved.
23)Open another terminal and check whether our change got updated: us01odcvde17752:pranavp>cat /tmp/tmp.113292.30 
24)Set for review using ccollab: 
	us01odcvde17752:pranavp>pwd
	/remote/us01sgnfs00017/users/pranavp/clients/lpddr54/build/c/fw
	us01odcvde17752:pranavp>cd ../../..
	us01odcvde17752:pranavp>pwd
	/remote/us01sgnfs00017/users/pranavp/clients/lpddr54
	us01odcvde17752:pranavp>set path = (/depot/java-1.8.0_91/jre/bin /depot/tools/ccollab/bin $path)
	us01odcvde17752:pranavp>ccollab set no-browser true
	us01odcvde17752:pranavp>ccollab login https://ccollab01
	testing JVM in /depot/java-1.8.0_91 ...
	Please enter your username: 
	(default: pranavp)
	> pranavp
	Please enter your password: 
	(Input will not echo.)
25)us01odcvde17752:pranavp>ccollab addchangelist new 8180006
# For review comments fix, once fix is done, do P4 shelve and then do the following
25)Review comments fix: us01odcvde17752:pranavp>ccollab addchangelist <code_review_id> <shelved_changelist_number>
26)Add "no change in binaries observed" in chat
26)
26)Add the reviewers in https://ccollab01 and at the bottom under 'next step' give 'begin review'
   For review comments fix, click on "send to inspection" at the bottom

                                        (or)
	#new code review
	~delbaere/bin/post-review <changelist>
	 
	#update existing review
	~delbaere/bin/post-review <reviewId> <changelist>
#Editing an already shelved changeList and shelving them to review
pranavp@ca09lab-bfmgr2-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst % p4 shelve -f -c <changelist#>
26)Swarm review: https://p4swarm1999.internal.synopsys.com/reviews/
26)Poke the reviewer in https://ccollab01 if the review is not done within 24 hrs
27)rm ~/.vdkload  /* Do this only once*/
   ln -s /remote/cad-rep/etc/.cshrc in home directory /* Do this only once*/
   /***********************************************************************
   Please do not stage before review
   ************************************************************************/
 # Make sure to do source bootenv and compile and then deliver the changes
28)Staging/submitting the changes to the stream: /*Takes around 3 hrs*/
	evim change_description.txt
	input file name, author name, change description and date modified
	ADD review and jira link to that
	#review tage as well as shown below
	#review-8973403
	p4 sync
	p4 resolve 
	p4w -stage -mf change_description.txt 
29) To revert the changes: p4 revert pmu_util.c
30) Error in staging log file: /remote/us01sgnfs00017/users/pranavp/clients/lpddr54/stage_dir_1625767697/release_gate/msip_lint_lp54cs2dq18ch1.spy.log -> find for error keyword in the file
31) Staging log file: /remote/us01sgnfs00017/users/pranavp/clients/lpddr54/stage_dir_1625767697.log


To shelve a newly created file:
1)[pranavp@ca09lab-bfmgr1-lnx SystemAnalyst]$ p4 add src/comm/hex_log_file.txt 
2)[pranavp@ca09lab-bfmgr1-lnx SystemAnalyst]$ p4 opened
//depot/products/SystemAnalyst/dev/src/comm/hex_log_file.txt#1 - add default change (text)

To run coverity faster:
o	In general:
make coverity && make coverityCheck

o	For training firmware:
make coverityFwLpddr5x && make coverityCheck

o	For ATE firmware:
make coverityAte && makeCoverityCheck



Coverity shortcuts:
1) pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54 % make coverityAte #builds only ATE firmware
2) pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54 % make coverityFwLpddr5 #builds only LPDDR5 firmware
3) pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54 % make coverityFwLpddr5x #builds only LPDDR5x firmware
4) pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54 % make coverityPhyinitLpddr5 #builds only LPDDR5 phyinit
5) pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54 % make coverityPhyinitLpddr5x #builds only LPDDR5x phyinit


Coverity - checking binaries -Christian's' tool
#Clean up old sim folders
0)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % cd mytests
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % rm -rf regg_edits
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % rm -rf regg_control
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % cd ..
1)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % p4 opened
//depot/products/lpddr5x_mphy/dev/pmu_firmware/lpddr/production_code/pmu_rx.c#16 - edit default change (text)
//depot/products/lpddr5x_mphy/dev/pmu_firmware/lpddr/production_code/pmu_rxdfe.c#18 - edit default change (text)
//depot/products/lpddr5x_mphy/dev/pmu_firmware/lpddr/production_code/pmu_util.c#57 - edit default change (text)
//depot/products/lpddr5x_mphy/dev/pmu_firmware/lpddr/production_code/pmu_wrlvl.c#27 - edit default change (text)
2)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % p4 shelve
Change 8407746 created with 4 open file(s).
Shelving files for change 8407746.
edit //depot/products/lpddr5x_mphy/dev/pmu_firmware/lpddr/production_code/pmu_rx.c#16
edit //depot/products/lpddr5x_mphy/dev/pmu_firmware/lpddr/production_code/pmu_rxdfe.c#18
edit //depot/products/lpddr5x_mphy/dev/pmu_firmware/lpddr/production_code/pmu_util.c#57
edit //depot/products/lpddr5x_mphy/dev/pmu_firmware/lpddr/production_code/pmu_wrlvl.c#27
Change 8407746 files shelved.
3)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % p4 shelve -fc 8407746
Shelving files for change 8407746.
edit //depot/products/lpddr5x_mphy/dev/pmu_firmware/lpddr/production_code/pmu_rx.c#16
edit //depot/products/lpddr5x_mphy/dev/pmu_firmware/lpddr/production_code/pmu_rxdfe.c#18
edit //depot/products/lpddr5x_mphy/dev/pmu_firmware/lpddr/production_code/pmu_util.c#57
edit //depot/products/lpddr5x_mphy/dev/pmu_firmware/lpddr/production_code/pmu_wrlvl.c#27
Change 8407746 files shelved.
5)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % p4 revert ...
//depot/products/lpddr5x_mphy/dev/pmu_firmware/lpddr/production_code/pmu_rx.c#16 - was edit, reverted
//depot/products/lpddr5x_mphy/dev/pmu_firmware/lpddr/production_code/pmu_rxdfe.c#18 - was edit, reverted
//depot/products/lpddr5x_mphy/dev/pmu_firmware/lpddr/production_code/pmu_util.c#57 - was edit, reverted
//depot/products/lpddr5x_mphy/dev/pmu_firmware/lpddr/production_code/pmu_wrlvl.c#27 - was edit, reverted
6)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % qsh -P iheavy -l os_distribution=centos -now n
6)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % konsole #open in konsole terminal for better view
6)In konsole -> cd /remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy/
6)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % source bootenv
6)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % tools/binDiff -s 8407746
7)Give 'y' to run the sims if there is a difference
#If we find any error, check in nightly if same error exists: 
8)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % find . -iname FAILED.txt
./mytests/regg_edits/sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_47886870326_092923_65/FAILED.txt
./mytests/regg_control/sim_lpddr5_train_partialskip_lp5d5cs4dq40ch2combo_tc200_47887250208_115246_65/FAILED.txt
9)#If no new error exists, its safe to stage - we can change the date in the link
  https://lamp/~us8wtool/live/index.cgi/daily/27-10-21?product=combo_lpddr
#To check what job is running
10)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/ddr54 % qstat
tee: /u/pranavp/tmp/qstat.txt: No such file or directory
job-ID     prior   name       user         state submit/start at     queue                          jclass                         slots ja-task-ID 
------------------------------------------------------------------------------------------------------------------------------------------------
   6745801 0.00000 fw_tb_sim  pranavp      r     10/18/2021 10:53:38 b_msem@odcgen-msem-120g-1176-0   
#To stop the sim in half way
11)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/ddr54 % qdel 6745801 #qdel <jobid>



#diff the obj files
#Remove the previously existing .dis files
7)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % rm -r out1.dis
8)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % rm -r out2.dis
#Change the name of the object file to the one you are working
#Search for the function name in the assemby file to figure out what has changed
#we can two functions top() and bottom() called in beginning and end of the change we have made - 
#This is done to identify the location of the change we have made
9)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % elfdumpac -T -o out1.dis build_control/c/fw/lpddr5x/pmu_train.o
10)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % elfdumpac -T -o out2.dis build_edits/c/fw/lpddr5x/pmu_train.o
11)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % vimdiff out1.dis out2.dis
#For diags - different folder for diags
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % elfdumpac -T -o out1.dis build_control/c/fw/lpddr5x_diags/pmu_diag.o
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % elfdumpac -T -o out2.dis build_edits/c/fw/lpddr5x_diags/pmu_diag.o


# PHYINIT - coverity fixes
#Test bench can also call phyinit functions
The interface between SystemVerilog and C is defined here:
tests/d5/uvmtests/src/sv/phyinit_dpi.svh
tests/lp5/uvmtests/src/sv/phyinit_dpi.svh
That allows the test bench to call phyinit functions, and also some functions of phyinit are replaced/implemented 
by the test bench 
some functions in PhyInit are called from SystemVerilog, so when you search for occurrences of functions, 
you can look under tests/ in addition to pmu_firmare/




When there is any mismatch in checksum - to decode the binary files, incv files and assembly code :
Note:
us01odcvde17752:pranavp>vi lpddr5_pmu_train_imem.incv /*Imem -Instruction memory file*/
us01odcvde17752:pranavp>vi lpddr5_pmu_train_dmem.incv /*Dmem -Data memory file*/
us01odcvde17752:pranavp>vi lpddr5_pmu_train_imem.bin /*Binary Imem file*/

1) Go into any one of the directories:
	pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54 % cd build/c/fw
	pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54/build/c/fw % ls -l
	total 92
	drwxrwxr-x  2 pranavp synopsys 8192 Jul  9 13:18 lpddr4 -> We have chosen this directory
	drwxrwxr-x  2 pranavp synopsys 8192 Jul  9 13:33 lpddr4_2d
	drwxrwxr-x  2 pranavp synopsys 4096 Jul  9 13:24 lpddr4_diags
	drwxrwxr-x  2 pranavp synopsys 8192 Jul  9 13:28 lpddr4_quickboot
	drwxrwxr-x  2 pranavp synopsys 8192 Jul  9 13:20 lpddr4x
	drwxrwxr-x  2 pranavp synopsys 8192 Jul  9 13:33 lpddr4x_2d
	drwxrwxr-x  2 pranavp synopsys 4096 Jul  9 13:25 lpddr4x_diags
	drwxrwxr-x  2 pranavp synopsys 8192 Jul  9 13:30 lpddr4x_quickboot
	drwxrwxr-x  2 pranavp synopsys 8192 Jul  9 13:22 lpddr5
	drwxrwxr-x  2 pranavp synopsys 8192 Jul  9 13:33 lpddr5_2d
	drwxrwxr-x  2 pranavp synopsys 4096 Jul  9 13:26 lpddr5_diags
	drwxrwxr-x  2 pranavp synopsys 8192 Jul  9 13:31 lpddr5_quickboot
	-rw-rw-r--  1 pranavp synopsys 1732 Jul 12 13:09 old.txt
	drwxrwxr-x 14 pranavp synopsys 4096 Jul  9 13:33 rel
	pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54/build/c/fw % cd lpddr4
	pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54/build/c/fw/lpddr4 % ls -l *.incv
	-rw-rw-r-- 1 pranavp synopsys 950272 Jul 12 11:31 lpddr4_pmu_train_dmem.incv
	-rw-rw-r-- 1 pranavp synopsys 180224 Jul 12 11:31 lpddr4_pmu_train_dmem_temp.incv
	-rw-rw-r-- 1 pranavp synopsys 759510 Jul 12 11:31 lpddr4_pmu_train_imem.incv
2) compare dmem: pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54/build/c/fw/lpddr4 % diff lpddr4_pmu_train_dmem.incv ../../../../fix_misra_error/c/fw/lpddr4/lpddr4_pmu_train_dmem.incv
3) compare imem: pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54/build/c/fw/lpddr4 % diff lpddr4_pmu_train_imem.incv ../../../../fix_misra_error/c/fw/lpddr4/lpddr4_pmu_train_imem.incv
#Search for the $$$$$$$$$$$$ function name $$$$$$$$$$$$$$ in the assemby file to figure out what has changed
#we can two functions top() and bottom() called in beginning and end of the change we have made - 
#This is done to identify the location of the change we have made
4)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % tkdiff build_control/c/fw/lpddr5x/lpddr5x_pmu_train.dis build_edits/c/fw/lpddr5x/lpddr5x_pmu_train.dis
or
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54 % diff fix_misra_error/c/fw/lpddr5/lpddr5_pmu_train.dis build/c/fw/lpddr5/lpddr5_pmu_train.dis
5) Check whether any file is opened or not: pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54/build/c/fw/lpddr4 % p4 opened
File(s) not opened on this client.
6)Remove fix_misra_error build :
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54/build/c/fw/lpddr4 % cd ../../../../
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54 % rm -rf build fix_misra_error
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54 % ls /*Ensure that build folder is not present*/
7)'&&' -> only when first build is successful(without errors), it will do the second build: pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54 % make phyinit && make phyinit build=fix_misra_error
#To compare the assembly code:
8)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54/build/c/fw/lpddr4 % diff lpddr4_pmu_train_imem.incv ../../../../fix_misra_error/c/fw/lpddr4/lpddr4_pmu_train_imem.incv
9)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % diff build_{control, edits}/c/fw/lpddr5/pmu_vrefoffset_preproc.c
10)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % diff build_{control, edits}/c/fw/lpddr5/pmu_vrefoffset.o




/*Importing change sets from LPDDR54 to LPDDRX_MPHY workspace*/
1)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % cd /remote/us01sgnfs00017/users/pranavp/clients/lpddr54/ 
2)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54 % p4 changes -m50|grep pranavp
/*To view my changesets*/
3)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54 % p4 changes -m50 pmu_firmware/... | grep pranavp 
	Change 8198738 on 2021/07/09 by pranavp@msip_pranavp_lpddr54_stage_dir_1625857835_0 ' coverity issue fix - MISRA ERR'
	Change 8187989 on 2021/07/08 by pranavp@msip_pranavp_lpddr54_stage_dir_1625780306_0 ' coverity issue fix - MISRA ERR'
/*Display the changes made in the specific changeset - for eg)8187989*/
4)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54 % p4 describe 8269832
5)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54 % cd ../lpddr5x_mphy
6)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % p4 integ //depot/products/lpddr54/dev/pmu_firmware/...@8269832,8269832 pmu_firmware/...
//depot/products/lpddr5x_mphy/dev/pmu_firmware/lpddr/production_code/pmu_eye_optimization.c#11 - integrate from //depot/products/lpddr54/dev/pmu_firmware/production_code/pmu_eye_optimization.c#79 (remapped from //depot/products/lpddr5x_mphy/dev/pmu_firmware/production_code/pmu_eye_optimization.c)
6-b)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % setenv P4EDITOR 'evim -f' 
7)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % p4 resolve
/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy/pmu_firmware/lpddr/production_code/pmu_eye_optimization.c - merging //depot/products/lpddr54/dev/pmu_firmware/production_code/pmu_eye_optimization.c#79
Diff chunks: 4 yours + 2 theirs + 0 both + 0 conflicting
7-a)Accept(a) Edit(e) Diff(d) Merge (m) Skip(s) Help(?) am: am
//msip_pranavp_lpddr5x_mphy_lpddr5x_mphy_0/pmu_firmware/lpddr/production_code/pmu_eye_optimization.c - merge from //depot/products/lpddr54/dev/pmu_firmware/production_code/pmu_eye_optimization.c
/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy/pmu_firmware/lpddr/production_code/pmu_eye_optimization.c - resolving move to //depot/products/lpddr5x_mphy/dev/pmu_firmware/production_code/pmu_eye_optimization.c
Filename resolve:
at: //depot/products/lpddr5x_mphy/dev/pmu_firmware/production_code/pmu_eye_optimization.c
ay: //depot/products/lpddr5x_mphy/dev/pmu_firmware/lpddr/production_code/pmu_eye_optimization.c
7-b)Accept(a) Skip(s) Help(?) ay: ay
//msip_pranavp_lpddr5x_mphy_lpddr5x_mphy_0/pmu_firmware/lpddr/production_code/pmu_eye_optimization.c - ignored //depot/products/lpddr5x_mphy/dev/pmu_firmware/production_code/pmu_eye_optimization.c
8)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % p4 diff -du
--- //depot/products/lpddr5x_mphy/dev/pmu_firmware/lpddr/production_code/pmu_eye_optimization.c	2021-07-12 15:02:27.000000000 -0700
+++ /remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy/pmu_firmware/lpddr/production_code/pmu_eye_optimization.c	2021-07-12 15:02:27.000000000 -0700
@@ -273,15 +273,15 @@
    uint8_t seed_end;
    uint8_t seed_start;
 
-   seed_start = 0;
-   seed_end = 0;
-
    if(num_of_seeds == 2){
       seed_start = 1;
       seed_end = 2;
    } else if(num_of_seeds == 3){
       seed_start = 0;
       seed_end = 2;
+   } else {
+      seed_start = 0;
+      seed_end = 0;
    }




conflicting case:
1)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % setenv P4EDITOR 'evim -f' /*another editor gvim*/
2)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % p4 resolve
/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy/pmu_firmware/lpddr/common_api/hwt_uc_api.c - merging //depot/products/lpddr54/dev/pmu_firmware/common_api/hwt_uc_api.c#299
Diff chunks: 173 yours + 1 theirs + 0 both + 2 conflicting
Accept(a) Edit(e) Diff(d) Merge (m) Skip(s) Help(?) e: e  #edit the code and merge
Accept(a) Edit(e) Diff(d) Merge (m) Skip(s) Help(?) ae: 
//msip_pranavp_lpddr5x_mphy_lpddr5x_mphy_0/pmu_firmware/lpddr/common_api/hwt_uc_api.c - edit from //depot/products/lpddr54/dev/pmu_firmware/common_api/hwt_uc_api.c
/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy/pmu_firmware/lpddr/common_api/hwt_uc_api.c - resolving move to //depot/products/lpddr5x_mphy/dev/pmu_firmware/common_api/hwt_uc_api.c
Filename resolve:
at: //depot/products/lpddr5x_mphy/dev/pmu_firmware/common_api/hwt_uc_api.c
ay: //depot/products/lpddr5x_mphy/dev/pmu_firmware/lpddr/common_api/hwt_uc_api.c
Accept(a) Skip(s) Help(?) ay: 
//msip_pranavp_lpddr5x_mphy_lpddr5x_mphy_0/pmu_firmware/lpddr/common_api/hwt_uc_api.c - ignored //depot/products/lpddr5x_mphy/dev/pmu_firmware/common_api/hwt_uc_api.c
/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy/pmu_firmware/lpddr/production_code/pmu_rdDQS_wrDQ.c - merging //depot/products/lpddr54/dev/pmu_firmware/production_code/pmu_rdDQS_wrDQ.c#176
Diff chunks: 132 yours + 2 theirs + 0 both + 0 conflicting
Accept(a) Edit(e) Diff(d) Merge (m) Skip(s) Help(?) am: am
//msip_pranavp_lpddr5x_mphy_lpddr5x_mphy_0/pmu_firmware/lpddr/production_code/pmu_rdDQS_wrDQ.c - merge from //depot/products/lpddr54/dev/pmu_firmware/production_code/pmu_rdDQS_wrDQ.c
/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy/pmu_firmware/lpddr/production_code/pmu_rdDQS_wrDQ.c - resolving move to //depot/products/lpddr5x_mphy/dev/pmu_firmware/production_code/pmu_rdDQS_wrDQ.c
Filename resolve:
at: //depot/products/lpddr5x_mphy/dev/pmu_firmware/production_code/pmu_rdDQS_wrDQ.c
ay: //depot/products/lpddr5x_mphy/dev/pmu_firmware/lpddr/production_code/pmu_rdDQS_wrDQ.c
Accept(a) Skip(s) Help(?) ay: 
//msip_pranavp_lpddr5x_mphy_lpddr5x_mphy_0/pmu_firmware/lpddr/production_code/pmu_rdDQS_wrDQ.c - ignored //depot/products/lpddr5x_mphy/dev/pmu_firmware/production_code/pmu_rdDQS_wrDQ.c
/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy/pmu_firmware/lpddr/production_code/pmu_util.c - merging //depot/products/lpddr54/dev/pmu_firmware/production_code/pmu_util.c#249
Diff chunks: 83 yours + 2 theirs + 0 both + 0 conflicting
Accept(a) Edit(e) Diff(d) Merge (m) Skip(s) Help(?) am: 
//msip_pranavp_lpddr5x_mphy_lpddr5x_mphy_0/pmu_firmware/lpddr/production_code/pmu_util.c - merge from //depot/products/lpddr54/dev/pmu_firmware/production_code/pmu_util.c
/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy/pmu_firmware/lpddr/production_code/pmu_util.c - resolving move to //depot/products/lpddr5x_mphy/dev/pmu_firmware/production_code/pmu_util.c
Filename resolve:
at: //depot/products/lpddr5x_mphy/dev/pmu_firmware/production_code/pmu_util.c
ay: //depot/products/lpddr5x_mphy/dev/pmu_firmware/lpddr/production_code/pmu_util.c
Accept(a) Skip(s) Help(?) ay: 
//msip_pranavp_lpddr5x_mphy_lpddr5x_mphy_0/pmu_firmware/lpddr/production_code/pmu_util.c - ignored //depot/products/lpddr5x_mphy/dev/pmu_firmware/production_code/pmu_util.c
3)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % make phyinit
#set for review
#run simulation
4)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % vi change_description.txt
5)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % p4w -stage -mf change_description.txt



Observations:
1)Always give source bootenv before making
2)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp % df -h /*To know all the disk spaces available*/
3)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp % df -h ./*To know  the disk spaces available in which current directory is located - we can check how much more space we can use and try not to exhaust it*/
4)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp % cd /remote/us01sgnfs00052 -> mkdir pranavp failed in this location
5)us01odcvde17752:pranavp>echo $PATH
/remote/sge4/default/bin/lx-amd64:/remote/lsf/src/10.1/linux2.6-glibc2.3-x86_64/etc:/remote/lsf/src/10.1/linux2.6-glibc2.3-x86_64/bin:/remote/cad-rep/emll/tools/system/ume/2021.01/bin:/remote/cad-rep/emll/tools/system/vdk/2020.09/bin:/global/apps/embedit_2021.03-SP1/bin:/remote/sge4/default/bin/lx-amd64:/depot/tcl8.6.6/bin:/depot/tcl8.4.19/bin:/bin:/usr/ucb:/usr/openwin/bin:/sbin:/usr/dt/bin:/usr/ccs/bin:/usr/X11R6/bin:/depot/java-1.8.0_91/bin:/remote/cad-rep/msip/tools/Shelltools/calex/2021.06/bin:/remote/cad-rep/msip/tools/bin:/remote/cad-rep/msip/tools/Shelltools/ude/ude/2021.05/bin:/depot/rsync-3.0.8/bin:/remote/cad-rep/msip/scripts:/usr/lib64/qt-3.3/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/usr/local/bin:/opt/Citrix/VDA/bin:/u/pranavp/.dotnet/tools:/usr/local/bin:/u/pranavp/bin:/u/pranavp/bin/p4v/bin:/u/pranavp/bin/cudatext
6)To change tab to 4 spaces:
	create a file called .vimrc in home directory
	Insert the following code in that
	set sw:4 et sta
7)p4v & -> opens gui view
8)qsh #understand its role in sims
9)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54/fix_misra_error % cat ~yiannisk/.aliases
10)pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr54/fix_misra_error % cat ~yiannisk/.aliases | grep q
11)pranavp@us01msem-32cx720g-386-120:~ % hostname #us01msem-32cx720g-386-120



Reviewers:
1.	Brian Perkins and myself as Reviewers
2.	Other Coverity team members are Observers (Arshi, Harshit, Shubham, Abdullah, Anil)
3.	Code owners as Reviewer (Andy Milia for optimizer, Joshua Williams for most other training code, Frank Liu (wenlin) for diags)
4.	For changes to pmu_firmware, add Observers: Lance Huang, and Olivier Benny




#Fake firmware
make d2crtl fwtb fwtb_fake phyinit #compiles base rtl for fwtb
make fwtb_fake   #Runs in host
make fwtb   #runs in ARC
make phyinit #uses phyinit to initialize the hardware

$REPO_PATH/fw_tb/run/runfw -compress 0 -caswizzle 0 -dqswizzle 0 -dram LPDDR5 -dimm UDIMM -seed 1 -frequency 800 -cfg cs1dq16ch1 -hdtctrl 255  -DfiFreqRatio 2 -SequenceCtrl 7 -phyinit_mode skiptrain -cfgps 3 -passfail -fsdb 0 -chkresult 1 -backdoor_sram -mmisc 14 -host_as_fake_uc


#Kill the task in the terminal
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst2 % ps
   PID TTY          TIME CMD
 50899 pts/31   00:00:00 tcsh
 60674 pts/31   00:00:00 python
 60682 pts/31   00:00:00 python
 64101 pts/31   00:05:42 python
 64316 pts/31   00:00:00 ps
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst2 % kill 60674
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst2 % 
[1]    Terminated                    python src/test/testRunner.py -P lpddr54