1)login shell: echo $SHELL 
	/bin/tcsh
	SHELL is an env variable which contains path name of our login shell
2)Moving to different shell - to know the path :  which csh
	/bin/csh
3)Changing to different shell: chsh
	changing shell for pranavp
	New shell[/bin/tcsh]: /bin/csh
	Password:
4)starts tcsh: tcsh
5)To display shell start up files: more ~/.cshrc ~/.login 
6)To display the values of the env variables: printenv
7)To set the value of env variables: set
8)To display all alias used: alias
	qterm for qsh -P iheavy
9)To review the history of the commands: history
10)To get the date: date
11)To show who has logged in: who
12)To list the contents of the current directory: ls
13)To clear the screen: clear
14)To kill the executing command: ctrl+c
15)To make a folder: mkdir <filename>
16)To list contents of current directory: ls
17)To remove file: rm <file_name>
18)To make a copy of file: cp <file1> <file2>
19)To rename file: mv <file1> <file2>
20)To concatenate files into one file: cat file1 file2 > file3
21)To print contents onto the screen: echo
22)To list directory above the current directory: ls ..
23)To go to home directory: cd
24)To remove the directory: rmdir <directory_name>
	rm -r <directory_name>
25)To define values to variable: set <variable_name> <value>
26) source
27)To define env variable: setenv <variable_name> <value>
28)To edit a file: vi <file_name>
29)


