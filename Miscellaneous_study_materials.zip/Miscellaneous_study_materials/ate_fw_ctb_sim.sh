cd $REPO_PATH
make clean d2crtl phyinit LP54X=1
#--Build prerequisties for StdProd LP5
make ateDone LP54X=1
cd $REPO_PATH/pmu_firmware/ate_firmware/
make clean real DDR5=0
/u/atayl/scripts/demo_ate_update.sh lp5
# Edit ctb_verif/testbench/tc/demo/demo_ate.sv -> replace d5 with lp5
cd $REPO_PATH/ctb_verif/sim
# That gets rid of everything in sim/ which isn't managed by p4
# you can use p4 clean to help find files which you've created but haven't committed
p4 clean ./...
source bootenv_internal
# Other test except for PLL
./runtc tc=demo_ate dump=FSDB bkdoor=1 ate=SELECTED_TEST
# run coverity before staging
make coverity



cd $REPO_PATH
make d2crtl phyinit DDR5=1
#--Build prerequisties for StdProd D5
make ateDone DDR5=1
cd $REPO_PATH/pmu_firmware/ate_firmware/
make clean real DDR5=1
/u/atayl/scripts/demo_ate_update.sh lp5
# Edit ctb_verif/testbench/tc/demo/demo_ate.sv -> replace d5 with lp5
cd $REPO_PATH/ctb_verif/sim
# That gets rid of everything in sim/ which isn't managed by p4
# you can use p4 clean to help find files which you've created but haven't committed
p4 clean ./...
source bootenv_internal
# Other test except for PLL
./runtc tc=demo_ate_ddr5 dump=FSDB bkdoor=1 ate=SELECTED_TEST dram=ddr5 freq0=1000 cfg=d5ac11ck1dq64ch2 cfg_p=cs2ac11d10ch2
# run coverity before staging
make coverity


# waveform
./verdi.run &

# PLL lock test
# Create a file called ate_cust_mb_cfg_file_0.sv 
# Add the following
# TestsToRun = 'h4; // 4 denotes PLL Lock test
# MemClkToggle = 'd1;
# MemClkTime = 'd200;

# Create a file called cmd_opts_file_0.f
# Add the following
# ate_cust_mb_cfg_file=$REPO_PATH/ctb_verif/sim/ate_cust_mb_cfg_file_0.sv
# freq0=800
# ate=pll_lock
# dump=FSDB
# tc=demo_ate_lpddr5
# dram=lpddr5
# dfi_mode=3
# bkdoor=1
# ate_bkdoor=0

./runtc cof=cmd_opts_file_0.f

# Another way to run PLL test
# To run test 4 and with paramters MemClkTime and MemClkToggle updated
# In pmu_firmware/ate_firmware/fw_src/dwc_ddrphy_ate_main.c
void dwc_ddrphy_ate_main(void)
{
  DEFINE_ATE_MESSGBLOCK();
  ate_messgBlock->TestsToRun = 4;
  ate_messgBlock->MemClkTime = 200;
  ate_messgBlock->MemClkToggle = 1;
  .
  .
  .
}

make clean real DDR5=0
source bootenv_internal
./simv +ddr_squashz_to_0 | tee simv.log


mnPmuSramMsgBlock_ate.src.h, we can check the test number to run
#define REVISION_CHECK_TEST    0x0001u
#define IMPEDANCE_CAL_TEST     0x0002u
#define PLL_LOCK_TEST          0x0004u
#define LCDL_LINEARITY_TEST    0x0008u
#define AC_LOOPBACK_TEST       0x0010u
#define BURN_IN_TEST           0x0080u
#define DAT_1D_LOOPBACK_TEST   0x0020u
#define DAT_2D_LOOPBACK_TEST   0x0040u
#define RXREPLICA_TEST         0x0100u
#define DAT_DCA_LOOPBACK_TEST  0x0200u
#define MEMRESET_LOOPBACK_TEST 0x0400u
#define PCLK_DCA_TEST          0x0800u

SELECTED_TEST can be one of the following:
   - revision_check
   - impedance_cal
   - pll_lock
   - lcdl_linearity
   - ac_loopback
   - data_1d_loopback

Check for binary match:
tools/binDiff -s <changeList>
   
You can load the waves by running './verdi.run &'

Press r in the waveform

Type the path in lookup
/u/atayl/wave_scripts/verdi/stdprod/

choose trace_registers_r1.rc

click 100%

In the waveform
First signal (csrSeq0BGPR0_p0[15:0]) -> test number (4) -> We have to see 4 in the waveform

Add the following call to the dwc_ddrphy_ate_pll_lock.c and note down the line number
ate_write_fw_trace(PLL_LOCK_TEST,__LINE, give any variables to view in the waveform)

second signal (csrSeq0BGPR0_p1[15:0]) -> line number in dwc_ddrphy_ate_pll_lock.c

Message block
pmu_firmware/ate_firmware/autogen/lp5/fw_src/dwc_ddrphy_ate_msgBlockTrace.h
ate_write_fw_trace(0,  1008,  (uint16_t)ate_messgBlock->TxModeCtlAcCk,       (uint16_t)ate_messgBlock->ContinuousCal,               (uint16_t)ate_messgBlock->CalInterval,          (uint16_t)ate_messgBlock->MemClkToggle); 
memclk toggle is the third variable -> 3 rd signal from the line number signal (csrSeq0BGPR0_p4[15:0])

click on the second signal (csrSeq0BGPR0_p1[15:0]) by -> busvalue  -> line number 1008 -> right arrow