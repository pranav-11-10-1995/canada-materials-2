pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst3 % python -m pdb src/apps/phyinit_driver.py -sn FT354532 -c configs/lpddr54_lpddr5.json -hdtctrl 0x4
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst3 % python -m pdb src/apps/diags_driver.py -sn FT354532 -c configs/lpddr54_lpddr5.json -hdtctrl 0xA
pranavp@delbaere-z400-lnx:/remote/ca09dws000/ddrphy_firmware/pranavp/systemAnalyst3 % python -m pdb src/apps/diags_driver.py -sn FT024570 -c configs/phy2_lpddr4.json -hdtctrl 0xA


Command     Key    Description
Next        n      Execute the next line
Print       p      print value of variable following p #(eg: p var_name)
Step        s      Step into a function
Return      r      Run until current function returns
breakpoint  b      b 63 #breakpoint at line number 63 in the current file;  b src/apps/diags_driver.py:23 
Continue    c      continue till the break point
Repeat      Enter  Repeat the last entered command
List        l      Show few lines above and below the current line
Quit        q      Quit pdb abruptly
Exit        exit   Exit out of pdb

# Note
Breakpoint did not work in subprocess

# gdb
pranavp@ca09lab-bfmgr1-lnx:/remote/ca09dwp004/ddrphy_firmware/pranavp/SystemAnalyst3 % gdb --args python src/apps/phyinit_driver.py -sn FT354532 -c configs/lpddr54_lpddr5.json -hdtctrl 0x4


command     key
run         r      running for the first time
Next        n      Execute the next line
Print       p      print value of variable following p #(eg: p var_name)
Step        s      Step into a function
Continue    c      continue till the break point
breakpoint  b      b 63 #breakpoint at line number 63 in the current file;  b phyinit/lpddr5x_std/init/lpddr5x/src/dwc_ddrphy_phyinit_C_initPhyConfig.c:4087