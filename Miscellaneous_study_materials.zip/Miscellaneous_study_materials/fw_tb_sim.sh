# Note
# 1D takes shorter time to complete than 2D

# DDR54
# CS/CA eye
# UDIMM
# 2D
1) ${REPO_PATH}/fw_tb/run/runfw -dram DDR5 -cfg ac12d4ch2 -delay rand -d5cscaskew 1 -fwtb_debug 1 -diag -dimm udimm -d5misc6_ckdly 1 -swizzle 0 -swap_dbytes 0 -CsPresent 0x1 -num_pstates 1 -mmisc 6 -mr50 0 -mr0_bl 0 -min_diag_rand -catrainopt 0x3d -hdt_ctrl 4 -testname fwtb_diag_01_01_23_3
# 1D
2) ${REPO_PATH}/fw_tb/run/runfw -dram DDR5 -cfg ac12d4ch2 -delay rand -d5cscaskew 1 -fwtb_debug 1 -diag -dimm udimm -d5misc6_ckdly 1 -swizzle 0 -swap_dbytes 0 -CsPresent 0x1 -num_pstates 1 -mmisc 6 -mr50 0 -mr0_bl 0 -min_diag_rand -hdt_ctrl 4 -testname fwtb_diag_01_01_23_1

# RDIMM
# 2D
3) ${REPO_PATH}/fw_tb/run/runfw -dram DDR5 -cfg ac14d10ch2 -delay rand -d5cscaskew 1 -fwtb_debug 1 -diag -dimm rdimm -d5misc6_ckdly 1 -swizzle 0 -swap_dbytes 0 -CsPresent 0x1 -num_pstates 1 -mmisc 6 -mr50 0 -mr0_bl 0 -min_diag_rand -catrainopt 0x3d -hdt_ctrl 4 -testname fwtb_diag_02_01_23_1
# 1D
4) ${REPO_PATH}/fw_tb/run/runfw -dram DDR5 -cfg ac14d10ch2 -delay rand -d5cscaskew 1 -fwtb_debug 1 -diag -dimm rdimm -d5misc6_ckdly 1 -swizzle 0 -swap_dbytes 0 -CsPresent 0x1 -num_pstates 1 -mmisc 6 -mr50 0 -mr0_bl 0 -min_diag_rand -hdt_ctrl 4 -testname fwtb_diag__01_01_23_2

# To just check for syntax error in the fw_tb code - just run devinit so that we can check errors faster
# Add -phyinit_mode devinit
# Run with min config ac6d4ch1
# Add -delay zero  also to run faster
# Remove -d5cscaskew 1 also to run faster

# UDIMM
# Skip CA lane 13
5) ${REPO_PATH}/fw_tb/run/runfw -dram DDR5 -cfg ac6d4ch1 -delay zero -fwtb_debug 1 -diag -dimm udimm -d5misc6_ckdly 1 -swizzle 0 -swap_dbytes 0 -CsPresent 0x1 -num_pstates 1 -mmisc 6 -mr50 0 -mr0_bl 0 -catrainopt 0x10 -min_diag_rand -hdt_ctrl 4 -testname fwtb_diag_03_01_23_1 -phyinit_mode devinit
# train CA lane 13
6) ${REPO_PATH}/fw_tb/run/runfw -dram DDR5 -cfg ac6d4ch1 -delay zero -fwtb_debug 1 -diag -dimm udimm -d5misc6_ckdly 1 -swizzle 0 -swap_dbytes 0 -CsPresent 0x1 -num_pstates 1 -mmisc 6 -mr50 0 -mr0_bl 0 -catrainopt 0 -min_diag_rand -hdt_ctrl 4 -testname fwtb_diag_03_01_23_1 -phyinit_mode devinit

# RDIMM
# ac12d4ch2 - min config with RDIMM
7) ${REPO_PATH}/fw_tb/run/runfw -dram DDR5 -cfg ac12d4ch2 -delay zero -fwtb_debug 1 -diag -dimm rdimm -d5misc6_ckdly 1 -swizzle 0 -swap_dbytes 0 -CsPresent 0x1 -num_pstates 1 -mmisc 6 -mr50 0 -mr0_bl 0 -min_diag_rand -hdt_ctrl 4 -testname fwtb_diag_03_01_23_1 -phyinit_mode devinit


${REPO_PATH}/fw_tb/run/runfw -regr -diag -delay rand -d5cscaskew 1 -d5misc6_ckdly 1 -swizzle 0 -swap_dbytes 0 -num_pstates 1 -mr38 0x2c -mr39 0x2c -mr50 0 -mr0_bl 0 -coven 0  -seed -1632912392 -testname REAL
# Configuration
# UDIMM
ac6d2ch1   
ac6d4ch1   
ac6d5ch1   
ac10d2ch1  
ac10d4ch1  
ac10d5ch1  
ac14d5ch1  
ac12d4ch2  
ac12d8ch2  
ac12d9ch2  
ac12d10ch2 
ac14d4ch2  
ac14d8ch2  
ac14d9ch2  
ac14d10ch2 

# RDIMM:
ac12d4ch2  
ac12d8ch2  
ac12d9ch2  
ac12d10ch2 
ac14d4ch2  
ac14d8ch2  
ac14d9ch2  
ac14d10ch2 

# DDR5_STD
# UDIMM
# 2D
${REPO_PATH}/fw_tb/ddr/run/runfw -dram DDR5 -cfg ac9ck2dq40ch1 -delay rand -d5cscaskew 1 -fwtb_debug 1 -diag -dimm udimm -d5misc6_ckdly 1 -swizzle 0 -swap_dbytes 0 -CsPresent 0x1 -num_pstates 1 -mmisc 6 -mr50 0 -mr0_bl 0 -catrainopt 0x3d -hdt_ctrl 4 -testname fwtb_diag_03_03_23_1

# 1D
${REPO_PATH}/fw_tb/ddr/run/runfw -dram DDR5 -cfg ac9ck2dq40ch1 -delay rand -d5cscaskew 1 -fwtb_debug 1 -diag -dimm udimm -d5misc6_ckdly 1 -swizzle 0 -swap_dbytes 0 -CsPresent 0x1 -num_pstates 1 -mmisc 6 -mr50 0 -mr0_bl 0 -hdt_ctrl 4 -testname fwtb_diag_03_03_23_3


# RDIMM
# 2D
${REPO_PATH}/fw_tb/ddr/run/runfw -dram DDR5 -cfg ac11ck1dq32ch2 -delay rand -d5cscaskew 1 -fwtb_debug 1 -diag -dimm rdimm -d5misc6_ckdly 1 -swizzle 0 -swap_dbytes 0 -CsPresent 0x1 -num_pstates 1 -mmisc 6 -mr50 0 -mr0_bl 0 -catrainopt 0x3d -hdt_ctrl 4 -testname fwtb_diag_03_03_23_2

# 1D
${REPO_PATH}/fw_tb/ddr/run/runfw -dram DDR5 -cfg ac11ck1dq32ch2 -delay rand -d5cscaskew 1 -fwtb_debug 1 -diag -dimm rdimm -d5misc6_ckdly 1 -swizzle 0 -swap_dbytes 0 -CsPresent 0x1 -num_pstates 1 -mmisc 6 -mr50 0 -mr0_bl 0 -hdt_ctrl 4 -testname fwtb_diag_03_03_23_4 

${REPO_PATH}/fw_tb/ddr/run/runfw -dram DDR5 -fwtb_debug 0 -regr -diag -delay rand -d5cscaskew 1 -d5misc6_ckdly 1 -swizzle 0 -swap_dbytes 0 -num_pstates 1 -mr38 0x2c -mr39 0x2c -mr50 0 -mr0_bl 0 -coven 0 -seed -1012022308 -phyCfg 1 -testname cseye_rerun_phyCfg_1




${REPO_PATH}/fw_tb/ddr/run/runfw -dram DDR5 -regr -diag -delay rand -d5cscaskew 1 -d5misc6_ckdly 1 -swizzle 0 -swap_dbytes 0 -num_pstates 1 -mr38 0x2c -mr39 0x2c -mr50 0 -mr0_bl 0 -coven 0 -seed 2138112530 -testname VrefCSMismatchWithHdtCtrl -hdt_ctrl 4
# Configuration
# UDIMM
ac10ck4dq16ch1
ac10ck4dq36ch1
ac10ck4dq40ch1
ac10ck4dq32ch1
ac17ck4dq32ch2
ac17ck4dq64ch2
ac17ck4dq72ch2
ac17ck4dq80ch2
ac19ck8dq32ch2
ac19ck8dq64ch2
ac19ck8dq72ch2
ac19ck8dq80ch2
ac9ck2dq16ch1
ac9ck2dq32ch1
ac9ck2dq36ch1
ac9ck2dq40ch1

# RDIMM
ac11ck1dq32ch2
ac11ck1dq64ch2
ac11ck1dq72ch2
ac11ck1dq80ch2
ac13ck2dq80ch2
ac17ck4dq64ch2
ac17ck4dq72ch2
ac19ck8dq32ch2
ac19ck8dq64ch2
ac19ck8dq72ch2
ac19ck8dq80ch2