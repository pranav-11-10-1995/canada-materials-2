pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % qsh -P iheavy -l os_distribution=centos -now n
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % Konsole
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % source bootenv
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % p4 shelve
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % p4 revert ...
#Run tools/binDiff again with coverity check changes
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % tools/binDiff -s 8407746
#COMBO_PHY
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % make phyinit && make clean && make coverity
#LP5_STD
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % make phyinit LP54X=1 && make clean && make coverity
#If there is any diff, run Simulation -> answer 'y' to the question: "Do u want to run the regression?"
#To check what job is running
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % qstat
#Running time of the sim is around a day
pranavp@us01odcvde17752:/remote/us01sgnfs00017/users/pranavp/clients/lpddr5x_mphy % find . -iname FAILED.txt #open in konsole terminal for better view
